<?php
include("../asset/connection/connection.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>autoresQ | Find Workshops</title>
<link rel="icon" type="image/png" href="../asset/logo/autoresQ_logo.png" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous" />

<style>
body {
  margin: 0;
  font-family: "Poppins", sans-serif;
  background: #f8f9fb;
  color: #333;
}

header {
  background: linear-gradient(90deg, #b71c1c, #d32f2f);
  color: white;
  padding: 20px 50px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 3px 8px rgba(0,0,0,0.3);
}

.logo {
  display: flex;
  align-items: center;
  gap: 15px;
}

.logo img {
  width: 55px;
  height: auto;
}

.logo h1 {
  font-size: 28px;
  font-weight: 700;
  margin: 0;
  letter-spacing: 1px;
}

.filter-section {
  background: #fff;
  padding: 25px;
  margin: 25px auto;
  width: 85%;
  border-radius: 15px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  display: flex;
  justify-content: center;
  gap: 30px;
  flex-wrap: wrap;
}

.filter-section select {
  padding: 10px 15px;
  border-radius: 10px;
  border: 1px solid #ccc;
  font-size: 15px;
  width: 200px;
}

.workshop-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 25px;
  padding: 20px 60px 100px;
}

.card {
  background: #fff;
  border-radius: 18px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  overflow: hidden;
  transition: all 0.3s ease;
  position: relative;
}

.card:hover {
  transform: translateY(-6px);
  box-shadow: 0 6px 18px rgba(0,0,0,0.2);
}

.card img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.card-content {
  padding: 15px 20px;
}

.card-content h3 {
  color: #b71c1c;
  font-size: 20px;
  margin: 8px 0;
}

.card-content p {
  margin: 4px 0;
  font-size: 15px;
  color: #555;
}

.rating {
  color: #ffcc00;
  margin: 8px 0;
}

.card .btn {
  display: inline-block;
  background: linear-gradient(90deg, #b71c1c, #d32f2f);
  color: #fff;
  text-decoration: none;
  padding: 10px 18px;
  border-radius: 8px;
  font-weight: 500;
  margin-top: 10px;
  transition: all 0.3s;
}

.card .btn:hover {
  background: #9a1616;
}

footer {
  background: #222;
  color: #ccc;
  text-align: center;
  padding: 15px 0;
  position: fixed;
  bottom: 0;
  width: 100%;
  font-size: 14px;
  letter-spacing: 0.5px;
}
</style>
</head>

<body>
<header>
  <div class="logo">
    <img src="../asset/logo/autoresQ_logo.png" alt="autoresQ logo">
    <h1>autoresQ</h1>
  </div>
  <h3>🚘 Find the Best Workshops Near You</h3>
</header>

<div class="filter-section">
  <div>
    <label><strong>District:</strong></label><br>
    <select name="district" id="district" onchange="getPlace(this.value);FindShop();">
      <option value="">--Select District--</option>
      <?php
        $districtSel="select * from tbl_district";
        $disResult=$Con->query($districtSel);
        while($disRow=$disResult->fetch_assoc()) {
      ?>
      <option value="<?php echo $disRow['district_id']?>"><?php echo $disRow['district_name']?></option>
      <?php } ?>
    </select>
  </div>

  <div>
    <label><strong>Place:</strong></label><br>
    <select name="place" id="place" onchange="FindShop();">
      <option value="">--Select Place--</option>
    </select>
  </div>
</div>

<div id="result" class="workshop-container">
<?php
$i=0;
$selQry = "select * from tbl_workshop u 
inner join tbl_place p on u.place_id=p.place_id 
inner join tbl_district d on d.district_id=p.district_id 
where workshop_status=1";
$result = $Con->query($selQry);
while ($row1= $result->fetch_assoc()) {
  $i++;
?>
<div class="card">
  <img src="../asset/Files/WorkShop/Photo/<?php echo $row1['shop_photo'];?>" alt="Workshop Photo">
  <div class="card-content">
    <h3><?php echo $row1['shop_name']; ?></h3>
    <p><i class="ri-mail-line"></i> <?php echo $row1['shop_email']; ?></p>
    <p><i class="ri-phone-line"></i> <?php echo $row1['shop_contact']; ?></p>
    <p><i class="ri-map-pin-line"></i> <?php echo $row1['place_name']; ?>, <?php echo $row1['district_name']; ?></p>

    <div class="rating">
      <?php
        $average_rating = 0;
        $total_review = 0;
        $total_user_rating = 0;
        $query = "SELECT * FROM tbl_rating WHERE workshop_id = '".$row1["shop_id"]."'";
        $resultRating = $Con->query($query);
        while($row = $resultRating->fetch_assoc()) {
          $total_user_rating += $row["rating_data"];
          $total_review++;
        }
        if($total_review > 0) {
          $average_rating = $total_user_rating / $total_review;
        }
        $fullStars = floor($average_rating);
        $halfStar = ($average_rating - $fullStars) >= 0.5 ? 1 : 0;
        $emptyStars = 5 - ($fullStars + $halfStar);
        for ($j = 0; $j < $fullStars; $j++) echo '<i class="fas fa-star"></i>';
        if ($halfStar) echo '<i class="fas fa-star-half-alt"></i>';
        for ($j = 0; $j < $emptyStars; $j++) echo '<i class="far fa-star"></i>';
      ?>
    </div>

    <a href="Request.php?wid=<?php echo $row1['shop_id']?>" class="btn">Send Request</a>
  </div>
</div>
<?php } ?>
</div>

<footer>
  © 2025 autoresQ — “Your Drive. Our Duty.”
</footer>

<script src="../asset/JQ/jQuery.js"></script>
<script>
function getPlace(did) {
  $.ajax({
    url: "../asset/AjaxPages/AjaxPlace.php?did=" + did,
    success: function(response){
      $('#place').html(response);
    }
  });
}

function FindShop() {
  var disId = document.getElementById("district").value;
  var pId = document.getElementById("place").value;
  $.ajax({
    url: "../asset/AjaxPages/AjaxSearch.php?disId=" + disId + "&pId=" + pId,
    success: function(response){
      $('#result').html(response);
    }
  });
}
</script>
</body>
</html>
