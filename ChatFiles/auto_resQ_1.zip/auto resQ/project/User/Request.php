<?php
include("../asset/connection/connection.php");
session_start();

$success = false;
$requestData = [];

if (isset($_POST['btn_submit'])) {
  $location = $_POST['txt_location'];
  $vehicle_no = $_POST['txt_vehicleno'];
  $title = $_POST['txt_title'];
  $content = $_POST['txt_content'];
  $category = $_POST['sel_category'];
  $brand = $_POST['sel_brand'];

  $insQry = "INSERT INTO tbl_request(request_location,vehicle_no,request_title,request_content,user_id,workshop_id,request_date,category_id,brand_id)
             VALUES('$location','$vehicle_no','$title','$content','".$_SESSION['uid']."','".$_GET['wid']."',CURDATE(),'$category','$brand')";

  if ($Con->query($insQry)) {
    $success = true;
    $requestData = [
      'location' => $location,
      'vehicle' => $vehicle_no,
      'title' => $title,
      'content' => $content,
      'category' => $category,
      'brand' => $brand,
      'date' => date('Y-m-d')
    ];
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>AutoResQ | New Service Request</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  body {
    font-family: "Poppins", sans-serif;
    background: #fff7f7;
    margin: 0;
    color: #333;
  }
  .navbar {
    background: #b71c1c;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 40px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
  }
  .navbar .logo {
    font-size: 22px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .navbar ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
  }
  .navbar ul li a {
    color: white;
    text-decoration: none;
    font-weight: 500;
    transition: 0.3s;
  }
  .navbar ul li a:hover {
    color: #ffcccc;
  }
  .container {
    max-width: 700px;
    margin: 50px auto;
    background: #ffffff;
    padding: 40px;
    border-radius: 18px;
    box-shadow: 0 6px 25px rgba(183, 28, 28, 0.15);
  }
  .container h2 {
    text-align: center;
    color: #b71c1c;
    font-size: 28px;
    margin-bottom: 25px;
  }
  label {
    font-weight: 600;
    display: block;
    margin-bottom: 6px;
    color: #333;
  }
  input[type="text"], textarea, select {
    width: 100%;
    padding: 10px 12px;
    border: 1.5px solid #ccc;
    border-radius: 8px;
    font-size: 14px;
    margin-bottom: 18px;
    transition: 0.3s;
  }
  input:focus, textarea:focus, select:focus {
    border-color: #b71c1c;
    outline: none;
    box-shadow: 0 0 6px rgba(183, 28, 28, 0.2);
  }
  textarea { resize: vertical; }
  .btn-submit {
    background: #b71c1c;
    color: white;
    border: none;
    padding: 14px 22px;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    width: 100%;
    cursor: pointer;
    transition: 0.3s;
  }
  .btn-submit:hover {
    background: #ff5252;
    transform: translateY(-2px);
  }
  .success-card {
    margin-top: 30px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 6px 25px rgba(183, 28, 28, 0.15);
    padding: 30px;
    text-align: center;
  }
  .success-card i {
    color: #4CAF50;
    font-size: 55px;
    margin-bottom: 10px;
  }
  .success-card h3 {
    color: #4CAF50;
    font-size: 24px;
  }
  .details {
    text-align: left;
    margin-top: 20px;
  }
  .details p {
    font-size: 15px;
    margin: 8px 0;
  }
  .btn-view {
    display: inline-block;
    background: #b71c1c;
    color: white;
    padding: 10px 20px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    transition: 0.3s;
    margin-top: 15px;
  }
  .btn-view:hover {
    background: #ff5252;
  }
</style>
</head>

<body>
  <div class="navbar">
    <div class="logo"><i class="fas fa-car-burst"></i> AutoResQ</div>
    <ul>
      <li><a href="HomePage.php"><i class="fas fa-home"></i> Home</a></li>
      <li><a href="MyRequest.php"><i class="fas fa-clipboard-list"></i> My Requests</a></li>
      <!-- <li><a href="../Guest/Login.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul> -->
  </div>

  <div class="container">
    <h2><i class="fas fa-tools"></i> Submit a Service Request</h2>
    <form method="post" action="">
      <label><i class="fas fa-map-marker-alt"></i> Location</label>
      <textarea required name="txt_location" placeholder="Enter landmark, nearby building, street name..."></textarea>

      <label><i class="fas fa-car-side"></i> Vehicle Number</label>
      <input required type="text" name="txt_vehicleno" placeholder="e.g. KL05 AB 1234" />

      <label><i class="fas fa-heading"></i> Request Title</label>
      <input required type="text" name="txt_title" placeholder="e.g. Engine repair needed" />

      <label><i class="fas fa-align-left"></i> Description</label>
      <textarea name="txt_content" rows="4" placeholder="Describe the issue briefly"></textarea>

      <label><i class="fas fa-cog"></i> Category</label>
      <select required name="sel_category">
        <option value="">Select Category</option>
        <?php
          $catQry = "SELECT * FROM tbl_category";
          $catResult = $Con->query($catQry);
          while($catRow = $catResult->fetch_assoc()) {
            echo "<option value='".$catRow['category_id']."'>".$catRow['category_name']."</option>";
          }
        ?>
      </select>

      <label><i class="fas fa-tags"></i> Brand</label>
      <select required name="sel_brand">
        <option value="">Select Brand</option>
        <?php
          $brandQry = "SELECT * FROM tbl_brand";
          $brandResult = $Con->query($brandQry);
          while($brandRow = $brandResult->fetch_assoc()) {
            echo "<option value='".$brandRow['brand_id']."'>".$brandRow['brand_name']."</option>";
          }
        ?>
      </select>

      <button type="submit" name="btn_submit" class="btn-submit"><i class="fas fa-paper-plane"></i> Submit Request</button>
    </form>

    <?php if ($success) { ?>
    <div class="success-card">
      <i class="fas fa-check-circle"></i>
      <h3>Request Submitted Successfully!</h3>
      <p>Your request has been recorded and will be reviewed shortly.</p>
      <div class="details">
        <p><strong>📍 Location:</strong> <?php echo htmlspecialchars($requestData['location']); ?></p>
        <p><strong>🚗 Vehicle No:</strong> <?php echo htmlspecialchars($requestData['vehicle']); ?></p>
        <p><strong>🧰 Title:</strong> <?php echo htmlspecialchars($requestData['title']); ?></p>
        <p><strong>📝 Description:</strong> <?php echo nl2br(htmlspecialchars($requestData['content'])); ?></p>
        <p><strong>🏷️ Category ID:</strong> <?php echo htmlspecialchars($requestData['category']); ?></p>
        <p><strong>🚘 Brand ID:</strong> <?php echo htmlspecialchars($requestData['brand']); ?></p>
        <p><strong>📅 Date:</strong> <?php echo htmlspecialchars($requestData['date']); ?></p>
      </div>
      <a href="MyRequest.php" class="btn-view"><i class="fas fa-clipboard-list"></i> View My Requests</a>
    </div>
    <?php } ?>
  </div>
</body>
</html>
