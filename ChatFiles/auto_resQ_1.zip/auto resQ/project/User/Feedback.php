<?php
include("../asset/connection/connection.php");
session_start();

if (isset($_POST['btn'])) {
    $content = $_POST['content'];
    $insQry = "INSERT INTO tbl_feedback(feedback_content,user_id) VALUES('$content','" . $_SESSION['uid'] . "')";
    if ($Con->query($insQry)) {
        echo "<script>
                alert('Feedback submitted successfully!');
                window.location='Feedback.php';
              </script>";
    }
}

if (isset($_GET['did'])) {
    $delQry = "DELETE FROM tbl_feedback WHERE feedback_id='" . $_GET['did'] . "'";
    if ($Con->query($delQry)) {
        echo "<script>
                alert('Feedback deleted successfully!');
                window.location='Feedback.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoresQ | Feedback</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #111, #b51212);
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        flex-direction: column;
        color: #333;
    }

    .feedback-container {
        background: rgba(255, 255, 255, 0.95);
        width: 900px;
        border-radius: 18px;
        overflow: hidden;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        padding: 40px;
        margin: 20px;
    }

    h1 {
        text-align: center;
        color: #b51212;
        font-size: 30px;
        font-weight: 700;
        margin-bottom: 25px;
    }

    form {
        width: 100%;
    }

    label {
        font-weight: 500;
        color: #444;
    }

    textarea {
        width: 100%;
        padding: 12px;
        border: 1.5px solid #bbb;
        border-radius: 10px;
        resize: none;
        font-family: 'Poppins', sans-serif;
        font-size: 15px;
        transition: 0.3s;
    }

    textarea:focus {
        border-color: #b51212;
        box-shadow: 0 0 6px rgba(181, 18, 18, 0.3);
        outline: none;
    }

    .btn-submit {
        display: block;
        margin-top: 15px;
        width: 100%;
        padding: 12px;
        background: #b51212;
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 17px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s, transform 0.2s;
    }

    .btn-submit:hover {
        background: #8d0f0f;
        transform: scale(1.03);
    }

    .feedback-table {
        margin-top: 40px;
        width: 100%;
        border-collapse: collapse;
    }

    .feedback-table th,
    .feedback-table td {
        border: 1px solid #ddd;
        padding: 12px 10px;
        text-align: center;
        font-size: 15px;
    }

    .feedback-table th {
        background: #b51212;
        color: white;
    }

    .feedback-table tr:nth-child(even) {
        background: #f9f9f9;
    }

    .feedback-table tr:hover {
        background: #f2f2f2;
    }

    .delete-btn {
        background: #b51212;
        color: #fff;
        padding: 6px 12px;
        border-radius: 6px;
        text-decoration: none;
        font-size: 14px;
        transition: 0.3s;
    }

    .delete-btn:hover {
        background: #8d0f0f;
    }

    @media (max-width: 850px) {
        .feedback-container {
            width: 90%;
            padding: 25px;
        }

        .feedback-table td,
        .feedback-table th {
            font-size: 13px;
            padding: 8px;
        }
    }
</style>
</head>
<body>

<div class="feedback-container">
    <h1>User Feedback</h1>

    <form method="post">
        <label for="content">Your Feedback</label>
        <textarea name="content" id="content" rows="4" required></textarea>
        <button type="submit" name="btn" class="btn-submit">Submit Feedback</button>
    </form>

    <table class="feedback-table">
        <tr>
            <th>SL No</th>
            <th>Feedback Content</th>
            <th>Action</th>
        </tr>
        <?php
        $i = 0;
        $selQry = "SELECT * FROM tbl_feedback WHERE user_id='" . $_SESSION['uid'] . "'";
        $result = $Con->query($selQry);
        while ($row = $result->fetch_assoc()) {
            $i++;
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $row['feedback_content']; ?></td>
                <td><a class="delete-btn" href="Feedback.php?did=<?php echo $row['feedback_id']; ?>">Delete</a></td>
            </tr>
            <?php
        }
        ?>
    </table>
</div>

</body>
</html>
