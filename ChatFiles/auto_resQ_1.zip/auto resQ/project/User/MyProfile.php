<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * 
           FROM tbl_user u 
           INNER JOIN tbl_place p ON u.place_id = p.place_id 
           INNER JOIN tbl_district d ON p.district_id = d.district_id 
           WHERE user_id = " . $_SESSION['uid'];
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Profile | AutoresQ</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
  margin: 0;
  padding: 0;
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #1c1c1c, #3a3a3a);
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

/* Glassmorphism Profile Card */
.profile-container {
  background: rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 20px;
  padding: 40px 35px 50px;
  width: 420px;
  box-shadow: 0 8px 30px rgba(0,0,0,0.4);
  color: #fff;
  text-align: center;
  position: relative;
  transition: all 0.4s ease;
}

.profile-container:hover {
  transform: translateY(-8px);
  box-shadow: 0 12px 40px rgba(0,0,0,0.6);
}

/* Logo section */
.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-bottom: 10px;
}
.logo span {
  font-size: 26px;
  font-weight: 700;
  color: #ff2b2b;
  letter-spacing: 1px;
}

/* Profile Image */
.profile-container img {
  width: 170px;
  height: 170px;
  border-radius: 50%;
  border: 4px solid transparent;
  background: linear-gradient(white, white) padding-box,
              linear-gradient(135deg, #ff2b2b, #b51212) border-box;
  object-fit: cover;
  box-shadow: 0 6px 25px rgba(0,0,0,0.4);
  margin-bottom: 15px;
}

/* Name */
.profile-container h2 {
  font-size: 22px;
  color: #fff;
  margin-bottom: 5px;
  font-weight: 600;
}

/* Info Table */
.profile-info {
  margin-top: 20px;
  text-align: left;
  font-size: 15px;
}

.profile-info table {
  width: 100%;
  border-collapse: collapse;
}

.profile-info td {
  padding: 10px;
  border-bottom: 1px solid rgba(255,255,255,0.2);
}

.profile-info td:first-child {
  color: #ff5757;
  font-weight: 600;
  width: 40%;
  text-transform: capitalize;
}

.profile-info td:last-child {
  color: #eee;
}

/* Back Button */
.btn-back {
  display: inline-block;
  margin-top: 25px;
  padding: 10px 25px;
  border-radius: 30px;
  background: linear-gradient(135deg, #b51212, #ff2b2b);
  color: #fff;
  text-decoration: none;
  font-weight: 600;
  letter-spacing: 0.5px;
  transition: all 0.3s ease;
  box-shadow: 0 5px 15px rgba(255,0,0,0.3);
}

.btn-back:hover {
  background: linear-gradient(135deg, #ff2b2b, #b51212);
  box-shadow: 0 8px 25px rgba(255,0,0,0.4);
}

/* Accent Glow behind card */
.profile-container::before {
  content: '';
  position: absolute;
  top: -20px;
  left: -20px;
  right: -20px;
  bottom: -20px;
  background: radial-gradient(circle at top left, rgba(255,0,0,0.2), transparent 70%);
  z-index: -1;
  border-radius: 25px;
}
</style>
</head>
<body>

<div class="profile-container">
  <div class="logo">
    <span>autoresQ</span>
  </div>

  <img src="../asset/Files/User/Photo/<?php echo $row['user_photo']; ?>" alt="Profile Photo">

  <h2><?php echo $row['user_name']; ?></h2>

  <div class="profile-info">
    <table>
      <tr>
        <td>Email</td>
        <td><?php echo $row['user_email']; ?></td>
      </tr>
      <tr>
        <td>Contact</td>
        <td><?php echo $row['user_contact']; ?></td>
      </tr>
      <tr>
        <td>Address</td>
        <td><?php echo $row['user_address']; ?></td>
      </tr>
      <tr>
        <td>District</td>
        <td><?php echo $row['district_name']; ?></td>
      </tr>
      <tr>
        <td>Place</td>
        <td><?php echo $row['place_name']; ?></td>
      </tr>
    </table>
  </div>

  <a href="../User/Homepage.php" class="btn-back">← Back to Home</a>
</div>

</body>
</html>
