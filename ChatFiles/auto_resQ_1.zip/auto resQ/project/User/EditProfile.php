<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * FROM tbl_user WHERE user_id='" . $_SESSION['uid'] . "'";
$row = $Con->query($SelQry);
$data = $row->fetch_assoc();

if (isset($_POST['btn'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];

    $UpQry = "UPDATE tbl_user 
              SET user_name='$name', user_email='$email', user_contact='$contact', user_address='$address' 
              WHERE user_id='" . $_SESSION['uid'] . "'";

    if ($Con->query($UpQry)) {
        echo "<script>
                alert('Profile updated successfully!');
                window.location='MyProfile.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoresQ | Update Profile</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

<style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #111, #b51212);
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .profile-wrapper {
        width: 900px;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 18px;
        overflow: hidden;
        display: flex;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    }

    /* LEFT SIDE */
    .profile-side {
        width: 40%;
        background: linear-gradient(135deg, #b51212, #7a0a0a);
        color: #fff;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 40px;
        text-align: center;
        position: relative;
    }

    .profile-side::after {
        content: "";
        position: absolute;
        width: 250px;
        height: 250px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.1);
        top: -70px;
        right: -70px;
    }

    .profile-side h1 {
        font-size: 45px;
        margin-bottom: 10px;
        letter-spacing: 2px;
    }

    .profile-side p {
        font-size: 15px;
        color: #f5f5f5;
        line-height: 1.5;
    }

    /* RIGHT SIDE */
    .profile-form {
        width: 60%;
        padding: 50px;
    }

    .profile-form h2 {
        text-align: center;
        color: #b51212;
        font-size: 26px;
        margin-bottom: 30px;
        font-weight: 700;
    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        display: block;
        font-weight: 500;
        margin-bottom: 5px;
        color: #444;
    }

    input, textarea {
        width: 100%;
        padding: 12px 14px;
        border-radius: 10px;
        border: 1.5px solid #bbb;
        font-size: 15px;
        transition: all 0.3s ease;
        font-family: 'Poppins', sans-serif;
    }

    input:focus, textarea:focus {
        border-color: #b51212;
        outline: none;
        box-shadow: 0 0 6px rgba(181,18,18,0.3);
    }

    textarea {
        resize: none;
    }

    .btn-submit {
        width: 100%;
        padding: 12px;
        background: #b51212;
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 17px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s ease, transform 0.2s;
    }

    .btn-submit:hover {
        background: #8d0f0f;
        transform: scale(1.03);
    }

    @media (max-width: 850px) {
        .profile-wrapper {
            flex-direction: column;
            width: 90%;
        }

        .profile-side {
            width: 100%;
            height: 200px;
        }

        .profile-form {
            width: 100%;
            padding: 30px 20px;
        }
    }
</style>
</head>
<body>

<div class="profile-wrapper">
    <div class="profile-side">
        <h1>autoresQ</h1>
        <p>Update your details to keep your<br>account up to date.</p>
    </div>

    <div class="profile-form">
        <h2>Update Profile</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input required type="text" name="name" id="name"
                       pattern="^[A-Z][a-zA-Z ]*$"
                       title="Only letters, spaces, first letter capitalized"
                       value="<?php echo $data['user_name']; ?>" />
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input required type="email" name="email" id="email"
                       value="<?php echo $data['user_email']; ?>" />
            </div>

            <div class="form-group">
                <label for="contact">Contact</label>
                <input required type="text" name="contact" id="contact"
                       pattern="[7-9]{1}[0-9]{9}"
                       title="Phone number must start with 7-9 and have 10 digits total"
                       value="<?php echo $data['user_contact']; ?>" />
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea required name="address" id="address" rows="3"><?php echo $data['user_address']; ?></textarea>
            </div>

            <button type="submit" class="btn-submit" name="btn">UPDATE PROFILE</button>
        </form>
    </div>
</div>

</body>
</html>
