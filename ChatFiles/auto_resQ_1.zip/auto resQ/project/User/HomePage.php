<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * FROM tbl_user WHERE user_id=" . $_SESSION['uid'];
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();

$workshopCount = $Con->query("SELECT COUNT(*) AS c FROM tbl_workshop")->fetch_assoc()['c'];
$feedbackCount = $Con->query("SELECT COUNT(*) AS c FROM tbl_feedback WHERE user_id=" . $_SESSION['uid'])->fetch_assoc()['c'];
$complaintCount = $Con->query("SELECT COUNT(*) AS c FROM tbl_complaint WHERE user_id=" . $_SESSION['uid'])->fetch_assoc()['c'];
$requestCount = $Con->query("SELECT COUNT(*) AS c FROM tbl_request WHERE user_id=" . $_SESSION['uid'])->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>autoresQ | Dashboard</title>
<link rel="icon" type="image/png" href="../asset/logo/autoresQ_logo.png" />
<link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
:root {
  --primary: #e53935;
  --accent: #ff5252;
  --dark: #0b0b0b;
  --card-bg: rgba(255,255,255,0.08);
  --text: #fff;
  --muted: #bbb;
}

body {
  margin: 0;
  font-family: "Poppins", sans-serif;
  background: linear-gradient(120deg, #000000, #250000);
  color: var(--text);
  overflow-x: hidden;
}

/* ===== HEADER ===== */
header {
  background: rgba(0,0,0,0.9);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 18px 50px;
  border-bottom: 2px solid var(--accent);
  flex-wrap: wrap;
}
.logo {
  display: flex;
  align-items: center;
  gap: 10px;
}
.logo img {
  width: 55px;
  height: auto;
  filter: drop-shadow(0 0 8px var(--accent));
}
.logo h1 {
  font-size: 28px;
  color: var(--accent);
  margin: 0;
}
.welcome {
  font-size: 16px;
  color: var(--muted);
}

/* ===== FEATURE HUB ===== */
.feature-hub {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 25px;
  background: rgba(10,10,10,0.95);
  padding: 30px 15px;
  border-bottom: 2px solid var(--accent);
}
.feature-card {
  background: var(--card-bg);
  color: var(--text);
  width: 170px;
  text-align: center;
  padding: 28px 22px;
  border-radius: 18px;
  text-decoration: none;
  transition: 0.3s ease;
  box-shadow: 0 0 10px rgba(255,0,0,0.15);
  position: relative;
}
.feature-card:hover {
  background: linear-gradient(145deg, #e53935, #b71c1c);
  transform: translateY(-8px);
  box-shadow: 0 0 25px rgba(255,0,0,0.4);
}
.feature-card i {
  font-size: 42px;
  margin-bottom: 8px;
  color: var(--accent);
  transition: 0.3s;
}
.feature-card:hover i {
  color: #fff;
  transform: scale(1.2);
}
.feature-card span {
  display: block;
  font-size: 15px;
  font-weight: 600;
}
.feature-info {
  font-size: 12px;
  color: var(--muted);
  margin-top: 5px;
}

/* ===== ABOUT ===== */
.about {
  max-width: 1100px;
  margin: 40px auto;
  background: var(--card-bg);
  border-radius: 20px;
  padding: 40px;
  text-align: center;
  box-shadow: 0 0 20px rgba(255,0,0,0.2);
}
.about h2 {
  color: var(--accent);
  font-size: 28px;
  margin-bottom: 15px;
}
.about p {
  color: #ccc;
  font-size: 16px;
  line-height: 1.7;
}

/* ===== DASHBOARD CARDS ===== */
.dashboard {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 25px;
  padding: 20px 40px;
  max-width: 1100px;
  margin: 0 auto 60px;
}
.card {
  background: var(--card-bg);
  border-radius: 18px;
  padding: 25px;
  text-align: center;
  transition: 0.3s;
  box-shadow: 0 0 15px rgba(255,0,0,0.1);
}
.card:hover {
  transform: translateY(-8px);
  box-shadow: 0 0 25px rgba(255,0,0,0.3);
}
.card i {
  font-size: 45px;
  color: var(--accent);
  margin-bottom: 10px;
}
.card h2 {
  font-size: 36px;
  margin: 5px 0;
}
.card span {
  font-size: 15px;
  color: #aaa;
}

/* ===== CHARTS ===== */
.charts {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 30px;
  padding: 40px;
  max-width: 1200px;
  margin: 0 auto;
}
.chart-card {
  background: var(--card-bg);
  border-radius: 20px;
  padding: 25px;
  width: 480px;
  box-shadow: 0 0 15px rgba(255,0,0,0.1);
}
.chart-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 0 25px rgba(255,0,0,0.25);
}
.chart-card h3 {
  text-align: center;
  color: var(--accent);
  font-size: 20px;
  margin-bottom: 10px;
}

/* ===== FOOTER ===== */
footer {
  background: rgba(0,0,0,0.9);
  color: #ccc;
  text-align: center;
  padding: 18px 0;
  font-size: 14px;
  border-top: 2px solid var(--accent);
}
</style>
</head>
<body>

<header>
  <div class="logo">
    <img src="../asset/logo/autoresQ_logo.png" alt="autoresQ logo">
    <h1>autoresQ</h1>
  </div>
  <div class="welcome">Welcome, <?php echo $row['user_name']; ?> 👋</div>
</header>

<!-- Feature Hub Section -->
<div class="feature-hub">
  <a href="MyProfile.php" class="feature-card">
    <i class="ri-user-3-line"></i>
    <span>My Profile</span>
    <div class="feature-info">View and manage your info</div>
  </a>
  <a href="EditProfile.php" class="feature-card">
    <i class="ri-edit-2-line"></i>
    <span>Edit Profile</span>
    <div class="feature-info">Update personal details</div>
  </a>
  <a href="ChangePassword.php" class="feature-card">
    <i class="ri-lock-password-line"></i>
    <span>Change Password</span>
    <div class="feature-info">Keep your account secure</div>
  </a>
  <a href="ViewWorkShop.php" class="feature-card">
    <i class="ri-tools-line"></i>
    <span>Workshops</span>
    <div class="feature-info">Explore available workshops</div>
  </a>
  <a href="MyRequest.php" class="feature-card">
    <i class="ri-list-check"></i>
    <span>My Requests</span>
    <div class="feature-info">Track your service requests</div>
  </a>
  <a href="Complaint.php" class="feature-card">
    <i class="ri-error-warning-line"></i>
    <span>Complaints</span>
    <div class="feature-info">Submit or view issues</div>
  </a>
  <a href="Feedback.php" class="feature-card">
    <i class="ri-feedback-line"></i>
    <span>Feedback</span>
    <div class="feature-info">Share your experience</div>
  </a>
  <a href="../Guest/Logout.php" class="feature-card">
    <i class="ri-logout-box-line"></i>
    <span>Logout</span>
    <div class="feature-info">Exit your session</div>
  </a>
</div>

<section class="about">
  <h2>About autoresQ</h2>
  <p>
    <strong>autoresQ</strong> is your digital roadside companion — connecting drivers with nearby 
    workshops and assistance instantly. From emergencies to maintenance and customer feedback, 
    we make your journey safer and more reliable.  
    <em>“Your Drive. Our Duty.”</em>
  </p>
</section>

<section class="dashboard">
  <div class="card">
    <i class="ri-tools-line"></i>
    <h2><?php echo $workshopCount; ?></h2>
    <span>Workshops Available</span>
  </div>
  <div class="card">
    <i class="ri-feedback-line"></i>
    <h2><?php echo $feedbackCount; ?></h2>
    <span>My Feedbacks</span>
  </div>
  <div class="card">
    <i class="ri-error-warning-line"></i>
    <h2><?php echo $complaintCount; ?></h2>
    <span>My Complaints</span>
  </div>
  <div class="card">
    <i class="ri-list-check"></i>
    <h2><?php echo $requestCount; ?></h2>
    <span>My Requests</span>
  </div>
</section>

<section class="charts">
  <div class="chart-card">
    <h3>My Activity Overview</h3>
    <canvas id="barChart"></canvas>
  </div>
  <div class="chart-card">
    <h3>Activity Distribution</h3>
    <canvas id="pieChart"></canvas>
  </div>
</section>

<footer>
  © 2025 autoresQ — Driven by Safety, Powered by Innovation.
</footer>

<script>
const ctxBar = document.getElementById('barChart').getContext('2d');
new Chart(ctxBar, {
  type: 'bar',
  data: {
    labels: ['Workshops', 'Feedbacks', 'Complaints', 'Requests'],
    datasets: [{
      label: 'User Activity',
      data: [<?php echo $workshopCount; ?>, <?php echo $feedbackCount; ?>, <?php echo $complaintCount; ?>, <?php echo $requestCount; ?>],
      backgroundColor: ['#ff5252cc', '#ff1744cc', '#ff8a80cc', '#ff3d00cc'],
      borderRadius: 10
    }]
  },
  options: {
    responsive: true,
    scales: { 
      y: { beginAtZero: true, ticks: { color: '#fff' }, grid: { color: '#333' } },
      x: { ticks: { color: '#fff' }, grid: { color: '#333' } } 
    },
    plugins: { legend: { display: false } }
  }
});

const ctxPie = document.getElementById('pieChart').getContext('2d');
new Chart(ctxPie, {
  type: 'doughnut',
  data: {
    labels: ['Workshops', 'Feedbacks', 'Complaints', 'Requests'],
    datasets: [{
      data: [<?php echo $workshopCount; ?>, <?php echo $feedbackCount; ?>, <?php echo $complaintCount; ?>, <?php echo $requestCount; ?>],
      backgroundColor: ['#ff5252', '#ff1744', '#ff8a80', '#ff3d00']
    }]
  },
  options: {
    responsive: true,
    cutout: '70%',
    plugins: { legend: { position: 'bottom', labels: { color: '#fff' } } }
  }
});
</script>

</body>
</html>
