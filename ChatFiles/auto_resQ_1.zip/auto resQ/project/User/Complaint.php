<?php
include("../asset/connection/connection.php");
session_start();

if(isset($_POST['btn'])) {
  $title = $_POST['title'];
  $content = $_POST['content'];
  $insQry = "INSERT INTO tbl_complaint(complaint_title, complaint_content, user_id, complaint_date)
             VALUES('$title', '$content', '".$_SESSION['uid']."', CURDATE())";
  if($Con->query($insQry)) {
    echo "<script>alert('Complaint submitted successfully!'); window.location='Complaint.php';</script>";
  }
}

if(isset($_GET['did'])) {	 
  $delQry = "DELETE FROM tbl_complaint WHERE complaint_id='".$_GET['did']."'";
  if($Con->query($delQry)) {
    echo "<script>alert('Complaint deleted successfully!'); window.location='Complaint.php';</script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>AutoResQ | Complaints</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  body {
    font-family: "Poppins", sans-serif;
    background: #fff7f7;
    margin: 0;
    padding: 0;
    color: #333;
  }

  /* ===== Navbar ===== */
  .navbar {
    background-color: #b71c1c;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 40px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  }

  .navbar .logo {
    font-size: 22px;
    font-weight: 700;
    letter-spacing: 1px;
  }

  .navbar .logo i {
    margin-right: 8px;
  }

  .navbar ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    gap: 25px;
  }

  .navbar ul li a {
    text-decoration: none;
    color: white;
    font-weight: 500;
    transition: 0.3s;
  }

  .navbar ul li a:hover {
    color: #ffcccc;
  }

  /* ===== Page Container ===== */
  .container {
    max-width: 950px;
    margin: 50px auto;
    padding: 0 20px;
  }

  h2 {
    color: #b71c1c;
    text-align: center;
    margin-bottom: 8px;
  }

  p.subtitle {
    text-align: center;
    color: #666;
    font-size: 14px;
    margin-bottom: 25px;
  }

  /* ===== Complaint Form ===== */
  form {
    background: #fff;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 5px 15px rgba(183, 28, 28, 0.15);
    margin-bottom: 35px;
  }

  label {
    font-weight: 500;
    color: #444;
  }

  input[type="text"],
  textarea {
    width: 100%;
    padding: 12px;
    border: 1.5px solid #ccc;
    border-radius: 10px;
    outline: none;
    transition: 0.3s;
    font-size: 14px;
    margin-top: 5px;
  }

  input[type="text"]:focus,
  textarea:focus {
    border-color: #b71c1c;
    box-shadow: 0 0 5px rgba(183, 28, 28, 0.4);
  }

  textarea {
    resize: none;
    height: 100px;
  }

  .submit-btn {
    background: #b71c1c;
    color: #fff;
    border: none;
    padding: 10px 25px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 15px;
    margin-top: 15px;
    transition: 0.3s;
  }

  .submit-btn:hover {
    background: #ff5252;
    transform: translateY(-2px);
  }

  /* ===== Complaints Grid ===== */
  .complaints {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 20px;
  }

  .card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 6px 16px rgba(183, 28, 28, 0.15);
    padding: 20px;
    transition: 0.3s;
    border-top: 4px solid #b71c1c;
    opacity: 0;
    transform: translateY(10px);
    animation: fadeIn 0.6s ease forwards;
  }

  @keyframes fadeIn {
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .card:hover {
    transform: translateY(-6px);
    box-shadow: 0 10px 25px rgba(183, 28, 28, 0.2);
  }

  .card h4 {
    color: #b71c1c;
    margin-bottom: 8px;
  }

  .card p {
    font-size: 14px;
    color: #333;
    margin: 4px 0;
  }

  /* Status color coding */
  .status {
    font-weight: 600;
    margin-top: 8px;
  }
  .status.pending {
    color: #777;
  }
  .status.replied {
    color: #2e7d32;
  }

  /* Delete button */
  .delete-btn {
    background: #b71c1c;
    color: #fff;
    border: none;
    padding: 7px 15px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 13px;
    text-decoration: none;
    display: inline-block;
    margin-top: 10px;
    transition: 0.3s;
  }

  .delete-btn:hover {
    background: #ff5252;
  }

  .no-data {
    text-align: center;
    color: #b71c1c;
    background: #fff0f0;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(183, 28, 28, 0.1);
    margin-top: 20px;
  }
</style>
</head>

<body>
  <!-- ===== Top Navigation Bar ===== -->
  <div class="navbar">
    <div class="logo"><i class="fas fa-car-burst"></i> AutoResQ</div>
    <ul>
      <li><a href="Home.php"><i class="fas fa-home"></i> Home</a></li>
      <li><a href="Profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
      <li><a href="../Guest/Login.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
  </div>

  <!-- ===== Main Content ===== -->
  <div class="container">
    <h2><i class="fas fa-comments"></i> Submit a Complaint</h2>
    <p class="subtitle">We value your feedback — share your issue or suggestion below.</p>

    <form method="post" action="">
      <label for="title">Complaint Title</label>
      <input type="text" name="title" id="title" required placeholder="Enter your complaint title">

      <label for="content">Complaint Details</label>
      <textarea name="content" id="content" required placeholder="Describe your issue here..."></textarea>

      <button type="submit" name="btn" class="submit-btn">
        <i class="fas fa-paper-plane"></i> Submit Complaint
      </button>
    </form>

    <h2><i class="fas fa-list"></i> Your Complaints</h2>
    <p class="subtitle">Below are all complaints you have submitted.</p>

    <div class="complaints">
      <?php
      $selQry = "SELECT * FROM tbl_complaint WHERE user_id='".$_SESSION['uid']."' ORDER BY complaint_id DESC";
      $result = $Con->query($selQry);

      if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
          $statusClass = $row['complaint_status']==0 ? 'pending' : 'replied';
          ?>
          <div class="card">
            <h4><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($row['complaint_title']); ?></h4>
            <p><?php echo nl2br(htmlspecialchars($row['complaint_content'])); ?></p>
            <p><strong>Date:</strong> <?php echo $row['complaint_date']; ?></p>
            <p class="status <?php echo $statusClass; ?>">
              <?php 
                if($row['complaint_status']==0)
                  echo "<i class='fas fa-hourglass-half'></i> Not Replied";
                else
                  echo "<i class='fas fa-check-circle'></i> " . htmlspecialchars($row['complaint_reply']);
              ?>
            </p>
            <a href="Complaint.php?did=<?php echo $row['complaint_id']; ?>" 
               class="delete-btn"
               onclick="return confirm('Are you sure you want to delete this complaint?');">
               <i class="fas fa-trash"></i> Delete
            </a>
          </div>
          <?php
        }
      } else {
        echo '<div class="no-data"><i class="fas fa-info-circle"></i> No complaints found.</div>';
      }
      ?>
    </div>
  </div>
</body>
</html>
