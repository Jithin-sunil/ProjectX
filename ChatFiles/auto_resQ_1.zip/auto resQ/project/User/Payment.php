<?php
session_start();
ob_start();
include("../asset/Connection/Connection.php");

if (isset($_GET["rid"])) {
    $_SESSION["rid"] = $_GET["rid"];
}

$paymentSuccess = false;

if (isset($_POST["btn_pay"])) {
    $update = "UPDATE tbl_request SET request_status='6' WHERE request_id='" . $_SESSION["rid"] . "'";
    if ($Con->query($update)) {
        $paymentSuccess = true;
    } else {
        echo "<script>alert('Payment Failed');</script>";
    }
}

$selRequest = "SELECT * FROM tbl_request WHERE request_id='" . $_SESSION["rid"] . "'";
$rowRequest = $Con->query($selRequest);
$Request = $rowRequest->fetch_assoc();
$amount = $Request['request_amount'];
$requestId = $Request['request_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ | Payment</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ======== GLOBAL ======== */
body {
  font-family: "Poppins", sans-serif;
  background: radial-gradient(circle at top, #2b0000, #000);
  color: #fff;
  margin: 0;
  overflow-x: hidden;
}

/* ======== NAVBAR ======== */
.navbar {
  background: rgba(20, 20, 20, 0.95);
  padding: 15px 50px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 2px solid rgba(255, 0, 0, 0.4);
  box-shadow: 0 2px 15px rgba(255, 0, 0, 0.2);
  position: sticky;
  top: 0;
  z-index: 10;
}
.navbar .logo {
  color: #ff3333;
  font-size: 22px;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 8px;
}
.navbar ul {
  list-style: none;
  display: flex;
  gap: 25px;
  margin: 0;
}
.navbar ul li a {
  color: #fff;
  text-decoration: none;
  font-weight: 500;
  transition: 0.3s;
}
.navbar ul li a:hover {
  color: #ff3333;
}

/* ======== CONTAINER ======== */
.container {
  max-width: 700px;
  margin: 80px auto;
  padding: 20px;
  text-align: center;
}

/* ======== CARD PREVIEW ======== */
.card-preview {
  perspective: 1000px;
  width: 100%;
  height: 220px;
  margin-bottom: 40px;
  position: relative;
}
.card-inner {
  width: 100%;
  height: 100%;
  transition: transform 0.8s;
  transform-style: preserve-3d;
  position: relative;
}
.card-preview.flip .card-inner {
  transform: rotateY(180deg);
}
.card-front, .card-back {
  position: absolute;
  width: 100%;
  height: 100%;
  border-radius: 15px;
  backface-visibility: hidden;
  background: linear-gradient(145deg, #ff3333, #1c0000);
  box-shadow: 0 0 20px rgba(255, 0, 0, 0.4);
  color: #fff;
  padding: 20px;
}
.card-front {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.card-front .logo {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.card-front .card-number {
  font-size: 22px;
  letter-spacing: 3px;
}
.card-front .card-info {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  margin-top: 10px;
}
.card-back {
  transform: rotateY(180deg);
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 40px 20px;
}
.card-back .cvv {
  background: rgba(255,255,255,0.2);
  border-radius: 5px;
  width: 80px;
  margin: 0 auto;
  text-align: center;
  padding: 10px;
  font-weight: bold;
}

/* ======== FORM ======== */
form {
  background: rgba(255, 255, 255, 0.07);
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 0 25px rgba(255, 0, 0, 0.2);
  backdrop-filter: blur(10px);
}
label {
  text-align: left;
  display: block;
  margin-top: 15px;
  font-size: 14px;
  color: #ff9999;
}
input[type="text"] {
  width: 100%;
  padding: 12px;
  margin-top: 5px;
  border: none;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.1);
  color: white;
  font-size: 15px;
  outline: none;
  transition: 0.3s;
}
input[type="text"]:focus {
  background: rgba(255, 255, 255, 0.2);
  box-shadow: 0 0 10px rgba(255, 0, 0, 0.4);
}
.row {
  display: flex;
  gap: 15px;
  margin-top: 10px;
}
.amount-box {
  background: linear-gradient(135deg, #b71c1c, #ff5252);
  padding: 15px;
  border-radius: 10px;
  margin-top: 25px;
  font-weight: bold;
  box-shadow: 0 0 20px rgba(255, 0, 0, 0.4);
}
.btn-pay {
  margin-top: 25px;
  width: 100%;
  padding: 15px;
  border: none;
  border-radius: 10px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  color: #fff;
  background: #ff3333;
  transition: 0.3s;
}
.btn-pay:hover {
  background: #ff6666;
  transform: scale(1.02);
}
.card-icons {
  margin-top: 20px;
  font-size: 35px;
  display: flex;
  justify-content: center;
  gap: 15px;
  color: #ffcccc;
}
.card-icons i:hover {
  color: #fff;
  transform: scale(1.2);
}

/* ======== PROCESSING SCREEN ======== */
.processing-screen,
.success-screen {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.95);
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  animation: fadeIn 0.6s ease;
  z-index: 9999;
}
.ring {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  border: 8px solid transparent;
  border-top: 8px solid #ff3333;
  animation: spin 1s linear infinite;
}
.processing-text {
  margin-top: 25px;
  font-size: 22px;
  color: #ff6666;
  font-weight: 600;
  letter-spacing: 1px;
}

/* ======== SUCCESS SCREEN ======== */
.checkmark {
  width: 140px;
  height: 140px;
  border-radius: 50%;
  border: 6px solid #4CAF50;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: popIn 0.4s ease forwards;
}
.checkmark i {
  color: #4CAF50;
  font-size: 70px;
}
.success-text {
  margin-top: 25px;
  font-size: 24px;
  color: #4CAF50;
  font-weight: 700;
  text-align: center;
}
.subtext {
  color: #aaa;
  margin-top: 8px;
  font-size: 16px;
}

@keyframes fadeIn { from {opacity:0;} to {opacity:1;} }
@keyframes popIn { from {transform:scale(0.4); opacity:0;} to {transform:scale(1); opacity:1;} }
@keyframes spin { from {transform: rotate(0deg);} to {transform: rotate(360deg);} }

/* ======== RESPONSIVE ======== */
@media (max-width: 600px) {
  .navbar { padding: 10px 20px; }
  .card-front .card-number { font-size: 18px; }
  .row { flex-direction: column; }
}
</style>
</head>

<body>
<div class="navbar">
  <div class="logo"><i class="fas fa-car-burst"></i> AutoResQ</div>
  <ul>
    <li><a href="Home.php"><i class="fas fa-home"></i> Home</a></li>
    <li><a href="MyRequest.php"><i class="fas fa-list"></i> My Requests</a></li>
    <li><a href="../Guest/Login.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  </ul>
</div>

<div class="container">
  <div class="card-preview" id="cardPreview">
    <div class="card-inner">
      <div class="card-front">
        <div class="logo">
          <i class="fa-solid fa-car-side"></i>
          <i class="fa-brands fa-cc-visa"></i>
        </div>
        <div class="card-number" id="displayNumber">XXXX XXXX XXXX XXXX</div>
        <div class="card-info">
          <div id="displayName">CARD HOLDER</div>
          <div id="displayExp">MM/YY</div>
        </div>
      </div>
      <div class="card-back">
        <div class="cvv" id="displayCVV">***</div>
      </div>
    </div>
  </div>

  <form method="post" id="paymentForm">
    <label>Card Number</label>
    <input type="text" id="cardNumber" name="txtacno" placeholder="XXXX XXXX XXXX XXXX" maxlength="19" required>

    <label>Name on Card</label>
    <input type="text" id="cardName" name="txtname" placeholder="Full Name" required>

    <div class="row">
      <div style="flex:1;">
        <label>Expiry (MM/YY)</label>
        <input type="text" id="cardExp" name="txtexpdate" placeholder="MM/YY" maxlength="5" required>
      </div>
      <div style="flex:1;">
        <label>CVV</label>
        <input type="text" id="cardCVV" name="txtccv" placeholder="XXX" maxlength="3" required>
      </div>
    </div>

    <div class="amount-box">Payable Amount: ₹<?php echo number_format($amount,2); ?></div>

    <button type="submit" name="btn_pay" class="btn-pay"><i class="fas fa-lock"></i> Pay Securely</button>
  </form>

  <div class="card-icons">
    <i class="fa-brands fa-cc-visa"></i>
    <i class="fa-brands fa-cc-mastercard"></i>
    <i class="fa-brands fa-cc-paypal"></i>
    <i class="fa-brands fa-google-pay"></i>
  </div>
</div>

<!-- Processing Animation -->
<div class="processing-screen" id="processingScreen" style="display:none;">
  <div class="ring"></div>
  <div class="processing-text">Processing Payment...</div>
</div>

<?php if ($paymentSuccess): ?>
<div class="success-screen" id="successScreen">
  <div class="checkmark"><i class="fas fa-check"></i></div>
  <div class="success-text">Payment Successful!</div>
  <div class="subtext">₹<?php echo number_format($amount,2); ?> paid for Request #<?php echo $requestId; ?></div>
</div>
<script>
setTimeout(()=>{ window.location="MyRequest.php"; },2500);
</script>
<?php endif; ?>

<script>
const form=document.getElementById("paymentForm");
form.addEventListener("submit",(e)=>{
  document.getElementById("processingScreen").style.display="flex";
});

// card animation
const cardPreview=document.getElementById("cardPreview");
const cardNumber=document.getElementById("cardNumber");
const cardName=document.getElementById("cardName");
const cardExp=document.getElementById("cardExp");
const cardCVV=document.getElementById("cardCVV");
const displayNumber=document.getElementById("displayNumber");
const displayName=document.getElementById("displayName");
const displayExp=document.getElementById("displayExp");
const displayCVV=document.getElementById("displayCVV");

cardNumber.addEventListener("input",()=>{
  let v=cardNumber.value.replace(/\D/g,"");
  cardNumber.value=v.match(/.{1,4}/g)?.join(" ")||"";
  displayNumber.textContent=cardNumber.value||"XXXX XXXX XXXX XXXX";
});
cardName.addEventListener("input",()=>{
  displayName.textContent=cardName.value.toUpperCase()||"CARD HOLDER";
});
cardExp.addEventListener("input",()=>{
  let v=cardExp.value.replace(/\D/g,"");
  cardExp.value=v.length>=3?v.slice(0,2)+"/"+v.slice(2,4):v;
  displayExp.textContent=cardExp.value||"MM/YY";
});
cardCVV.addEventListener("focus",()=>cardPreview.classList.add("flip"));
cardCVV.addEventListener("blur",()=>cardPreview.classList.remove("flip"));
cardCVV.addEventListener("input",()=>{
  cardCVV.value=cardCVV.value.replace(/\D/g,"").slice(0,3);
  displayCVV.textContent=cardCVV.value.padEnd(3,"*");
});
</script>
</body>
</html>
