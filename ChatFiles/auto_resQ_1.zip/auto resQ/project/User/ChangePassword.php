<?php
include("../asset/connection/connection.php");
session_start();
$SelQry = "select * from tbl_user where user_id='" . $_SESSION['uid'] . "'";
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();
$userpassword = $row['user_password'];

if (isset($_POST['btn'])) {
    $oldpass = $_POST['oldpass'];
    $newpass = $_POST['newpass'];
    $repass = $_POST['retypepass'];

    if ($oldpass == $userpassword) {
        if ($newpass == $repass) {
            $UpQry = "update tbl_user set user_password='" . $newpass . "' where user_id='" . $_SESSION['uid'] . "'";
            if ($Con->query($UpQry)) {
                echo "<script>
                    alert('Password updated successfully!');
                    window.location='MyProfile.php';
                </script>";
            }
        } else {
            echo "<script>alert('Password mismatch!');</script>";
        }
    } else {
        echo "<script>alert('Incorrect old password!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoresQ | Change Password</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #111, #b51212);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    color: #333;
}
.change-wrapper {
    width: 500px;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 18px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    overflow: hidden;
    backdrop-filter: blur(6px);
}
.header {
    background: linear-gradient(135deg, #b51212, #7a0a0a);
    color: white;
    text-align: center;
    padding: 25px 10px;
    font-size: 28px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
}
.form-container {
    padding: 40px 35px;
}
.form-container h2 {
    color: #b51212;
    text-align: center;
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 25px;
}
.form-group {
    margin-bottom: 18px;
}
label {
    display: block;
    font-weight: 500;
    margin-bottom: 5px;
    color: #444;
}
input {
    width: 100%;
    padding: 12px 14px;
    border-radius: 10px;
    border: 1.5px solid #bbb;
    font-size: 15px;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s ease;
}
input:focus {
    border-color: #b51212;
    outline: none;
    box-shadow: 0 0 6px rgba(181,18,18,0.3);
}
.btn-submit {
    width: 100%;
    padding: 12px;
    background: #b51212;
    color: #fff;
    border: none;
    border-radius: 10px;
    font-size: 17px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s;
}
.btn-submit:hover {
    background: #8d0f0f;
    transform: scale(1.03);
}
.form-note {
    text-align: center;
    font-size: 13px;
    color: #777;
    margin-top: 15px;
}
@media (max-width: 600px) {
    .change-wrapper {
        width: 90%;
    }
    .header {
        font-size: 24px;
        padding: 20px;
    }
    .form-container {
        padding: 25px;
    }
}
</style>
</head>

<body>
<div class="change-wrapper">
    <div class="header">autoresQ</div>
    <div class="form-container">
        <h2>Change Password</h2>
        <form id="form1" name="form1" method="post" action="">
            <div class="form-group">
                <label for="oldpass">Old Password</label>
                <input required type="password" name="oldpass" id="oldpass"
                       pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                       title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters" />
            </div>

            <div class="form-group">
                <label for="newpass">New Password</label>
                <input required type="password" name="newpass" id="newpass"
                       pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                       title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters" />
            </div>

            <div class="form-group">
                <label for="retypepass">Retype New Password</label>
                <input required type="password" name="retypepass" id="retypepass"
                       pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                       title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters" />
            </div>

            <button type="submit" class="btn-submit" name="btn">UPDATE PASSWORD</button>
        </form>
    </div>
</div>
</body>
</html>
