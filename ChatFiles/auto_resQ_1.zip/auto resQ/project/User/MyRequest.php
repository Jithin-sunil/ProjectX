<?php
session_start();
include("../asset/Connection/Connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ | View Requests</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
  /* ===== Base Styling ===== */
  body {
    font-family: "Poppins", sans-serif;
    background: #fff7f7;
    margin: 0;
    color: #333;
  }

  /* ===== Navbar ===== */
  .navbar {
    background-color: #b71c1c;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 40px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  }

  .navbar .logo {
    font-size: 22px;
    font-weight: 700;
    letter-spacing: 1px;
  }

  .navbar .logo i {
    margin-right: 8px;
  }

  .navbar ul {
    list-style: none;
    display: flex;
    gap: 25px;
    margin: 0;
    padding: 0;
  }

  .navbar ul li a {
    text-decoration: none;
    color: white;
    font-weight: 500;
    transition: 0.3s;
  }

  .navbar ul li a:hover {
    color: #ffcccc;
  }

  /* ===== Container ===== */
  .container {
    max-width: 1100px;
    margin: 40px auto;
    padding: 0 20px;
  }

  h1 {
    color: #b71c1c;
    text-align: center;
    margin-bottom: 25px;
    font-size: 26px;
  }

  /* ===== Table Styling ===== */
  table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    box-shadow: 0 6px 20px rgba(183, 28, 28, 0.15);
    border-radius: 15px;
    overflow: hidden;
  }

  th, td {
    padding: 14px 16px;
    text-align: center;
    font-size: 14px;
  }

  th {
    background: #b71c1c;
    color: white;
    text-transform: uppercase;
  }

  tr:nth-child(even) {
    background: #fff2f2;
  }

  tr:hover {
    background: #ffeaea;
    transition: 0.2s;
  }

  td {
    color: #333;
  }

  /* ===== Animated Status Labels ===== */
  @keyframes pulse {
    0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(183, 28, 28, 0.4); }
    70% { transform: scale(1.05); box-shadow: 0 0 0 8px rgba(183, 28, 28, 0); }
    100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(183, 28, 28, 0); }
  }

  .status {
    font-weight: 600;
    padding: 6px 12px;
    border-radius: 12px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    animation: pulse 2.5s infinite;
  }

  .waiting { background: #fff0b3; color: #b28900; }
  .accepted { background: #c8e6c9; color: #2e7d32; }
  .rejected { background: #ffcdd2; color: #b71c1c; }
  .assigned { background: #bbdefb; color: #1565c0; }
  .working { background: #ffe0b2; color: #ef6c00; }
  .completed { background: #c8e6c9; color: #2e7d32; }
  .paid { background: #d1c4e9; color: #4a148c; }

  /* ===== Buttons ===== */
  a.btn {
    text-decoration: none;
    padding: 8px 15px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    transition: 0.3s;
    display: inline-block;
    margin-top: 6px;
  }

  a.btn-payment {
    background: #b71c1c;
    color: white;
  }

  a.btn-payment:hover {
    background: #ff5252;
    transform: translateY(-2px);
  }

  a.btn-rate {
    background: #2e7d32;
    color: white;
  }

  a.btn-rate:hover {
    background: #43a047;
    transform: translateY(-2px);
  }

  /* ===== Empty Data ===== */
  .no-data {
    text-align: center;
    color: #b71c1c;
    background: #fff0f0;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(183, 28, 28, 0.1);
    margin-top: 20px;
  }
</style>
</head>

<body>
  <!-- ===== Navbar ===== -->
  <div class="navbar">
    <div class="logo"><i class="fas fa-car-burst"></i> AutoResQ</div>
    <ul>
      <li><a href="HomePage.php"><i class="fas fa-home"></i> Home</a></li>
      <!-- <li><a href="Profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
      <li><a href="../Guest/Login.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li> -->
    </ul>
  </div>

  <!-- ===== Main Content ===== -->
  <div class="container">
    <h1><i class="fas fa-clipboard-list"></i> View Your Requests</h1>

    <table>
      <tr>
        <th>Sl.No</th>
        <th>Name</th>
        <th>Date</th>
        <th>Location</th>
        <th>Details</th>
        <th>Vehicle Info</th>
        <th>Status / Action</th>
      </tr>

      <?php
      $i = 0;
      $selqry = "SELECT *  
                  FROM tbl_request r
                  INNER JOIN tbl_user u ON r.user_id = u.user_id
                  INNER JOIN tbl_brand b ON r.brand_id = b.brand_id
                  INNER JOIN tbl_category c ON r.category_id = c.category_id
                  WHERE r.user_id = ".$_SESSION['uid']." 
                  AND r.workshop_id = ".$_SESSION['wid'];

      $result = $Con->query($selqry);
      if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
          $i++;
          echo "<tr>";
          echo "<td>$i</td>";
          echo "<td>".$row["user_name"]."</td>";
          echo "<td>".$row["request_date"]."</td>";
          echo "<td>".$row["request_location"]."</td>";
          echo "<td><b>".$row["request_title"]."</b><br>".$row["request_content"]."</td>";
          echo "<td>Vehicle No: ".$row["vehicle_no"]."<br>Brand: ".$row["brand_name"]."<br>Category: ".$row["category_name"]."</td>";
          echo "<td>";

          switch($row["request_status"]) {
            case "0":
              echo "<span class='status waiting'><i class='fas fa-hourglass-half'></i> Waiting</span>";
              break;

            case "1":
              echo "<span class='status accepted'><i class='fas fa-check-circle'></i> Accepted</span>";
              break;

            case "2":
              echo "<span class='status rejected'><i class='fas fa-times-circle'></i> Rejected</span>";
              break;

            case "3":
              $sel = "SELECT * FROM tbl_mechanic WHERE mechanic_id='".$row["mechanic_id"]."'";
              $res = $Con->query($sel);
              $m = $res->fetch_assoc();
              echo "<span class='status assigned'><i class='fas fa-user-cog'></i> Assigned to ".$m["mechanic_name"]."</span>";
              break;

            case "4":
              $sel = "SELECT * FROM tbl_mechanic WHERE mechanic_id='".$row["mechanic_id"]."'";
              $res = $Con->query($sel);
              $m = $res->fetch_assoc();
              echo "<span class='status working'><i class='fas fa-wrench'></i> ".$m["mechanic_name"]." Started Work</span>";
              break;

            case "5":
              echo "<span class='status completed'><i class='fas fa-flag-checkered'></i> Work Completed</span><br>";
              echo "<strong>Amount:</strong> ₹".$row["request_amount"]."<br>";
              echo "<a href='Payment.php?rid=".$row["request_id"]."' class='btn btn-payment'><i class='fas fa-credit-card'></i> Pay Now</a>";
              break;

            case "6":
              echo "<span class='status paid'><i class='fas fa-coins'></i> Payment Completed</span><br>";
              echo "<a href='Rating.php?wid=".$row["workshop_id"]."' class='btn btn-rate'><i class='fas fa-star'></i> Rate Workshop</a>";
              break;
          }

          echo "</td></tr>";
        }
      } else {
        echo "<tr><td colspan='7' class='no-data'><i class='fas fa-info-circle'></i> No requests found.</td></tr>";
      }
      ?>
    </table>
  </div>
</body>
</html>
