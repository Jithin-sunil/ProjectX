<!DOCTYPE html>
<html>
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Oberlo</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" type="text/css" href="asset/template/main/css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" type="text/css" href="asset/template/main/css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="asset/template/main/css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="asset/template/main/images/fevicon.png" type="image/gif" />
      <!-- font css -->
      <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap" rel="stylesheet">
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="asset/template/main/css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- font awesome css -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   </head>
   <body>
      <!-- header section strats -->
      <header class="header_section">
        <div class="container">
            <nav class="navbar navbar-expand-lg custom_nav-container ">

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class=""> </span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav  ">
                        <li class="nav-item active">
                            <a class="nav-link" href="">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Guest/login.php"> login </a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link" href=""> Workshop</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link navbar-brand" href=""> <span><span>au</span>toresQ</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Guest/UserRegistrstion.php"> User</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Guest/WorkShopRegisteration.php"> Workshop</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link " href="">Contact </a>
                        </li> -->
                    </ul>
                </div>
            </nav>
         </div>
      </header>
      <!-- end header section -->
      <!-- banner section start --> 
      <div class="banner_section layout_padding">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-6">
                  <div id="banner_slider" class="carousel slide" data-ride="carousel">
                     <div class="carousel-inner">
                        <div class="carousel-item active">
                           <div class="banner_taital_main">
                              <h1 class="banner_taital">Vehicle<br> Breakdown Assitance</h1>
                              <p class="banner_text">vehicle BreakDown Assitance</p>
                              <!-- <div class="form-group">
                                 <input type="text" class="update_mail" placeholder="Search here" name="Search here">
                                 <div class="subscribe_bt"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
                              </div> -->
                           </div>
                        </div>
                        <div class="carousel-item">
                           <div class="banner_taital_main">
                              <h1 class="banner_taital">New<br> Model Cars</h1>
                              <p class="banner_text">consectetur adipiscing elit, sed do eiusmod tempor incididunt uolore magna aliqua. Ut enim ad minim veniam, quis non</p>
                              <!-- <div class="form-group">
                                 <input type="text" class="update_mail" placeholder="Search here" name="Search here">
                                 <div class="subscribe_bt"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
                              </div> -->
                           </div>
                        </div>
                        <div class="carousel-item">
                           <div class="banner_taital_main">
                              <h1 class="banner_taital">New<br> Model Cars</h1>
                              <p class="banner_text">consectetur adipiscing elit, sed do eiusmod tempor incididunt uolore magna aliqua. Ut enim ad minim veniam, quis non</p>
                              <!-- <div class="form-group">
                                 <input type="text" class="update_mail" placeholder="Search here" name="Search here">
                                 <div class="subscribe_bt"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
                              </div> -->
                           </div>
                        </div>
                     </div>
                     <a class="carousel-control-prev" href="#banner_slider" role="button" data-slide="prev">
                     <i class="fa fa-angle-left"></i>
                     </a>
                     <a class="carousel-control-next" href="#banner_slider" role="button" data-slide="next">
                     <i class="fa fa-angle-right"></i>
                     </a>
                  </div>
               </div>
               <div class="col-md-6 padding_right0">
                  <div class="banner_img"><img src="asset/template/main/images/banner-img.png"></div>
               </div>
            </div>
         </div>
      </div>
      <!-- banner section end -->
      <!-- about section start -->
      <div class="about_section layout_padding">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-6">
                  <div class="about_img"><img src="asset/template/main/images/about-img.png"></div>
               </div>
               <div class="col-md-6">
                  <h3 class="about_taital">About Service</h3>
                    <p class="about_text">The Vehicle Breakdown Assistance Service refers to the professional support provided to vehicle owners or drivers when their vehicle experiences an unexpected mechanical or electrical failure on the road. The service aims to offer immediate help, such as towing, on-site repair, battery jump-start, fuel delivery, flat tire replacement, and emergency mechanic support, ensuring the safety and convenience of the user and minimizing vehicle downtime.</p>
                    <div class="readmore_btn"><a href="#">Read More<span class="arrow_icon"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a></div>
               </div>
            </div>
         </div>
      </div>
      <!-- about section end -->
      <!-- models section start -->
      <div class="models_section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <h1 class="models_taital">Our Services</h1>
               </div>
            </div>
            <div class="models_section_2">
               <div class="row">
                  <div class="col-md-6">
                     <div class="models_img"><img src="asset/template/main/images/img-1.png"></div>
                  </div>
                  <div class="col-md-6">
                     <h3 class="carolo_text"><span class="number_text">01</span> New Carolo car</h3>
                     <p class="ullamco_text">Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p>
                     <div class="price_main">
                        <p class="price_text"><span style="color: #fc9d22;">Price</span> $30000.00</p>
                        <div class="read_btn"><a href="#">Read More<span class="arrow_icon"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="models_section_2">
               <div class="row">
                  <div class="col-md-6">
                     <h3 class="carolo_text"><span class="number_text">02</span> New Carolo car</h3>
                     <p class="ullamco_text">Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p>
                     <div class="price_main">
                        <p class="price_text"><span style="color: #fc9d22;">Price</span> $30000.00</p>
                        <div class="read_btn"><a href="#">Read More<span class="arrow_icon"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a></div>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="models_img"><img src="asset/template/main/images/img-2.png"></div>
                  </div>
               </div>
            </div>
            <div class="models_section_2">
               <div class="row">
                  <div class="col-md-6">
                     <div class="models_img"><img src="asset/template/main/images/img-3.png"></div>
                  </div>
                  <div class="col-md-6">
                     <h3 class="carolo_text"><span class="number_text">03</span> New Carolo car</h3>
                     <p class="ullamco_text">Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p>
                     <div class="price_main">
                        <p class="price_text"><span style="color: #fc9d22;">Price</span> $30000.00</p>
                        <div class="read_btn"><a href="#">Read More<span class="arrow_icon"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- models section end -->
      <div class="choose_section_2">
            <div class="container">
               <div class="row">
                  <div class="col-lg-3 col-sm-6">
                     <h1 class="rated_text"><span class="padding_10"><img src="asset/template/main/images/icon-1.png"></span>3700</h1>
                     <p class="house_text">Happy Clients</p>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                     <h1 class="rated_text"><span class="padding_10"><img src="asset/template/main/images/icon-2.png"></span>5700</h1>
                     <p class="house_text">Vehicles In Stock</p>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                     <h1 class="rated_text"><span class="padding_10"><img src="asset/template/main/images/icon-3.png"></span>124</h1>
                     <p class="house_text">Awards</p>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                     <h1 class="rated_text"><span class="padding_10"><img src="asset/template/main/images/icon-4.png"></span>704</h1>
                     <p class="house_text">Dealer Branches</p>
                  </div>
               </div>
            </div>
         </div>
      <!-- blog section start -->
      <div class="blog_section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <h1 class="blog_taital">FEATURED VEHICLES</h1>
               </div>
            </div>
            <div class="blog_section_2">
               <div class="row">
                  <div class="col-md-4">
                     <div class="blog_img"><img src="asset/template/main/images/img-4.png"></div>
                     <div class="btn_main">
                        <div class="date_text"><a href="#">Price $ 40000.0</a></div>
                     </div>
                     <div class="blog_box">
                        <h3 class="blog_text">Voluptate</h3>
                        <p class="lorem_text">Commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum </p>
                     </div>
                     <div class="read_bt"><a href="#">Read More<span class="arrow_icon"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a></div>
                  </div>
                  <div class="col-md-4">
                     <div class="blog_img"><img src="asset/template/main/images/img-5.png"></div>
                     <div class="btn_main">
                        <div class="date_text active"><a href="#">Price $ 40000.0</a></div>
                     </div>
                     <div class="blog_box">
                        <h3 class="blog_text">Voluptate</h3>
                        <p class="lorem_text">Commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum </p>
                     </div>
                     <div class="read_bt active"><a href="#">Read More<span class="arrow_icon"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a></div>
                  </div>
                  <div class="col-md-4">
                     <div class="blog_img"><img src="asset/template/main/images/img-6.png"></div>
                     <div class="btn_main">
                        <div class="date_text"><a href="#">Price $ 40000.0</a></div>
                     </div>
                     <div class="blog_box">
                        <h3 class="blog_text">Voluptate</h3>
                        <p class="lorem_text">Commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum </p>
                     </div>
                     <div class="read_bt"><a href="#">Read More<span class="arrow_icon"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- blog section end -->
      <!-- client section start -->
      <div class="client_section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <h1 class="client_taital">What Says Our Students</h1>
                  <p class="client_text">It is a long established fact that a reader will be distracted by the readable c</p>
               </div>
            </div>
            <div class="customer_section_2">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="box_main">
                           <div class="customer_main">
                              <div class="customer_left">
                                 <div class="customer_img"><img src="asset/template/main/images/client-img.png"></div>
                              </div>
                              <div class="customer_right">
                                 <h3 class="customer_name">DenoMark</h3>
                                 <p class="enim_text">anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internetanything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet</p>
                                 <div class="quick_icon"><img src="asset/template/main/images/quick-icon.png"></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- client section end -->
      <!-- contact section start -->
      <div class="contact_section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <h1 class="contact_taital">Get In Touch</h1>
               </div>
            </div>
            <div class="contact_section_2">
               <div class="mail_section map_form_container">
                  <form action="">
                  <input type="text" class="mail_text" placeholder="Name" name="Name">
                  <input type="text" class="mail_text" placeholder="Phone Number" name="Phone Number"> 
                  <input type="text" class="mail_text" placeholder="Email" name="Email">
                  <textarea class="massage-bt" placeholder="Massage" rows="5" id="comment" name="Massage"></textarea>
                  <div class="map_btn_main">
                     <div class="send_bt"><a href="#">Send Now</a></div>
                     <div class="map_bt"><a href="#" id="showMap">Map</a></div>
                  </div>
                  </form>
                  <div class="map_main map_container">
                     <div class="map-responsive">
                        <iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&amp;q=Eiffel+Tower+Paris+France" width="600" height="368" frameborder="0" style="border:0; width: 100%;" allowfullscreen=""></iframe>
                         <div class="map_btn_main">
                           <div class="map_bt d-flex justify-content-center w-100 map_center"><a href="#" id="showForm">Form</a></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="location_main">
               <div class="location_text">
                  <ul>
                     <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i><span class="padding_left_15">(+71) 8522369417</span></a></li>
                     <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i><span class="padding_left_15">demo@gmail.com</span></a></li>
                  </ul>
               </div>
            </div>
            <div class="social_icon">
               <ul>
                  <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                  <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                  <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
               </ul>
            </div>
         </div>
      </div>
      <!-- contact section end -->
      <!-- copyright section start -->
      <div class="copyright_section">
         <div class="container">
            <p class="copyright_text">2020 All Rights Reserved. Design by <a href="https://html.design">Free Html Templates</a>. DIstributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a></p>
         </div>
      </div>
      <!-- copyright section end -->
      <!-- Javascript files-->
      <script src="asset/template/main/js/jquery.min.js"></script>
      <script src="asset/template/main/js/popper.min.js"></script>
      <script src="asset/template/main/js/bootstrap.bundle.min.js"></script>
      <script src="asset/template/main/js/jquery-3.0.0.min.js"></script>
      <script src="asset/template/main/js/plugin.js"></script>
      <!-- sidebar -->
      <script src="asset/template/main/js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="asset/template/main/js/custom.js"></script>
   </body>
</html>