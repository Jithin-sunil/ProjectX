<?php
include("../asset/connection/connection.php");
session_start();

if (!isset($_SESSION['mid'])) {
    header("Location: ../Guest/login.php");
    exit();
}

$SelQry = "SELECT * FROM tbl_mechanic WHERE mechanic_id='" . $_SESSION['mid'] . "'";
$row = $Con->query($SelQry);
$data = $row->fetch_assoc();

if (isset($_POST['btn'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $UpQry = "UPDATE tbl_mechanic SET mechanic_name='" . $name . "', mechanic_email='" . $email . "' WHERE mechanic_id='" . $_SESSION['mid'] . "'";
    if ($Con->query($UpQry)) {
        echo "<script>alert('Profile updated successfully'); window.location='MyProfile.php';</script>";
    } else {
        echo "<script>alert('Update failed, please try again');</script>";
    }
}

$firstLetter = strtoupper(substr($data['mechanic_name'], 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ | Mechanic Profile</title>
<style>
body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
  background-color: #0a0a0a;
  color: #f5f5f5;
  display: flex;
}

/* Sidebar */
.sidebar {
  width: 220px;
  height: 100vh;
  background: linear-gradient(180deg, #111, #1a1a1a);
  box-shadow: 2px 0 15px rgba(255, 0, 0, 0.3);
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 30px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.sidebar h2 {
  color: #ff3b3b;
  margin-bottom: 40px;
  letter-spacing: 1px;
}
.sidebar a {
  text-decoration: none;
  color: #eee;
  display: block;
  width: 80%;
  text-align: center;
  padding: 10px;
  margin: 10px 0;
  border-radius: 8px;
  transition: background 0.3s, color 0.3s;
}
.sidebar a:hover, .sidebar a.active {
  background: #ff3b3b;
  color: #fff;
}

/* Main */
.main {
  margin-left: 240px;
  width: calc(100% - 240px);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* Topbar */
.topbar {
  background: rgba(255, 255, 255, 0.05);
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 15px rgba(255,0,0,0.2);
}
.topbar h1 {
  color: #ff3b3b;
  font-size: 20px;
  margin: 0;
}
.profile {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* Profile Circle */
.profile-circle {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(145deg, #ff3b3b, #ff5555);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  color: #fff;
  font-weight: bold;
  box-shadow: 0 0 10px rgba(255, 59, 59, 0.6);
}

/* Form Container */
.container {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid #ff3b3b;
  border-radius: 15px;
  box-shadow: 0 0 20px rgba(255, 0, 0, 0.3);
  width: 450px;
  padding: 30px;
  margin: 60px auto;
  text-align: center;
}

.container h2 {
  color: #ff3b3b;
  margin-bottom: 20px;
}

form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

input[type="text"], input[type="email"] {
  width: 100%;
  padding: 10px;
  background: #1a1a1a;
  border: 1px solid #ff3b3b;
  border-radius: 8px;
  color: #fff;
  outline: none;
  transition: border 0.3s;
}

input[type="text"]:focus, input[type="email"]:focus {
  border-color: #ff5555;
}

button {
  background: #ff3b3b;
  border: none;
  color: #fff;
  padding: 10px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s;
  font-weight: 600;
}

button:hover {
  background: #ff5555;
}

a {
  color: #ff3b3b;
  text-decoration: none;
  margin-top: 15px;
  display: inline-block;
}
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2>AutoResQ</h2>
  <a href="Homepage.php">🏠 Dashboard</a>
  <a href="MyProfile.php" class="active">👤 My Profile</a>
  <a href="ViewAssignedWorks.php">🧰 My Works</a>
  <a href="Changepassword.php">🔒 Change Password</a>
  <a href="../Guest/logout.php">🚪 Logout</a>
</div>

<!-- Main -->
<div class="main">
  <div class="topbar">
    <h1>Mechanic Profile</h1>
    <div class="profile">
      <div class="profile-circle"><?php echo $firstLetter; ?></div>
      <span>Welcome, <?php echo htmlspecialchars($data['mechanic_name']); ?></span>
    </div>
  </div>

  <div class="container">
    <h2>Update Profile</h2>
    <form method="post" action="">
      <input type="text" name="name" value="<?php echo htmlspecialchars($data['mechanic_name']); ?>" required />
      <input type="email" name="email" value="<?php echo htmlspecialchars($data['mechanic_email']); ?>" required />
      <button type="submit" name="btn">Update Profile</button>
    </form>
    <a href="MechanicHome.php">⬅ Back to Dashboard</a>
  </div>
</div>

</body>
</html>
