<?php
include("../asset/connection/connection.php");
session_start();

if (!isset($_SESSION['mid'])) {
    header("Location: ../Guest/login.php");
    exit();
}

$mid = $_SESSION['mid'];

// Fetch mechanic details
$SelQry = "SELECT * FROM tbl_mechanic WHERE mechanic_id = $mid";
$result = $Con->query($SelQry);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("Mechanic not found.");
}

// Default values
$workshopName = "—";

// ✅ 1️⃣ Try to get workshop name from tbl_mechanic (using workshop_id)
if (array_key_exists('workshop_id', $row) && !empty($row['workshop_id'])) {
    $workshopQry = "SELECT workshop_name FROM tbl_workshop WHERE workshop_id = " . intval($row['workshop_id']);
    $workshopResult = $Con->query($workshopQry);
    if ($workshopResult && $workshopResult->num_rows > 0) {
        $workshopRow = $workshopResult->fetch_assoc();
        $workshopName = $workshopRow['workshop_name'];
    }
}

// ✅ 2️⃣ If still empty, find workshop from assigned work
if ($workshopName === "—") {
    $altQry = "SELECT w.workshop_name 
               FROM tbl_workassign a 
               INNER JOIN tbl_workshop w ON a.workshop_id = w.workshop_id 
               WHERE a.mechanic_id = $mid 
               LIMIT 1";
    $altResult = $Con->query($altQry);
    if ($altResult && $altResult->num_rows > 0) {
        $altRow = $altResult->fetch_assoc();
        $workshopName = $altRow['workshop_name'];
    } else {
        $workshopName = "No Workshop Linked";
    }
}

// ✅ Count assigned works
$workQry = "SELECT COUNT(*) AS total FROM tbl_workassign WHERE mechanic_id = $mid";
$workRes = $Con->query($workQry);
$totalWorks = 0;
if ($workRes && $workRes->num_rows > 0) {
    $workData = $workRes->fetch_assoc();
    $totalWorks = $workData['total'];
}

$firstLetter = strtoupper(substr($row['mechanic_name'], 0, 1));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ | Mechanic Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
  background: radial-gradient(circle at top left, #1a1a1a, #000);
  color: #f5f5f5;
  display: flex;
  min-height: 100vh;
  overflow-x: hidden;
}

/* Sidebar */
.sidebar {
  width: 230px;
  background: linear-gradient(180deg, #111, #1a1a1a);
  box-shadow: 2px 0 20px rgba(255, 0, 0, 0.3);
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 30px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.sidebar h2 {
  color: #ff3b3b;
  margin-bottom: 40px;
  font-weight: 600;
}
.sidebar a {
  text-decoration: none;
  color: #eee;
  display: block;
  width: 80%;
  text-align: center;
  padding: 12px;
  margin: 8px 0;
  border-radius: 10px;
  transition: 0.3s ease;
}
.sidebar a:hover, .sidebar a.active {
  background: #ff3b3b;
  color: #fff;
  transform: scale(1.05);
  box-shadow: 0 0 15px rgba(255, 59, 59, 0.6);
}

/* Main */
.main {
  margin-left: 250px;
  flex: 1;
  display: flex;
  flex-direction: column;
}

/* Topbar */
.topbar {
  background: rgba(255, 255, 255, 0.05);
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 15px rgba(255, 0, 0, 0.2);
}
.topbar h1 {
  color: #ff3b3b;
  font-size: 20px;
  margin: 0;
}
.profile {
  display: flex;
  align-items: center;
  gap: 12px;
}

/* Profile Circle */
.profile-circle {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  background: linear-gradient(145deg, #ff3b3b, #ff5555);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  color: #fff;
  font-weight: bold;
  box-shadow: 0 0 10px rgba(255, 59, 59, 0.6);
  animation: glow 2s infinite alternate;
}
@keyframes glow {
  from { box-shadow: 0 0 5px #ff3b3b; }
  to { box-shadow: 0 0 20px #ff3b3b; }
}

/* Welcome Box */
.welcome-box {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid #ff3b3b;
  border-radius: 15px;
  box-shadow: 0 0 25px rgba(255, 0, 0, 0.25);
  width: 500px;
  padding: 40px;
  margin: 60px auto 20px;
  text-align: center;
}
.welcome-box h2 {
  color: #ff3b3b;
  font-size: 26px;
  margin-bottom: 12px;
}
.welcome-box p {
  color: #ccc;
  font-size: 15px;
  margin: 6px 0;
}

/* Dashboard Cards */
.dashboard {
  display: flex;
  justify-content: center;
  gap: 25px;
  flex-wrap: wrap;
  margin-bottom: 40px;
}
.card {
  width: 220px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid #ff3b3b;
  border-radius: 12px;
  padding: 25px;
  text-align: center;
  transition: 0.3s;
  box-shadow: 0 0 15px rgba(255, 0, 0, 0.2);
}
.card:hover {
  transform: scale(1.05);
  box-shadow: 0 0 25px rgba(255, 59, 59, 0.4);
}
.card h3 {
  color: #ff3b3b;
  margin-bottom: 10px;
}
.card p {
  font-size: 18px;
  font-weight: bold;
  color: #fff;
}

/* Clock */
.clock {
  font-size: 14px;
  color: #aaa;
  margin-top: 5px;
  text-align: center;
}
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2>AutoResQ</h2>
  <a href="MechanicHome.php" class="active">🏠 Dashboard</a>
  <a href="MyProfile.php">👤 My Profile</a>
  <a href="ViewAssignedWork.php">🧰 My Works</a>
  <a href="EditProfile.php">✏️ Edit Profile</a>
  <a href="ChangePassword.php">🔒 Change Password</a>
  <a href="../Guest/Logout.php">🚪 Logout</a>
</div>

<!-- Main -->
<div class="main">
  <div class="topbar">
    <h1>Welcome, <?php echo htmlspecialchars($row['mechanic_name']); ?></h1>
    <div class="profile">
      <div class="profile-circle"><?php echo $firstLetter; ?></div>
    </div>
  </div>

  <div class="welcome-box">
    <h2>👋 Hello <?php echo htmlspecialchars($row['mechanic_name']); ?>!</h2>
    <p>Workshop: <strong><?php echo htmlspecialchars($workshopName); ?></strong></p>
    <p>Email: <?php echo htmlspecialchars($row['mechanic_email']); ?></p>
    <p>Contact: <?php echo htmlspecialchars($row['mechanic_contact']); ?></p>
    <p>Address: <?php echo htmlspecialchars($row['mechanic_address']); ?></p>
    <div class="clock" id="clock"></div>
  </div>

  <div class="dashboard">
    <div class="card">
      <h3>Assigned Works</h3>
      <p><?php echo $totalWorks; ?></p>
    </div>

    <div class="card">
      <h3>Workshop</h3>
      <p><?php echo htmlspecialchars($workshopName); ?></p>
    </div>

    <div class="card">
      <h3>Status</h3>
      <p>Active</p>
    </div>
  </div>
</div>

<script>
function updateClock() {
  const now = new Date();
  document.getElementById('clock').innerText = now.toLocaleString();
}
setInterval(updateClock, 1000);
updateClock();
</script>

</body>
</html>
