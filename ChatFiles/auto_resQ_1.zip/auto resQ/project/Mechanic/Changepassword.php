<?php
include("../asset/connection/connection.php");
session_start();

if (!isset($_SESSION['mid'])) {
    header("Location: ../Guest/Login.php");
    exit();
}

$SelQry = "SELECT * FROM tbl_mechanic WHERE mechanic_id=?";
$stmt = $Con->prepare($SelQry);
$stmt->bind_param("i", $_SESSION['mid']);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$mechpassword = $row['mechanic_password'];

if (isset($_POST['btn'])) {
    $oldpass = $_POST['oldpass'];
    $newpass = $_POST['newpass'];
    $repass = $_POST['retypepass'];

    if ($oldpass === $mechpassword) {
        if ($newpass === $repass) {
            $UpQry = "UPDATE tbl_mechanic SET mechanic_password=? WHERE mechanic_id=?";
            $stmt = $Con->prepare($UpQry);
            $stmt->bind_param("si", $newpass, $_SESSION['mid']);
            if ($stmt->execute()) {
                echo "<script>alert('Password Updated Successfully'); window.location='MyProfile.php';</script>";
            }
        } else {
            echo "<script>alert('New password and confirm password do not match');</script>";
        }
    } else {
        echo "<script>alert('Old password is incorrect');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ | Mechanic - Change Password</title>
<style>
body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
  background: #0a0a0a;
  color: #f5f5f5;
  display: flex;
}

/* Sidebar */
.sidebar {
  width: 220px;
  height: 100vh;
  background: linear-gradient(180deg, #111, #1a1a1a);
  box-shadow: 2px 0 15px rgba(255, 0, 0, 0.3);
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 30px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.sidebar h2 {
  color: #ff3b3b;
  margin-bottom: 40px;
  letter-spacing: 1px;
}
.sidebar a {
  text-decoration: none;
  color: #eee;
  display: block;
  width: 80%;
  text-align: center;
  padding: 10px;
  margin: 10px 0;
  border-radius: 8px;
  transition: background 0.3s, color 0.3s;
}
.sidebar a:hover, .sidebar a.active {
  background: #ff3b3b;
  color: #fff;
}

/* Main */
.main {
  margin-left: 240px;
  width: calc(100% - 240px);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* Topbar */
.topbar {
  background: rgba(255, 255, 255, 0.05);
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 15px rgba(255,0,0,0.2);
}
.topbar h1 {
  color: #ff3b3b;
  font-size: 20px;
  margin: 0;
}
.profile {
  display: flex;
  align-items: center;
  gap: 10px;
}
.profile img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: 2px solid #ff3b3b;
}

/* Password Card */
.form-container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex: 1;
}
form {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid #ff3b3b;
  border-radius: 20px;
  padding: 40px 50px;
  width: 400px;
  box-shadow: 0 0 25px rgba(255, 59, 59, 0.3);
  text-align: center;
  transition: all 0.3s ease;
  margin-top: 50px;
}
form:hover {
  box-shadow: 0 0 35px rgba(255, 59, 59, 0.5);
}
h2 {
  color: #ff3b3b;
  margin-bottom: 25px;
  letter-spacing: 1px;
}

/* Inputs */
input[type="password"] {
  width: 100%;
  padding: 12px;
  margin: 10px 0;
  border-radius: 8px;
  border: 1px solid #ff3b3b;
  background: #1a1a1a;
  color: #fff;
  font-size: 14px;
  outline: none;
  transition: 0.3s;
}
input[type="password"]:focus {
  border-color: #ff5555;
  box-shadow: 0 0 8px rgba(255, 59, 59, 0.4);
}

/* Button */
input[type="submit"] {
  background: #ff3b3b;
  border: none;
  color: #fff;
  padding: 12px 20px;
  border-radius: 8px;
  cursor: pointer;
  width: 100%;
  margin-top: 15px;
  font-weight: bold;
  transition: background 0.3s;
}
input[type="submit"]:hover {
  background: #ff5555;
}

/* Back link */
.back-link {
  display: inline-block;
  margin-top: 15px;
  color: #aaa;
  text-decoration: none;
  transition: color 0.3s;
}
.back-link:hover {
  color: #ff3b3b;
}
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2>AutoResQ</h2>
  <a href="MechanicHome.php">🏠 Dashboard</a>
  <a href="MyProfile.php">👤 My Profile</a>
  <a href="ChangePassword.php" class="active">🔒 Change Password</a>
  <a href="ViewWork.php">🧰 My Works</a>
  <a href="../Guest/Logout.php">🚪 Logout</a>
</div>

<!-- Main -->
<div class="main">
  <div class="topbar">
    <h1>Change Password</h1>
    <div class="profile">
      <img src="../asset/images/mechanic.png" alt="Mechanic">
      <span><?php echo htmlspecialchars($row['mechanic_name']); ?></span>
    </div>
  </div>

  <div class="form-container">
    <form method="post" action="">
      <h2>🔑 Update Password</h2>
      <input required type="password" name="oldpass" placeholder="Enter Old Password"
             pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
             title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters" />

      <input required type="password" name="newpass" placeholder="Enter New Password"
             pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
             title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters" />

      <input required type="password" name="retypepass" placeholder="Re-type New Password"
             pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
             title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters" />

      <input type="submit" name="btn" value="Update Password" />
      <a href="MyProfile.php" class="back-link">⬅ Back to Profile</a>
    </form>
  </div>
</div>
</body>
</html>
