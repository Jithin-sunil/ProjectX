<?php
include("../asset/connection/connection.php");
session_start();

if (!isset($_SESSION['mid'])) {
    header("Location: ../Guest/login.php");
    exit();
}

$SelQry = "SELECT * FROM tbl_mechanic WHERE mechanic_id=" . $_SESSION['mid'];
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();

// Handle profile photo update
if (isset($_POST['update_photo'])) {
    $photo = $_FILES['new_photo']['name'];
    $temp = $_FILES['new_photo']['tmp_name'];

    if ($photo != "") {
        $targetPath = "../asset/Files/WorkShop/Photo/" . $photo;
        move_uploaded_file($temp, $targetPath);

        $updateQry = "UPDATE tbl_mechanic SET mechanic_photo='$photo' WHERE mechanic_id=" . $_SESSION['mid'];
        if ($Con->query($updateQry)) {
            echo "<script>
                sessionStorage.setItem('toastMessage', 'Profile photo updated successfully!');
                window.location='mechanic_profile.php';
            </script>";
            exit();
        } else {
            echo "<script>
                sessionStorage.setItem('toastMessage', 'Error updating photo.');
                window.location='mechanic_profile.php';
            </script>";
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Mechanic Profile | AutoResQ</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
/* ========== GLOBAL STYLES ========== */
body {
  font-family: 'Poppins', sans-serif;
  background: radial-gradient(circle at top left, #ff1e1e, #5c0000 70%);
  color: #fff;
  margin: 0;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow-x: hidden;
}

/* ========== CONTAINER ========== */
.profile-container {
  background: rgba(255,255,255,0.08);
  border-radius: 25px;
  padding: 50px;
  width: 90%;
  max-width: 850px;
  text-align: center;
  box-shadow: 0 10px 40px rgba(0,0,0,0.5);
  backdrop-filter: blur(14px);
  animation: fadeIn 0.8s ease;
}

@keyframes fadeIn {
  from {opacity: 0; transform: translateY(20px);}
  to {opacity: 1; transform: translateY(0);}
}

h1 {
  color: #fff;
  font-size: 32px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  margin-bottom: 30px;
}

/* ========== PROFILE IMAGE ========== */
.profile-image {
  position: relative;
  display: inline-block;
}

.profile-image img {
  width: 220px;
  height: 220px;
  border-radius: 50%;
  border: 5px solid #fff;
  object-fit: cover;
  box-shadow: 0 0 25px rgba(255,255,255,0.3);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.profile-image img:hover {
  transform: scale(1.05);
  box-shadow: 0 0 35px rgba(255,255,255,0.4);
}

.upload-overlay {
  position: absolute;
  bottom: 12px;
  right: 15px;
  background: #fff;
  color: #b51212;
  font-weight: 600;
  font-size: 13px;
  padding: 8px 16px;
  border-radius: 30px;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  transition: all 0.3s ease;
}

.upload-overlay:hover {
  background: #b51212;
  color: #fff;
  transform: scale(1.1);
}

input[type="file"] {
  display: none;
}

/* ========== TABLE ========== */
table {
  width: 100%;
  margin-top: 35px;
  border-collapse: collapse;
  font-size: 16px;
}

td {
  padding: 14px 12px;
  border-bottom: 1px solid rgba(255,255,255,0.2);
}

td:first-child {
  text-align: left;
  color: #ffbaba;
  font-weight: 600;
  text-transform: uppercase;
  width: 35%;
}

td:last-child {
  text-align: left;
  color: #fff;
  font-weight: 500;
}

/* ========== BACK BUTTON ========== */
.back-btn {
  display: inline-block;
  margin-top: 40px;
  background: #fff;
  color: #b51212;
  padding: 14px 30px;
  border-radius: 30px;
  font-weight: 600;
  text-decoration: none;
  transition: 0.3s ease;
  box-shadow: 0 0 20px rgba(255,255,255,0.3);
}

.back-btn:hover {
  background: #b51212;
  color: #fff;
  box-shadow: 0 0 25px rgba(255,255,255,0.5);
  transform: scale(1.05);
}

/* ========== TOAST STYLES ========== */
.toast {
  visibility: hidden;
  min-width: 260px;
  background-color: rgba(255,255,255,0.95);
  color: #b51212;
  text-align: center;
  border-radius: 8px;
  padding: 16px;
  position: fixed;
  z-index: 10;
  left: 50%;
  bottom: 30px;
  transform: translateX(-50%);
  font-weight: 600;
  box-shadow: 0 5px 20px rgba(0,0,0,0.4);
  transition: visibility 0s, opacity 0.5s linear;
  opacity: 0;
}

.toast.show {
  visibility: visible;
  opacity: 1;
}
</style>
</head>

<body>
<div class="profile-container">
  <h1>Mechanic Profile</h1>

  <div class="profile-image">
    <img src="../asset/Files/WorkShop/Photo/<?php echo $row['mechanic_photo']; ?>" alt="Mechanic Photo">
    <form method="post" enctype="multipart/form-data">
      <label for="new_photo" class="upload-overlay">Change Photo</label>
      <input type="file" name="new_photo" id="new_photo" accept="image/*" onchange="this.form.submit()">
      <input type="hidden" name="update_photo" value="1">
    </form>
  </div>

  <form id="form1" name="form1" method="post" action="">
    <table>
      <tr>
        <td>Name</td>
        <td><?php echo $row['mechanic_name']; ?></td>
      </tr>
      <tr>
        <td>Email</td>
        <td><?php echo $row['mechanic_email']; ?></td>
      </tr>
      <tr>
        <td>Contact</td>
        <td><?php echo $row['mechanic_contact']; ?></td>
      </tr>
    </table>
  </form>

  <a href="mechanic_home.php" class="back-btn">⬅ Back to Dashboard</a>
</div>

<div id="toast" class="toast"></div>

<script>
  // Toast Notification from sessionStorage
  document.addEventListener("DOMContentLoaded", () => {
    const msg = sessionStorage.getItem('toastMessage');
    if (msg) {
      const toast = document.getElementById('toast');
      toast.textContent = msg;
      toast.classList.add('show');
      setTimeout(() => { toast.classList.remove('show'); }, 3000);
      sessionStorage.removeItem('toastMessage');
    }
  });
</script>

</body>
</html>
