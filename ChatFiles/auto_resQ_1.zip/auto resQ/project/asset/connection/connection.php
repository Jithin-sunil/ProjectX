<?php
$ServerName="localhost";
$UserName="root";
$DBPassword="";
$DBName="db_autoresq";

$Con=mysqli_connect($ServerName,$UserName,$DBPassword,$DBName);
if (!$Con)
{
	 echo "connection Failed";
	 
} 
 ?>