<?php
include("../connection/connection.php");

$selQry = "SELECT * FROM tbl_workshop u 
           INNER JOIN tbl_place p ON u.place_id=p.place_id 
           INNER JOIN tbl_district d ON d.district_id=p.district_id 
           WHERE workshop_status=1";

if ($_GET['disId'] != "") {
    $selQry .= " AND p.district_id='" . $_GET['disId'] . "'";
}
if ($_GET['disId'] != "" && $_GET['pId'] != "") {
    $selQry .= " AND p.place_id='" . $_GET['pId'] . "'";
}

$result = $Con->query($selQry);
?>

<style>
  body {
    font-family: "Poppins", sans-serif;
    background: #fff7f7;
    margin: 0;
    padding: 20px;
  }

  .header {
    text-align: center;
    margin-bottom: 25px;
  }

  .header h2 {
    font-size: 28px;
    color: #b71c1c;
    margin-bottom: 5px;
  }

  .header p {
    color: #555;
    font-size: 15px;
  }

  .workshop-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    justify-content: center;
    padding: 10px 20px;
  }

  .workshop-card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 6px 20px rgba(183, 28, 28, 0.1);
    overflow: hidden;
    transition: all 0.3s ease;
  }

  .workshop-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 10px 25px rgba(183, 28, 28, 0.25);
  }

  .workshop-photo {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-bottom: 4px solid #b71c1c;
  }

  .workshop-content {
    padding: 16px 18px;
    text-align: center;
  }

  .workshop-content h3 {
    color: #b71c1c;
    font-size: 20px;
    margin: 10px 0;
  }

  .workshop-content p {
    color: #333;
    font-size: 14px;
    margin: 5px 0;
  }

  .rating {
    margin-top: 10px;
  }

  .rating i {
    color: #ffc107;
    font-size: 17px;
    margin: 1px;
  }

  .action-btn {
    display: inline-block;
    background: #b71c1c;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    text-decoration: none;
    margin-top: 14px;
    transition: 0.3s;
  }

  .action-btn:hover {
    background: #ff5252;
    transform: scale(1.05);
  }

  .no-data {
    text-align: center;
    font-size: 18px;
    color: #b71c1c;
    background: #fff0f0;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(183, 28, 28, 0.1);
    width: fit-content;
    margin: 60px auto;
  }
</style>

<!-- <div class="header">
  <h2><i class="fas fa-tools"></i> Workshop Listings</h2>
  <p>Browse workshops available in your selected district and place.</p>
</div> -->

<div class="workshop-container">
<?php
if ($result->num_rows > 0) {
    while ($row1 = $result->fetch_assoc()) {
        // Rating Calculation
        $average_rating = 0;
        $total_review = 0;
        $total_user_rating = 0;

        $query = "SELECT * FROM tbl_rating WHERE workshop_id = '" . $row1["shop_id"] . "' ORDER BY rating_id DESC";
        $resultRating = $Con->query($query);
        while ($row = $resultRating->fetch_assoc()) {
            $total_user_rating += $row["rating_data"];
            $total_review++;
        }

        if ($total_review > 0) {
            $average_rating = $total_user_rating / $total_review;
        }

        $fullStars = floor($average_rating);
        $halfStar = ($average_rating - $fullStars) >= 0.5 ? 1 : 0;
        $emptyStars = 5 - ($fullStars + $halfStar);
        ?>
        
        <div class="workshop-card">
          <img class="workshop-photo" src="../asset/Files/WorkShop/Photo/<?php echo $row1['shop_photo']; ?>" alt="Workshop Photo" />
          <div class="workshop-content">
            <h3><?php echo $row1['shop_name']; ?></h3>
            <p><strong>Email:</strong> <?php echo $row1['shop_email']; ?></p>
            <p><strong>Address:</strong> <?php echo $row1['shop_address']; ?></p>
            <p><strong>Contact:</strong> <?php echo $row1['shop_contact']; ?></p>
            <p><strong>District:</strong> <?php echo $row1['district_name']; ?></p>
            <p><strong>Place:</strong> <?php echo $row1['place_name']; ?></p>

            <div class="rating">
              <?php
                for ($j = 0; $j < $fullStars; $j++) echo '<i class="fas fa-star"></i>';
                if ($halfStar) echo '<i class="fas fa-star-half-alt"></i>';
                for ($j = 0; $j < $emptyStars; $j++) echo '<i class="far fa-star"></i>';
              ?>
            </div>

            <a href="Request.php?wid=<?php echo $row1['shop_id']; ?>" class="action-btn">
              <i class="fas fa-paper-plane"></i> Send Request
            </a>
          </div>
        </div>
<?php
    }
} else {
    echo '<div class="no-data"><i class="fas fa-info-circle"></i> No workshops found for your selected location.</div>';
}
?>
</div>

<!-- FontAwesome -->
<script src="https://kit.fontawesome.com/a81368914c.js" crossorigin="anonymous"></script>
