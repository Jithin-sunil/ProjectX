<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * FROM tbl_workshop WHERE shop_id='" . $_SESSION['wid'] . "'";
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();
$shoppassword = $row['shop_password'];

if (isset($_POST['btn'])) {
    $oldpass = $_POST['oldpass'];
    $newpass = $_POST['newpass'];
    $repass = $_POST['retypepass'];

    if ($oldpass == $shoppassword) {
        if ($newpass == $repass) {
            $UpQry = "UPDATE tbl_workshop SET shop_password='" . $newpass . "' WHERE shop_id='" . $_SESSION['wid'] . "'";
            if ($Con->query($UpQry)) {
                echo "<script>alert('✅ Password Updated Successfully'); window.location='MyProfile.php';</script>";
            }
        } else {
            echo "<script>alert('⚠️ Password Mismatch');</script>";
        }
    } else {
        echo "<script>alert('❌ Incorrect Old Password');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Change Password</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #0a0a0a, #330000);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  color: #fff;
  margin: 0;
}

.container {
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(12px);
  padding: 40px;
  border-radius: 20px;
  box-shadow: 0 0 25px rgba(255, 0, 0, 0.3);
  width: 360px;
  text-align: center;
  animation: fadeIn 0.6s ease;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

.container h2 {
  color: #ff3333;
  margin-bottom: 25px;
  font-size: 22px;
  text-shadow: 0 0 10px rgba(255,0,0,0.5);
}

/* Input Box */
.input-group {
  position: relative;
  margin-bottom: 20px;
}

.input-group input {
  width: 100%;
  padding: 12px 45px 12px 15px;
  border: none;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
  font-size: 14px;
  outline: none;
  transition: 0.3s;
}

.input-group input:focus {
  background: rgba(255, 255, 255, 0.2);
  box-shadow: 0 0 10px rgba(255,0,0,0.4);
}

/* Right Icons (eye, lock) */
.input-group i {
  position: absolute;
  right: 15px;
  top: 12px;
  color: #ff6666;
  cursor: pointer;
}

/* Submit Button */
button {
  width: 100%;
  background: #ff3333;
  border: none;
  padding: 12px;
  border-radius: 10px;
  color: white;
  font-weight: 600;
  font-size: 15px;
  cursor: pointer;
  transition: 0.3s;
}

button:hover {
  background: #ff5555;
  box-shadow: 0 0 15px rgba(255,0,0,0.5);
  transform: translateY(-2px);
}

small {
  display: block;
  color: #ccc;
  font-size: 12px;
  margin-top: 10px;
}
</style>
</head>
<body>

<div class="container">
  <h2><i class="fa-solid fa-lock"></i> Change Password</h2>
  <form method="post">
    
    <div class="input-group">
      <input type="password" id="oldpass" name="oldpass" placeholder="Old Password" required
        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
        title="Must contain at least one number, one uppercase and lowercase letter, and 8+ characters">
      <i class="fa-solid fa-eye" id="toggleOld" onclick="togglePassword('oldpass','toggleOld')"></i>
    </div>

    <div class="input-group">
      <input type="password" id="newpass" name="newpass" placeholder="New Password" required
        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
        title="Must contain at least one number, one uppercase and lowercase letter, and 8+ characters">
      <i class="fa-solid fa-eye" id="toggleNew" onclick="togglePassword('newpass','toggleNew')"></i>
    </div>

    <div class="input-group">
      <input type="password" id="retypepass" name="retypepass" placeholder="Re-type Password" required
        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
        title="Must contain at least one number, one uppercase and lowercase letter, and 8+ characters">
      <i class="fa-solid fa-eye" id="toggleRetype" onclick="togglePassword('retypepass','toggleRetype')"></i>
    </div>

    <button type="submit" name="btn"><i class="fa-solid fa-rotate"></i> Update Password</button>

    <small>Must include uppercase, lowercase, and a number (min 8 characters)</small>
  </form>
</div>

<script>
function togglePassword(fieldId, iconId) {
  const field = document.getElementById(fieldId);
  const icon = document.getElementById(iconId);
  if (field.type === "password") {
    field.type = "text";
    icon.classList.remove("fa-eye");
    icon.classList.add("fa-eye-slash");
  } else {
    field.type = "password";
    icon.classList.remove("fa-eye-slash");
    icon.classList.add("fa-eye");
  }
}
</script>

</body>
</html>
