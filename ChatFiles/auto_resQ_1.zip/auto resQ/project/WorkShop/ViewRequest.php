<?php
include("../asset/Connection/Connection.php");
session_start();

if (!isset($_SESSION['wid'])) {
    header("Location: login.php");
    exit();
}

// Handle Accept/Reject
if (isset($_GET["ch"]) || isset($_GET["mh"])) {
    $status = isset($_GET["ch"]) ? 1 : 2;
    $request_id = intval(isset($_GET["ch"]) ? $_GET["ch"] : $_GET["mh"]);

    $stmt = $Con->prepare("UPDATE tbl_request SET request_status = ? WHERE request_id = ?");
    $stmt->bind_param("ii", $status, $request_id);
    $stmt->execute();
    header("Location: ViewRequest.php?msg=updated");
    exit();
}

// Filter + Search
$filter = isset($_GET['status']) ? intval($_GET['status']) : -1;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$query = "SELECT r.*, u.user_name, b.brand_name, c.category_name 
          FROM tbl_request r
          INNER JOIN tbl_user u ON r.user_id = u.user_id
          INNER JOIN tbl_brand b ON r.brand_id = b.brand_id
          INNER JOIN tbl_category c ON r.category_id = c.category_id
          WHERE r.workshop_id = " . intval($_SESSION['wid']);

if ($filter >= 0) $query .= " AND r.request_status = $filter";
if ($search !== '') $query .= " AND (u.user_name LIKE '%$search%' OR r.request_title LIKE '%$search%' OR r.vehicle_no LIKE '%$search%')";
$result = $Con->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Workshop | View Requests</title>
<style>
body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
  background: #0a0a0a;
  color: #f5f5f5;
  display: flex;
}

/* Sidebar */
.sidebar {
  width: 220px;
  height: 100vh;
  background: linear-gradient(180deg, #111, #1a1a1a);
  box-shadow: 2px 0 15px rgba(255, 0, 0, 0.3);
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 30px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.sidebar h2 {
  color: #ff3b3b;
  margin-bottom: 40px;
  letter-spacing: 1px;
}
.sidebar a {
  text-decoration: none;
  color: #eee;
  display: block;
  width: 80%;
  text-align: center;
  padding: 10px;
  margin: 10px 0;
  border-radius: 8px;
  transition: background 0.3s, color 0.3s;
}
.sidebar a:hover, .sidebar a.active {
  background: #ff3b3b;
  color: #fff;
}

/* Main */
.main {
  margin-left: 240px;
  width: calc(100% - 240px);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* Topbar */
.topbar {
  background: rgba(255, 255, 255, 0.05);
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 15px rgba(255,0,0,0.2);
}
.topbar h1 {
  color: #ff3b3b;
  font-size: 20px;
  margin: 0;
}
.profile {
  display: flex;
  align-items: center;
  gap: 10px;
}
.profile img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: 2px solid #ff3b3b;
}

/* Search Bar */
.filter-bar {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 15px;
  margin: 20px auto;
  background: rgba(255,255,255,0.05);
  padding: 15px;
  border-radius: 10px;
  width: 85%;
  box-shadow: 0 0 10px rgba(255,0,0,0.2);
}
.filter-bar input, .filter-bar select, .filter-bar button {
  padding: 8px 12px;
  border: none;
  border-radius: 6px;
  outline: none;
  background: #1a1a1a;
  color: #fff;
  border: 1px solid #ff3b3b;
}
.filter-bar button {
  background: #ff3b3b;
  cursor: pointer;
  transition: background 0.3s;
}
.filter-bar button:hover {
  background: #f33f3fff;
}

/* Request Cards */
.request-card {
  background: rgba(255,255,255,0.05);
  border: 1px solid #fa2424ff;
  border-radius: 15px;
  padding: 20px;
  margin: 20px auto;
  width: 90%;
  max-width: 850px;
  box-shadow: 0 0 20px rgba(255,0,0,0.2);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.request-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 0 25px rgba(255,0,0,0.4);
}
.card-header {
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid rgba(255,255,255,0.1);
  padding-bottom: 10px;
  margin-bottom: 10px;
}
.card-header h3 { color: #ff3b3b; }
.actions a {
  text-decoration: none;
  background: #ff3b3b;
  color: #fff;
  padding: 6px 12px;
  border-radius: 6px;
  margin-right: 10px;
}
.actions a:hover { background: #ff5555; }

/* Status Stepper */
.status-steps {
  list-style-type: none;
  display: flex;
  justify-content: space-between;
  padding: 0;
  margin: 20px 0 0;
  position: relative;
}
.status-steps::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 5%;
  right: 5%;
  height: 3px;
  background: rgba(255,255,255,0.1);
}
.status-steps li {
  position: relative;
  text-align: center;
  color: #999;
  flex: 1;
  font-size: 13px;
}
.status-steps li::before {
  content: '';
  display: block;
  margin: 0 auto 6px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #555;
  border: 2px solid #666;
}
.status-steps li.active { color: #ff3b3b; }
.status-steps li.active::before {
  background: #ff3b3b;
  border-color: #ff3b3b;
}
.status-steps li.rejected {
  color: red;
}
.status-steps li.rejected::before {
  background: red;
  border-color: red;
}
</style>
</head>
<body>

<div class="sidebar">
  <h2>Workshop</h2>
  <a href="HomePage.php">🏠 Dashboard</a>
  <a href="ViewRequest.php" class="active">📋 View Requests</a>
  <!-- <a href="AssignMechanic.php">🧰 Mechanics</a> -->
  <a href="../Guest/logout.php">🚪 Logout</a>
</div>

<div class="main">
  <div class="topbar">
    <h1>All Customer Requests</h1>
    <div class="profile">
      <img src="../asset/images/workshop.png" alt="Profile">
      <span>Welcome, Workshop</span>
    </div>
  </div>

  <!-- Filter Bar -->
  <form class="filter-bar" method="get" action="">
    <input type="text" name="search" placeholder="🔍 Search by name, title, or vehicle" value="<?php echo htmlspecialchars($search); ?>" />
    <select name="status">
      <option value="-1" <?php if($filter==-1) echo "selected"; ?>>All Status</option>
      <option value="0" <?php if($filter==0) echo "selected"; ?>>Pending</option>
      <option value="1" <?php if($filter==1) echo "selected"; ?>>Accepted</option>
      <option value="2" <?php if($filter==2) echo "selected"; ?>>Rejected</option>
      <option value="3" <?php if($filter==3) echo "selected"; ?>>Assigned</option>
      <option value="4" <?php if($filter==4) echo "selected"; ?>>Work Started</option>
      <option value="5" <?php if($filter==5) echo "selected"; ?>>Work Completed</option>
      <option value="6" <?php if($filter==6) echo "selected"; ?>>Payment Completed</option>
    </select>
    <button type="submit">Filter</button>
  </form>

  <?php while ($row = $result->fetch_assoc()) {
      $status = intval($row["request_status"]); ?>
  <div class="request-card">
    <div class="card-header">
      <h3><?php echo htmlspecialchars($row["request_title"]); ?></h3>
      <span>📅 <?php echo htmlspecialchars($row["request_date"]); ?></span>
    </div>
    <div class="card-body">
      <p><strong>Customer:</strong> <?php echo htmlspecialchars($row["user_name"]); ?></p>
      <p><strong>Location:</strong> <?php echo htmlspecialchars($row["request_location"]); ?></p>
      <p><strong>Details:</strong> <?php echo htmlspecialchars($row["request_content"]); ?></p>
      <p><strong>Vehicle:</strong> <?php echo htmlspecialchars($row["vehicle_no"]); ?> |
         <strong>Brand:</strong> <?php echo htmlspecialchars($row["brand_name"]); ?> |
         <strong>Category:</strong> <?php echo htmlspecialchars($row["category_name"]); ?></p>

      <div class="actions">
        <?php 
          if ($status === 0) {
            echo '<a href="ViewRequest.php?ch=' . $row["request_id"] . '">Accept</a>';
            echo '<a href="ViewRequest.php?mh=' . $row["request_id"] . '" style="background:red;">Reject</a>';
          } elseif ($status === 1) {
            echo '✅ Accepted | <a href="AssignMechanic.php?mh=' . $row["request_id"] . '">Assign Mechanic</a>';
          } elseif ($status === 2) {
            echo '❌ Rejected';
          } elseif ($status === 3 || $status === 4) {
            $selQry = "SELECT mechanic_name FROM tbl_mechanic WHERE mechanic_id = '" . intval($row["mechanic_id"]) . "'"; 
            $resulta = $Con->query($selQry);
            $rowa = $resulta->fetch_assoc();
            echo ($status === 3) ? "🧰 Assigned To " . htmlspecialchars($rowa["mechanic_name"]) : htmlspecialchars($rowa["mechanic_name"]) . " 🛠 Started Work";
          } elseif ($status === 5) {
            echo "⏳ Work Completed, Waiting for Payment";
          } elseif ($status === 6) {
            echo "💰 Payment Completed";
          }
        ?>
      </div>

      <ul class="status-steps">
        <?php 
        if ($status === 2) {
          echo '<li class="active">Pending</li>';
          echo '<li class="rejected">Rejected</li>';
        } else {
          echo '<li class="' . ($status >= 0 ? 'active' : '') . '">Pending</li>';
          echo '<li class="' . ($status >= 1 ? 'active' : '') . '">Accepted</li>';
          echo '<li class="' . ($status >= 3 ? 'active' : '') . '">Assigned</li>';
          echo '<li class="' . ($status >= 4 ? 'active' : '') . '">Work Started</li>';
          echo '<li class="' . ($status >= 5 ? 'active' : '') . '">Work Completed</li>';
          echo '<li class="' . ($status == 6 ? 'active' : '') . '">Payment Done</li>';
        } ?>
      </ul>
    </div>
  </div>
  <?php } ?>
</div>
</body>
</html>
