<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * FROM tbl_workshop WHERE shop_id='" . $_SESSION['wid'] . "'";
$result = $Con->query($SelQry);
$data = $result->fetch_assoc();

if (isset($_POST['btn'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];

    // Handle profile image update
    $photo = $data['shop_photo'];
    if ($_FILES['photo']['name'] != "") {
        $photo = $_FILES['photo']['name'];
        $temp = $_FILES['photo']['tmp_name'];
        move_uploaded_file($temp, "../asset/Files/WorkShop/Photo/" . $photo);
    }

    $UpQry = "UPDATE tbl_workshop SET 
                shop_name='$name',
                shop_email='$email',
                shop_contact='$contact',
                shop_address='$address',
                shop_photo='$photo'
              WHERE shop_id='" . $_SESSION['wid'] . "'";
    
    if ($Con->query($UpQry)) {
        echo "<script>alert('✅ Profile Updated Successfully'); window.location='MyProfile.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Workshop Profile</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* Reset & Layout */
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  font-family: 'Poppins', sans-serif;
  background: #0f0f0f;
  color: #fff;
  display: flex;
  height: 100vh;
}

/* Sidebar */
.sidebar {
  width: 220px;
  background: #1a1a1a;
  padding: 30px 0;
  text-align: center;
  box-shadow: 4px 0 15px rgba(255, 0, 0, 0.2);
}
.sidebar h2 {
  color: #ff3333;
  margin-bottom: 40px;
  font-size: 22px;
}
.sidebar a {
  display: block;
  color: #ccc;
  text-decoration: none;
  padding: 12px 0;
  margin: 8px 20px;
  border-radius: 10px;
  transition: 0.3s;
}
.sidebar a:hover, .sidebar a.active {
  background: #ff3333;
  color: #fff;
  box-shadow: 0 0 10px rgba(255,0,0,0.6);
}

/* Container */
.container {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #111, #1c1c1c);
}

/* Profile Card */
.form-card {
  width: 460px;
  background: rgba(255, 255, 255, 0.06);
  backdrop-filter: blur(12px);
  border-radius: 20px;
  padding: 40px;
  box-shadow: 0 0 25px rgba(255, 0, 0, 0.25);
  animation: slideIn 0.5s ease-out;
}
@keyframes slideIn {
  from { transform: translateY(30px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}
.form-card h2 {
  text-align: center;
  color: #ff3333;
  margin-bottom: 25px;
  font-size: 22px;
}

/* Profile Image */
.image-upload {
  position: relative;
  text-align: center;
  margin-bottom: 20px;
}
.profile-avatar {
  width: 110px;
  height: 110px;
  border-radius: 50%;
  border: 3px solid #ff3333;
  object-fit: cover;
  transition: 0.3s;
}
.profile-avatar:hover {
  box-shadow: 0 0 15px rgba(255,0,0,0.5);
}
.upload-icon {
  position: absolute;
  bottom: 0;
  right: 42%;
  background: #ff3333;
  border-radius: 50%;
  padding: 6px;
  cursor: pointer;
  transition: 0.3s;
}
.upload-icon:hover {
  background: #ff5555;
  transform: scale(1.1);
}
#photo-input {
  display: none;
}

/* Input Groups */
.input-group {
  margin-bottom: 18px;
}
.input-group label {
  font-size: 14px;
  color: #ccc;
  margin-bottom: 6px;
  display: block;
}
.input-group input, 
.input-group textarea {
  width: 100%;
  padding: 12px;
  border: none;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
  font-size: 14px;
  outline: none;
  transition: 0.3s;
  resize: none;
}
.input-group input:focus,
.input-group textarea:focus {
  background: rgba(255, 255, 255, 0.2);
  box-shadow: 0 0 10px rgba(255,0,0,0.4);
}

/* Button */
button {
  width: 100%;
  padding: 12px;
  background: #ff3333;
  border: none;
  border-radius: 10px;
  color: white;
  font-weight: 600;
  font-size: 15px;
  cursor: pointer;
  transition: 0.3s;
}
button:hover {
  background: #ff5555;
  box-shadow: 0 0 15px rgba(255,0,0,0.5);
  transform: translateY(-2px);
}
</style>
</head>
<body>

<!-- Sidebar -->
<!-- <div class="sidebar">
  <h2>Workshop</h2>
  <a href="DasHomePage.php"><i class="fa-solid fa-house"></i> Dashboard</a>
  <a href="Myprofile.php" class="active"><i class="fa-solid fa-user"></i> Profile</a>
  <a href="Changepassword.php"><i class="fa-solid fa-lock"></i> Change Password</a>
  <a href="Logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div> -->

<!-- Main Content -->
<div class="container">
  <div class="form-card">
    <form method="post" enctype="multipart/form-data">
      <div class="image-upload">
        <img id="profile-img" src="../asset/Files/WorkShop/Photo/<?php echo $data['shop_photo'] ?: 'default.png'; ?>" alt="Profile" class="profile-avatar">
        <label for="photo-input" class="upload-icon">
          <i class="fa-solid fa-camera"></i>
        </label>
        <input type="file" id="photo-input" name="photo" accept="image/*" onchange="previewImage(event)">
      </div>

      <h2><i class="fa-solid fa-user-pen"></i> Edit Profile</h2>

      <div class="input-group">
        <label><i class="fa-solid fa-building"></i> Workshop Name</label>
        <input type="text" name="name" required value="<?php echo $data['shop_name']; ?>">
      </div>

      <div class="input-group">
        <label><i class="fa-solid fa-envelope"></i> Email</label>
        <input type="email" name="email" required value="<?php echo $data['shop_email']; ?>">
      </div>

      <div class="input-group">
        <label><i class="fa-solid fa-phone"></i> Contact</label>
        <input type="text" name="contact" required value="<?php echo $data['shop_contact']; ?>">
      </div>

      <div class="input-group">
        <label><i class="fa-solid fa-location-dot"></i> Address</label>
        <textarea name="address" required rows="4"><?php echo $data['shop_address']; ?></textarea>
      </div>

      <button type="submit" name="btn"><i class="fa-solid fa-rotate"></i> Update Profile</button>
    </form>
  </div>
</div>

<script>
// Live preview for uploaded image
function previewImage(event) {
  const img = document.getElementById('profile-img');
  img.src = URL.createObjectURL(event.target.files[0]);
}
</script>

</body>
</html>
