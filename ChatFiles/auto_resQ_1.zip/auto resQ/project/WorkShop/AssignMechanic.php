<?php
session_start();
include("../asset/Connection/Connection.php");		

// Store request ID
if (isset($_GET["mh"])) {
    $_SESSION["ch"] = $_GET["mh"];
    header("Location: AssignMechanic.php");
    exit;
}

// Assign mechanic to request
if (isset($_GET["m"])) {
    $update = "UPDATE tbl_request SET request_status='3', mechanic_id='" . $_GET["m"] . "' WHERE request_id='" . $_SESSION["ch"] . "'";
    if ($Con->query($update)) {
        echo "<script>alert('✅ Mechanic Assigned Successfully!'); window.location='ViewRequest.php';</script>";
        exit;
    } else {
        echo "<script>alert('❌ Failed to Assign Mechanic');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Assign Mechanic</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
  font-family: "Poppins", sans-serif;
  background: linear-gradient(135deg, #0a0a0a, #1a0000);
  color: #fff;
  margin: 0;
  padding: 0;
}

/* Header */
h1 {
  text-align: center;
  margin-top: 40px;
  color: #ff3333;
  text-shadow: 0 0 15px rgba(255,0,0,0.6);
}

/* Container */
.container {
  width: 90%;
  margin: 50px auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 25px;
  justify-content: center;
}

/* Mechanic Card */
.card {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 18px;
  padding: 25px;
  text-align: center;
  transition: 0.3s;
  box-shadow: 0 0 25px rgba(255,0,0,0.15);
  backdrop-filter: blur(8px);
  position: relative;
  overflow: hidden;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 0 35px rgba(255,0,0,0.4);
}

/* Circular Image */
.card img {
  width: 130px;
  height: 130px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #ff3333;
  box-shadow: 0 0 15px rgba(255,0,0,0.4);
  margin-bottom: 15px;
  transition: 0.3s;
}

.card img:hover {
  transform: scale(1.05);
  box-shadow: 0 0 25px rgba(255,0,0,0.7);
}

/* Name & Details */
.card h3 {
  color: #ff6666;
  font-size: 20px;
  margin-bottom: 5px;
}

.card p {
  color: #ccc;
  font-size: 14px;
  margin: 4px 0;
}

/* Status Badge */
.status {
  display: inline-block;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 13px;
  font-weight: 600;
  margin-top: 10px;
}
.available {
  background: rgba(0, 255, 100, 0.2);
  color: #00ff88;
  border: 1px solid #00ff88;
}
.busy {
  background: rgba(255, 0, 0, 0.2);
  color: #ff4444;
  border: 1px solid #ff4444;
}

/* Button */
.assign-btn {
  display: inline-block;
  background: #ff3333;
  color: white;
  border: none;
  padding: 10px 22px;
  border-radius: 8px;
  margin-top: 15px;
  text-decoration: none;
  font-weight: 600;
  transition: 0.3s;
}

.assign-btn:hover {
  background: #ff6666;
  box-shadow: 0 0 15px rgba(255,0,0,0.4);
  transform: scale(1.05);
}
</style>
</head>
<body>

<h1><i class="fa-solid fa-users-gear"></i> Assign Mechanic</h1>

<div class="container">
<?php
$i=0;
$selqry = "SELECT * FROM tbl_mechanic WHERE workshop_id='" . $_SESSION["wid"] . "'";
$result = $Con->query($selqry);

while ($row = $result->fetch_assoc()) {
    $i++;

    // Check mechanic status
    $checkWork = "SELECT COUNT(*) AS cnt FROM tbl_request WHERE mechanic_id='" . $row['mechanic_id'] . "' AND request_status IN (3,4)";
    $workRes = $Con->query($checkWork);
    $statusRow = $workRes->fetch_assoc();
    $isBusy = $statusRow['cnt'] > 0;

    $statusClass = $isBusy ? "busy" : "available";
    $statusText = $isBusy ? "Busy" : "Available";
    $statusIcon = $isBusy ? "fa-circle-xmark" : "fa-circle-check";
    
    echo '
    <div class="card">
      <img src="../asset/Files/WorkShop/Photo/'.$row['mechanic_photo'].'" alt="Mechanic">
      <h3>'.$row['mechanic_name'].'</h3>
      <p><i class="fa-solid fa-envelope"></i> '.$row['mechanic_email'].'</p>
      <p><i class="fa-solid fa-phone"></i> '.$row['mechanic_contact'].'</p>
      <span class="status '.$statusClass.'"><i class="fa-solid '.$statusIcon.'"></i> '.$statusText.'</span><br>';
    
    if (!$isBusy) {
        echo '<a href="#" onclick="confirmAssign('.$row['mechanic_id'].')" class="assign-btn">
                <i class="fa-solid fa-check-circle"></i> Assign
              </a>';
    } else {
        echo '<a class="assign-btn" style="background: gray; pointer-events:none;">Assigned</a>';
    }
    
    echo '</div>';
}
?>
</div>

<script>
function confirmAssign(id) {
  if (confirm("⚙️ Are you sure you want to assign this mechanic?")) {
    window.location = "AssignMechanic.php?m=" + id;
  }
}
</script>

</body>
</html>
