<?php
include("../asset/connection/connection.php");
session_start();

// Fetch workshop info
$SelQry = "SELECT * FROM tbl_workshop WHERE shop_id=" . $_SESSION['wid'];
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();

// Count total mechanics
$MechQry = "SELECT COUNT(*) AS total_mechanics FROM tbl_mechanic WHERE workshop_id=" . $_SESSION['wid'];
$mechRes = $Con->query($MechQry);
$mechData = $mechRes->fetch_assoc();
$totalMechanics = $mechData['total_mechanics'];

// Count completed works
$WorkQry = "SELECT COUNT(*) AS completed_works FROM tbl_request WHERE workshop_id=" . $_SESSION['wid'] . " AND request_status='Completed'";
$workRes = $Con->query($WorkQry);
$workData = $workRes->fetch_assoc();
$completedWorks = $workData['completed_works'];

// Count pending works
$PendingQry = "SELECT COUNT(*) AS pending_works FROM tbl_request WHERE workshop_id=" . $_SESSION['wid'] . " AND request_status!='Completed'";
$pendingRes = $Con->query($PendingQry);
$pendingData = $pendingRes->fetch_assoc();
$pendingWorks = $pendingData['pending_works'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Workshop Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body {
  display: flex;
  min-height: 100vh;
  background: linear-gradient(135deg, #0d0d0d, #1c1c1c);
  color: #fff;
  overflow-x: hidden;
}

/* Sidebar */
.sidebar {
  width: 250px;
  background: #1a1a1a;
  padding: 30px 0;
  text-align: center;
  box-shadow: 4px 0 15px rgba(255, 0, 0, 0.3);
  transition: 0.3s;
  position: fixed;
  height: 100%;
  z-index: 1000;
}
.sidebar.hide {
  width: 70px;
}
.sidebar img {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #ff3333;
  margin-bottom: 15px;
  transition: 0.3s;
}
.sidebar img:hover {
  box-shadow: 0 0 15px rgba(255, 0, 0, 0.6);
}
.sidebar h2 {
  color: #ff3333;
  font-size: 20px;
  margin-bottom: 40px;
  transition: 0.3s;
}
.sidebar.hide h2 {
  display: none;
}
.sidebar a {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 12px;
  color: #ccc;
  text-decoration: none;
  padding: 12px 20px;
  margin: 8px 15px;
  border-radius: 10px;
  transition: 0.3s;
  font-weight: 500;
}
.sidebar a:hover {
  background: #ff3333;
  color: #fff;
  box-shadow: 0 0 12px rgba(255,0,0,0.6);
}
.sidebar.hide a span {
  display: none;
}

/* Toggle Button */
.toggle-btn {
  position: fixed;
  left: 260px;
  top: 20px;
  font-size: 22px;
  background: #ff3333;
  color: white;
  padding: 10px;
  border-radius: 50%;
  cursor: pointer;
  transition: 0.3s;
  z-index: 1100;
}
.sidebar.hide + .toggle-btn {
  left: 80px;
}

/* Main Section */
.main-content {
  margin-left: 250px;
  flex: 1;
  padding: 80px 40px;
  text-align: center;
  transition: 0.3s;
}
.sidebar.hide ~ .main-content {
  margin-left: 70px;
}
.main-content h1 {
  font-size: 28px;
  color: #ff3333;
  margin-bottom: 10px;
}
.main-content p {
  font-size: 15px;
  color: #bbb;
  max-width: 600px;
  line-height: 1.6;
  margin: 0 auto 50px auto;
}

/* Stats Section */
.stats {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 25px;
}
.stat-box {
  background: rgba(255, 51, 51, 0.1);
  border: 2px solid #ff3333;
  padding: 25px 40px;
  border-radius: 20px;
  box-shadow: 0 0 15px rgba(255,0,0,0.3);
  transition: 0.3s;
  width: 230px;
  animation: fadeUp 1s ease-out;
}
.stat-box:hover {
  transform: translateY(-6px);
  box-shadow: 0 0 25px rgba(255,0,0,0.6);
}
.stat-box i {
  font-size: 40px;
  color: #ff3333;
  margin-bottom: 10px;
}
.stat-box h3 {
  font-size: 34px;
  color: #fff;
  margin: 5px 0;
}
.stat-box p {
  color: #aaa;
  font-size: 14px;
}

/* Responsive */
@media (max-width: 768px) {
  .sidebar {
    position: fixed;
    width: 70px;
  }
  .toggle-btn {
    left: 80px;
  }
  .main-content {
    margin-left: 70px;
    padding: 60px 20px;
  }
  .stat-box {
    width: 100%;
    max-width: 300px;
  }
}

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <img src="../asset/Files/WorkShop/Photo/<?php echo $row['shop_photo'] ?: 'default.png'; ?>" alt="Profile Photo">
  <h2><?php echo strtoupper($row['shop_name']); ?></h2>

  <a href="MyProfile.php"><i class="fa-solid fa-id-card"></i><span> My Profile</span></a>
  <a href="EditProfile.php"><i class="fa-solid fa-pen-to-square"></i><span> Edit Profile</span></a>
  <a href="ChangePassword.php"><i class="fa-solid fa-lock"></i><span> Change Password</span></a>
  <a href="AddMechanic.php"><i class="fa-solid fa-user-plus"></i><span> Add Mechanic</span></a>
  <a href="AssignMechanic.php"><i class="fa-solid fa-user-gear"></i><span> Assign Mechanic</span></a>
  <a href="ViewRequest.php"><i class="fa-solid fa-list"></i><span> View Requests</span></a>
  <a href="../Guest/Logout.php"><i class="fa-solid fa-right-from-bracket"></i><span> Logout</span></a>
</div>

<!-- Toggle Button -->
<div class="toggle-btn" id="toggleBtn">
  <i class="fa-solid fa-bars"></i>
</div>

<!-- Main Content -->
<div class="main-content">
  <h1>Welcome, <?php echo $row['shop_name']; ?> 👋</h1>
  <p>Manage your mechanics, track ongoing and completed jobs, and monitor workshop activity — all from one sleek, responsive dashboard.</p>

  <div class="stats">
    <div class="stat-box">
      <i class="fa-solid fa-users"></i>
      <h3 class="counter" data-target="<?php echo $totalMechanics; ?>">0</h3>
      <p>Total Mechanics</p>
    </div>

    <div class="stat-box">
      <i class="fa-solid fa-screwdriver-wrench"></i>
      <h3 class="counter" data-target="<?php echo $completedWorks; ?>">0</h3>
      <p>Completed Works</p>
    </div>

    <div class="stat-box">
      <i class="fa-solid fa-hourglass-half"></i>
      <h3 class="counter" data-target="<?php echo $pendingWorks; ?>">0</h3>
      <p>Pending Works</p>
    </div>
  </div>
</div>

<!-- JS: Sidebar toggle + counter animation -->
<script>
const sidebar = document.getElementById('sidebar');
const toggleBtn = document.getElementById('toggleBtn');
toggleBtn.onclick = () => {
  sidebar.classList.toggle('hide');
};

// Counter animation
const counters = document.querySelectorAll('.counter');
counters.forEach(counter => {
  counter.innerText = '0';
  const updateCount = () => {
    const target = +counter.getAttribute('data-target');
    const count = +counter.innerText;
    const speed = 100;
    const increment = target / speed;
    if(count < target) {
      counter.innerText = Math.ceil(count + increment);
      setTimeout(updateCount, 25);
    } else {
      counter.innerText = target;
    }
  };
  updateCount();
});
</script>

</body>
</html>
