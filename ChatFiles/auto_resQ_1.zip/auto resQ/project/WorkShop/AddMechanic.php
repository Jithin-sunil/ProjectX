<?php
include("../asset/connection/connection.php");
session_start();

if (isset($_POST['btn'])) {
    $mechname = $_POST['name'];
    $mechmail = $_POST['email'];
    $contact = $_POST['contact'];
    $password = $_POST['password'];
    $photo = $_FILES['photo']['name'];
    $temp = $_FILES['photo']['tmp_name'];
    move_uploaded_file($temp, '../asset/Files/WorkShop/Photo/' . $photo);

    $insQry = "INSERT INTO tbl_mechanic (mechanic_name, mechanic_email, mechanic_contact, mechanic_password, mechanic_photo, workshop_id)
               VALUES ('$mechname', '$mechmail', '$contact', '$password', '$photo', '" . $_SESSION['wid'] . "')";

    if ($Con->query($insQry)) {
        echo "<script>
                alert('✅ Mechanic added successfully!');
                window.location='AddMechanic.php';
              </script>";
    } else {
        echo "<script>alert('❌ Error inserting mechanic');</script>";
    }
}

if (isset($_GET['did'])) {
    $delQry = "DELETE FROM tbl_mechanic WHERE mechanic_id='" . $_GET['did'] . "'";
    if ($Con->query($delQry)) {
        echo "<script>
                alert('🗑️ Mechanic deleted successfully!');
                window.location='AddMechanic.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ | Add Mechanic</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ===== GENERAL STYLING ===== */
body {
  font-family: "Poppins", sans-serif;
  background: radial-gradient(circle at top, #250000, #000);
  color: #fff;
  margin: 0;
  padding: 0;
}
.container {
  max-width: 1000px;
  margin: 80px auto;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 15px;
  box-shadow: 0 0 25px rgba(255, 0, 0, 0.3);
  padding: 40px;
  backdrop-filter: blur(8px);
}

/* ===== NAVBAR ===== */
.navbar {
  background: rgba(20,20,20,0.95);
  padding: 15px 50px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 2px solid rgba(255,0,0,0.4);
  box-shadow: 0 2px 15px rgba(255,0,0,0.2);
}
.navbar .logo {
  color: #ff3333;
  font-size: 22px;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 8px;
}
.navbar ul {
  list-style: none;
  display: flex;
  gap: 25px;
  margin: 0;
}
.navbar ul li a {
  color: #fff;
  text-decoration: none;
  font-weight: 500;
}
.navbar ul li a:hover {
  color: #ff3333;
}

/* ===== TITLE ===== */
h1 {
  text-align: center;
  color: #ff3333;
  text-shadow: 0 0 15px rgba(255,0,0,0.7);
}

/* ===== FORM ===== */
form {
  margin-top: 30px;
}
label {
  font-weight: 600;
  color: #ff9999;
  margin-top: 15px;
  display: block;
}
input[type="text"],
input[type="file"],
input[type="password"] {
  width: 100%;
  padding: 12px;
  margin-top: 5px;
  border: none;
  border-radius: 8px;
  background: rgba(255,255,255,0.1);
  color: white;
  font-size: 15px;
  outline: none;
  transition: 0.3s;
}
input:focus {
  background: rgba(255,255,255,0.2);
  box-shadow: 0 0 10px rgba(255,0,0,0.5);
}
.btn {
  width: 100%;
  margin-top: 25px;
  background: #ff3333;
  border: none;
  color: white;
  padding: 15px;
  font-size: 16px;
  border-radius: 10px;
  cursor: pointer;
  transition: 0.3s;
  font-weight: 600;
}
.btn:hover {
  background: #ff6666;
  transform: scale(1.03);
}

/* ===== TABLE ===== */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 40px;
}
th, td {
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  text-align: center;
  padding: 12px;
}
th {
  background: rgba(255, 51, 51, 0.3);
  color: #fff;
}
tr:hover {
  background: rgba(255, 51, 51, 0.1);
}
img {
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(255,0,0,0.4);
}
a.delete {
  color: #ff6666;
  text-decoration: none;
  font-weight: 600;
  transition: 0.3s;
}
a.delete:hover {
  color: #ff0000;
  text-shadow: 0 0 10px red;
}
</style>
</head>

<body>

<div class="navbar">
  <div class="logo"><i class="fas fa-car-burst"></i> AutoResQ</div>
  <ul>
    <li><a href="WorkshopHome.php"><i class="fas fa-home"></i> Home</a></li>
    <li><a href="AddMechanic.php"><i class="fas fa-users-gear"></i> Mechanics</a></li>
    <li><a href="../Guest/Login.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  </ul>
</div>

<div class="container">
  <h1><i class="fas fa-user-gear"></i> Add Mechanic</h1>

  <form method="post" enctype="multipart/form-data">
    <label><i class="fa-solid fa-user"></i> Name</label>
    <input required type="text" name="name" placeholder="Enter mechanic name">

    <label><i class="fa-solid fa-envelope"></i> Email</label>
    <input required type="text" name="email" placeholder="Enter email">

    <label><i class="fa-solid fa-phone"></i> Contact</label>
    <input required type="text" name="contact" placeholder="Enter contact number">

    <label><i class="fa-solid fa-image"></i> Photo</label>
    <input required type="file" name="photo">

    <label><i class="fa-solid fa-lock"></i> Password</label>
    <input required type="text" name="password"
      pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
      title="Must contain at least one number and one uppercase and lowercase letter, and 8 or more characters"
      placeholder="Create a strong password">

    <button type="submit" name="btn" class="btn"><i class="fa-solid fa-plus"></i> Add Mechanic</button>
  </form>

  <h2 style="margin-top:50px; text-align:center; color:#ff6666;">Existing Mechanics</h2>
  <table>
    <tr>
      <th>Sl.No</th>
      <th>Name</th>
      <th>Email</th>
      <th>Contact</th>
      <th>Photo</th>
      <th>Action</th>
    </tr>
    <?php
    $i = 0;
    $selQry = "SELECT * FROM tbl_mechanic WHERE workshop_id='" . $_SESSION['wid'] . "'";
    $result = $Con->query($selQry);
    while ($row = $result->fetch_assoc()) {
        $i++;
        echo "
        <tr>
          <td>$i</td>
          <td>{$row['mechanic_name']}</td>
          <td>{$row['mechanic_email']}</td>
          <td>{$row['mechanic_contact']}</td>
          <td><img src='../asset/Files/WorkShop/Photo/{$row['mechanic_photo']}' width='150' height='120'></td>
          <td><a href='#' onclick='confirmDelete({$row['mechanic_id']})' class='delete'><i class=\"fas fa-trash\"></i> Delete</a></td>
        </tr>";
    }
    ?>
  </table>
</div>

<script>
function confirmDelete(id) {
  if (confirm("⚠️ Are you sure you want to delete this mechanic?")) {
    window.location = "AddMechanic.php?did=" + id;
  }
}
</script>

</body>
</html>
