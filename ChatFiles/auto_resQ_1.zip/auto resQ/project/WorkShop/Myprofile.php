<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * 
           FROM tbl_workshop u 
           INNER JOIN tbl_place p ON u.place_id = p.place_id 
           INNER JOIN tbl_district d ON p.district_id = d.district_id 
           WHERE shop_id = " . $_SESSION['wid'];
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Workshop Profile</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #111, #222);
  color: #fff;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  margin: 0;
}
.profile-container {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid #ff3333;
  box-shadow: 0 0 20px rgba(255, 0, 0, 0.3);
  border-radius: 20px;
  padding: 30px 50px;
  width: 90%;
  max-width: 700px;
  text-align: center;
}
.profile-container h2 {
  color: #ff3333;
  margin-bottom: 20px;
  font-size: 26px;
  letter-spacing: 1px;
}
.images {
  display: flex;
  justify-content: center;
  gap: 30px;
  margin-bottom: 25px;
  flex-wrap: wrap;
}
.images div {
  text-align: center;
}
.images img {
  width: 180px;
  height: 180px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #ff3333;
  box-shadow: 0 0 15px rgba(255,0,0,0.4);
}
.images label {
  display: block;
  margin-top: 8px;
  color: #ccc;
  font-size: 14px;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}
td {
  padding: 12px 10px;
  text-align: left;
  font-size: 15px;
}
td:first-child {
  color: #ff3333;
  width: 35%;
  font-weight: bold;
}
td:last-child {
  color: #eee;
}
@media (max-width: 600px) {
  .images img {
    width: 130px;
    height: 130px;
  }
  td {
    display: block;
    text-align: center;
  }
  td:first-child {
    text-align: center;
  }
}
</style>
</head>

<body>
  <div class="profile-container">
    <h2>Workshop Profile</h2>
    <div class="images">
      <div>
        <img src="../asset/Files/WorkShop/Photo/<?php echo $row['shop_photo']; ?>" alt="Workshop Photo">
        <label>Profile Photo</label>
      </div>
      <div>
        <img src="../asset/Files/WorkShop/Photo/<?php echo $row['shop_proof']; ?>" alt="Proof Document">
        <label>Proof Document</label>
      </div>
    </div>

    <table>
      <tr><td>Name</td><td><?php echo $row['shop_name']; ?></td></tr>
      <tr><td>Email</td><td><?php echo $row['shop_email']; ?></td></tr>
      <tr><td>Contact</td><td><?php echo $row['shop_contact']; ?></td></tr>
      <tr><td>Address</td><td><?php echo $row['shop_address']; ?></td></tr>
      <tr><td>District</td><td><?php echo $row['district_name']; ?></td></tr>
      <tr><td>Place</td><td><?php echo $row['place_name']; ?></td></tr>
    </table>
  </div>
</body>
</html>
