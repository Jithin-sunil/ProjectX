<?php
include("../asset/connection/connection.php");
session_start();

if (isset($_POST['btn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $SelUser = "select * from tbl_user where user_email='$email' and user_password='$password'";
    $resultUser = $Con->query($SelUser);

    $workshop = "select * from tbl_workshop where shop_email='$email' and shop_password='$password'";
    $resWorkshop = $Con->query($workshop);

    $mechanic = "select * from tbl_mechanic where mechanic_email='$email' and mechanic_password='$password'";
    $resMechanic = $Con->query($mechanic);

    $admin = "select * from tbl_admin where admin_email='$email' and admin_password='$password'";
    $resAdmin = $Con->query($admin);

    if ($rowUser = $resultUser->fetch_assoc()) {
        $_SESSION['uid'] = $rowUser['user_id'];
        header("location:../User/HomePage.php");
    } elseif ($rowShop = $resWorkshop->fetch_assoc()) {
        $_SESSION['wid'] = $rowShop['shop_id'];
        header("location:../WorkShop/Homepage.php");
    } elseif ($rowMechanic = $resMechanic->fetch_assoc()) {
        $_SESSION['mid'] = $rowMechanic['mechanic_id'];
        header("location:../Mechanic/Homepage.php");
    } elseif ($rowAdmin = $resAdmin->fetch_assoc()) {
        $_SESSION['did'] = $rowAdmin['admin_id'];
        header("location:../Admin/Homeadmin.php");
    } else {
        echo "<script>alert('Invalid Email or Password'); window.location='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Login | Vehicle Breakdown Assistance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet" />
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />

    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            height: 100vh;
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .container {
            width: 900px;
            max-width: 95%;
            display: flex;
            border-radius: 15px;
            box-shadow: 0 0 40px rgba(0, 0, 0, 0.4);
            overflow: hidden;
            background: transparent;
        }

        .left-panel {
            background: url('https://laweta24-poznan.pl/wp-content/uploads/2023/11/c3e57ec5-d4ed-4505-ab34-fba86dd3511b.jpeg') no-repeat center center/cover;
            width: 45%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
        }

        /* Remove the left-panel buttons */
        /* .left-panel a {
            ... 
        } */

        .right-panel {
            width: 55%;
            padding: 50px 40px;
            background-color: #f0f0f0;
            border-radius: 12px;
            color: black;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .right-panel h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 26px;
            color: #2c5364;
        }

        form label {
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
            color: black;
        }

        .input-box {
            margin-bottom: 20px;
            position: relative;
        }

        .input-box input {
            width: 100%;
            padding: 12px 40px 12px 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
            outline: none;
            transition: 0.3s;
            color: black;
        }

        .input-box input:focus {
            border-color: #2c5364;
            box-shadow: 0 0 5px rgba(44, 83, 100, 0.5);
        }

        .input-box i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
        }

        .forgot {
            text-align: right;
            margin-top: -10px;
            margin-bottom: 15px;
        }

        .forgot a {
            font-size: 13px;
            color: #2c5364;
            text-decoration: none;
        }

        .forgot a:hover {
            text-decoration: underline;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background: #2c5364;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background: #1f3647;
        }

        .note {
            margin-top: 20px;
            font-size: 13px;
            text-align: center;
            color: black;
        }

        .note a {
            color: #2c5364;
            text-decoration: none;
            font-weight: 600;
        }

        .note a:hover {
            text-decoration: underline;
        }

        /* Container for the bottom sign in buttons */
        .bottom-buttons {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .bottom-buttons a {
            padding: 12px 24px;
            border: 2px solid black;
            border-radius: 30px;
            background-color: rgba(255, 255, 255, 0.85);
            color: black;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            text-align: center;
            transition: all 0.3s ease;
            min-width: 140px;
        }

        .bottom-buttons a:hover {
            background-color: black;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .left-panel,
            .right-panel {
                width: 100%;
                padding: 30px;
            }

            .left-panel {
                text-align: center;
            }

            .bottom-buttons {
                flex-direction: column;
                gap: 10px;
            }

            .bottom-buttons a {
                min-width: auto;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <!-- Left panel keeps only background image -->
        </div>

        <div class="right-panel">
            <div>
                <h2>Login</h2>
                <form method="post" action="">
                    <label for="email">Email</label>
                    <div class="input-box">
                        <input type="text" name="email" id="email" placeholder="Enter your email" required />
                        <i class="bx bxs-envelope"></i>
                    </div>

                    <label for="password">Password</label>
                    <div class="input-box">
                        <input type="password" name="password" id="password" placeholder="Enter your password" required />
                        <i class="bx bxs-lock"></i>
                    </div>

                    <div class="forgot">
                        <a href="ChangePassword.php">Forgot password?</a>
                    </div>

                    <input type="submit" name="btn" value="Login" />

                    <div class="note">
                        Don’t have an account? <a href="UserRegistrstion.php">Register here</a>
                    </div>
                </form>
            </div>

            <div class="bottom-buttons">
                <a href="UserRegistrstion.php">👤 User Sign In</a>
                <a href="WorkShopRegisteration.php">🔧 Shop Sign In</a>
            </div>
        </div>
    </div>
</body>
</html>
