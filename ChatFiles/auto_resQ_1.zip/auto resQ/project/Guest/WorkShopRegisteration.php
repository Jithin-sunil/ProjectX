<?php
include("../asset/connection/connection.php");

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $mail = $_POST['mail'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $place = $_POST['place'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // secure hash

    // File uploads
    $photo = $_FILES['photo']['name'];
    $temp = $_FILES['photo']['tmp_name'];
    $proof = $_FILES['proof']['name'];
    $tempproof = $_FILES['proof']['tmp_name'];

    move_uploaded_file($temp, '../asset/Files/WorkShop/Photo/' . $photo);
    move_uploaded_file($tempproof, '../asset/Files/WorkShop/Photo/' . $proof);

    // Email check
    $check = $Con->query("SELECT * FROM tbl_workshop WHERE shop_email='$mail'");
    if ($check->num_rows > 0) {
        echo "<script>alert('Email already registered!');</script>";
    } else {
        $insQry = "INSERT INTO tbl_workshop (shop_name, shop_email, shop_address, shop_contact, shop_photo, shop_password, place_id, shop_proof)
                   VALUES ('$name','$mail','$address','$contact','$photo','$password','$place','$proof')";
        if ($Con->query($insQry)) {
            echo "<script>
                alert('Workshop Registered Successfully!');
                window.location='../WorkShop/WorkShopRegistration.php';
            </script>";
        } else {
            echo "<script>alert('Error during registration');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AutoresQ | Workshop Registration</title>
    <script src="../asset/JQ/jQuery.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #111, #b51212);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .registration-wrapper {
            width: 950px;
            background: rgba(255, 255, 255, 0.95);
            display: flex;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(6px);
        }

        /* LEFT SIDE */
        .registration-image {
            width: 45%;
            background: linear-gradient(135deg, #b51212, #7a0a0a);
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            flex-direction: column;
            padding: 30px;
            position: relative;
            overflow: hidden;
        }

        .registration-image::after {
            content: "";
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -80px;
            right: -80px;
        }

        .registration-image h1 {
            font-size: 50px;
            letter-spacing: 2px;
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 2px 2px 10px rgba(0,0,0,0.3);
        }

        .registration-image p {
            font-size: 16px;
            color: #f1f1f1;
            text-align: center;
            line-height: 1.5;
        }

        /* RIGHT SIDE */
        .registration-form {
            width: 55%;
            padding: 50px 40px;
        }

        .registration-form h2 {
            text-align: center;
            color: #b51212;
            font-weight: 700;
            font-size: 26px;
            margin-bottom: 30px;
        }

        .form-group { margin-bottom: 18px; }

        label {
            display: block;
            font-weight: 500;
            margin-bottom: 5px;
            color: #444;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 14px;
            border-radius: 10px;
            border: 1.5px solid #bbb;
            font-size: 15px;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        input:focus, select:focus, textarea:focus {
            border-color: #b51212;
            outline: none;
            box-shadow: 0 0 6px rgba(181,18,18,0.3);
        }

        textarea { resize: none; }

        .btn-submit {
            width: 100%;
            padding: 12px;
            background: #b51212;
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 17px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s;
        }

        .btn-submit:hover {
            background: #8d0f0f;
            transform: scale(1.03);
        }

        .form-note {
            text-align: center;
            font-size: 13px;
            color: #777;
            margin-top: 15px;
        }

        @media (max-width: 850px) {
            .registration-wrapper { flex-direction: column; width: 90%; }
            .registration-image { width: 100%; height: 200px; padding: 20px; }
            .registration-image h1 { font-size: 36px; }
            .registration-form { width: 100%; padding: 30px 20px; }
        }
    </style>
</head>

<body>
<div class="registration-wrapper">
    <!-- LEFT SIDE -->
    <div class="registration-image">
        <h1>autoresQ</h1>
        <p>Register your workshop with us<br>and assist road users faster!</p>
    </div>

    <!-- RIGHT SIDE -->
    <div class="registration-form">
        <h2>Workshop Registration</h2>
        <form action="" method="post" enctype="multipart/form-data">
            
            <div class="form-group">
                <label for="name">Workshop Name</label>
                <input required type="text" name="name" id="name"
                       pattern="^[A-Z][a-zA-Z ]*$"
                       title="Only letters, spaces, first letter capitalized" />
            </div>

            <div class="form-group">
                <label for="mail">Email</label>
                <input required type="email" name="mail" id="mail" />
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea required name="address" id="address" rows="3"></textarea>
            </div>

            <div class="form-group">
                <label for="contact">Contact</label>
                <input required type="text" name="contact" id="contact"
                       pattern="[7-9]{1}[0-9]{9}"
                       title="Phone number must start with 7-9 and have 10 digits total" />
            </div>

            <div class="form-group">
                <label for="district">District</label>
                <select name="district" id="district" required onchange="getPlace(this.value)">
                    <option value="">-- Select District --</option>
                    <?php
                    $districtSel = "SELECT * FROM tbl_district";
                    $disResult = $Con->query($districtSel);
                    while ($disRow = $disResult->fetch_assoc()) {
                        echo "<option value='{$disRow['district_id']}'>{$disRow['district_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="place">Place</label>
                <select name="place" id="place" required>
                    <option value="">-- Select Place --</option>
                </select>
            </div>

            <div class="form-group">
                <label for="photo">Workshop Photo</label>
                <input required type="file" name="photo" id="photo" accept="image/*" />
            </div>

            <div class="form-group">
                <label for="proof">Proof Document</label>
                <input required type="file" name="proof" id="proof" accept="image/*,application/pdf" />
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input required type="password" name="password" id="password"
                       pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                       title="At least 1 number, 1 uppercase, 1 lowercase, min 8 characters" />
            </div>

            <button type="submit" class="btn-submit" name="submit">REGISTER NOW</button>
        </form>
    </div>
</div>

<script>
function getPlace(did) {
    $.ajax({
        url: "../asset/AjaxPages/AjaxPlace.php?did=" + did,
        success: function(response) {
            $('#place').html(response);
        }
    });
}
</script>
</body>
</html>
