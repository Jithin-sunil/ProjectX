<?php
include("../asset/connection/connection.php");
session_start();

$statusFilter = "";
if (isset($_POST['status'])) {
    $statusFilter = $_POST['status'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Complaints | AutoResQ Admin</title>
<style>
    body {
        margin: 0;
        font-family: "Poppins", sans-serif;
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364); /* 🔵 Deep blue gradient */
        color: #fff;
        overflow-x: hidden;
    }

    .sidebar {
        width: 220px;
        background: rgba(10, 20, 30, 0.95);
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        padding: 30px 15px;
        border-right: 3px solid #00bfff; /* Neon blue accent */
    }

    .sidebar h2 {
        color: #00bfff;
        text-align: center;
        margin-bottom: 30px;
        letter-spacing: 1px;
    }

    .sidebar a {
        display: block;
        color: #fff;
        text-decoration: none;
        padding: 12px 10px;
        border-radius: 6px;
        margin-bottom: 10px;
        transition: all 0.3s;
    }

    .sidebar a:hover {
        background-color: #00bfff;
        color: #fff;
        transform: translateX(5px);
    }

    .main-content {
        margin-left: 240px;
        padding: 40px;
    }

    .card {
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(12px);
        border-radius: 15px;
        padding: 25px;
        box-shadow: 0 0 25px rgba(0, 191, 255, 0.3);
        max-width: 1100px;
        margin: auto;
    }

    h2 {
        text-align: center;
        color: #00bfff;
        margin-bottom: 25px;
        text-shadow: 0 0 12px rgba(0, 191, 255, 0.4);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 15px;
    }

    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    th {
        background-color: rgba(0, 123, 255, 0.9);
        color: #fff;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    tr:hover {
        background-color: rgba(255, 255, 255, 0.08);
    }

    .btn {
        display: inline-block;
        padding: 8px 16px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 6px;
        text-decoration: none;
        font-size: 14px;
        transition: 0.3s;
    }

    .btn:hover {
        background-color: #33adff;
    }

    .reply-text {
        color: #5effb7;
        font-style: italic;
        font-weight: 500;
    }

    .filter-bar {
        text-align: right;
        margin-bottom: 20px;
    }

    select, input[type="submit"] {
        padding: 8px 12px;
        border: none;
        border-radius: 6px;
        background-color: #007bff;
        color: #fff;
        font-weight: 500;
        cursor: pointer;
    }

    select {
        background-color: rgba(255, 255, 255, 0.15);
        color: #fff;
        border: 1px solid #00bfff;
        margin-right: 10px;
    }

    select option {
        color: #000;
    }
</style>
</head>

<body>

<div class="sidebar">
    <h2>AutoResQ</h2>
    <a href="AdminHome.php">🏠 Dashboard</a>
    <a href="WorkshopVerification.php">🧰 Workshop Verification</a>
    <a href="ViewComplaint.php">📩 Complaints</a>
    <a href="ViewFeedback.php">💬 Feedback</a>
    <a href="Category.php">🗂 Categories</a>
    <a href="Brand.php">🏷 Brands</a>
    <a href="District.php">🌍 Districts</a>
    <a href="Place.php">📍 Places</a>
    <a href="../Guest/login.php">🚪 Logout</a>
</div>

<div class="main-content">
    <div class="card">
        <h2>Manage Complaints</h2>

        <form method="post" class="filter-bar">
            <select name="status">
                <option value="">All Complaints</option>
                <option value="0" <?php if ($statusFilter === "0") echo "selected"; ?>>Pending</option>
                <option value="1" <?php if ($statusFilter === "1") echo "selected"; ?>>Replied</option>
            </select>
            <input type="submit" value="Filter">
        </form>

        <table>
            <tr>
                <th>Sl No</th>
                <th>User Details</th>
                <th>Complaint Title</th>
                <th>Content</th>
                <th>Action</th>
            </tr>

            <?php
            $i = 0;
            $selQry = "SELECT * FROM tbl_complaint c 
                       INNER JOIN tbl_user u ON c.user_id = u.user_id";

            if ($statusFilter !== "") {
                $selQry .= " WHERE c.complaint_status = '$statusFilter'";
            }

            $result = $Con->query($selQry);
            while ($row = $result->fetch_assoc()) {
                $i++;
                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td>
                        <strong><?php echo $row['user_name']; ?></strong><br>
                        <small><?php echo $row['user_email']; ?></small><br>
                        📞 <?php echo $row['user_contact']; ?><br>
                        🏠 <?php echo $row['user_address']; ?>
                    </td>
                    <td><?php echo $row['complaint_title']; ?></td>
                    <td><?php echo $row['complaint_content']; ?></td>
                    <td>
                        <?php
                        if ($row['complaint_status'] == 0) {
                            ?>
                            <a href="Reply.php?cid=<?php echo $row['complaint_id']; ?>" class="btn">Reply</a>
                            <?php
                        } else if ($row['complaint_status'] == 1) {
                            echo "<span class='reply-text'>💬 " . $row['complaint_reply'] . "</span>";
                        }
                        ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>
</div>

</body>
</html>
