<?php
include("../asset/connection/connection.php");

$bname = "";
$eid = 0;

if (isset($_POST['btn'])) {
    $bname = $_POST['bname'];
    $eid = $_POST['txt_eid'];

    if ($eid == 0) {
        $insQry = "INSERT INTO tbl_brand(brand_name) VALUES('".$bname."')";
        if ($Con->query($insQry)) {
            echo "<script>alert('✅ Brand added successfully!'); window.location='Brand.php';</script>";
        }
    } else {
        $upQry = "UPDATE tbl_brand SET brand_name='".$bname."' WHERE brand_id='".$eid."'";
        if ($Con->query($upQry)) {
            echo "<script>alert('✅ Brand updated successfully!'); window.location='Brand.php';</script>";
        }
    }
}

if (isset($_GET['did'])) {
    $delQry = "DELETE FROM tbl_brand WHERE brand_id=".$_GET['did'];
    if ($Con->query($delQry)) {
        echo "<script>alert('🗑️ Brand deleted successfully!'); window.location='Brand.php';</script>";
    }
}

if (isset($_GET['eid'])) {
    $editSel = "SELECT * FROM tbl_brand WHERE brand_id='".$_GET['eid']."'";
    $editResult = $Con->query($editSel);
    $editRow = $editResult->fetch_assoc();
    $bname = $editRow['brand_name'];
    $eid = $editRow['brand_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Brand Management | AutoResQ</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #001233, #003566, #001845);
  margin: 0;
  color: #fff;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: 70px 0;
}

/* Container */
.container {
  width: 90%;
  max-width: 900px;
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(15px);
  border-radius: 20px;
  padding: 40px 50px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
  animation: fadeIn 0.8s ease;
  border: 1px solid rgba(255,255,255,0.1);
}

/* Header */
.header {
  text-align: center;
  margin-bottom: 30px;
}
.header h1 {
  color: #00b4d8;
  font-size: 28px;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.header p {
  color: #90e0ef;
  font-size: 14px;
  margin-top: 8px;
}

/* Form */
.form-table {
  width: 100%;
  border-spacing: 0 10px;
}

label {
  font-weight: 500;
  color: #caf0f8;
}

input[type="text"] {
  width: 100%;
  padding: 12px 16px;
  border: none;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
  outline: none;
  font-size: 15px;
  transition: 0.3s ease;
}

input[type="text"]:focus {
  background: rgba(255, 255, 255, 0.25);
  box-shadow: 0 0 8px #00b4d8;
}

input[type="submit"] {
  background: #00b4d8;
  color: #001219;
  font-weight: 600;
  border: none;
  border-radius: 25px;
  padding: 12px 30px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: block;
  margin: 20px auto 30px;
}

input[type="submit"]:hover {
  background: #90e0ef;
  transform: scale(1.05);
  box-shadow: 0 0 15px #00b4d8;
}

/* Table List */
.data-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  font-size: 15px;
}

.data-table th {
  background: rgba(0, 180, 216, 0.25);
  color: #00b4d8;
  text-transform: uppercase;
  font-weight: 600;
  padding: 12px;
}

.data-table td {
  text-align: center;
  padding: 10px;
  border-bottom: 1px solid rgba(255,255,255,0.1);
}

.data-table tr:nth-child(even) {
  background: rgba(255,255,255,0.05);
}

/* Buttons */
.action-btn {
  text-decoration: none;
  padding: 6px 14px;
  border-radius: 8px;
  color: #fff;
  font-weight: 500;
  margin: 0 5px;
  transition: 0.3s ease;
}

.edit {
  background: #0077b6;
}

.delete {
  background: #ff4d6d;
}

.action-btn:hover {
  transform: scale(1.1);
  opacity: 0.9;
}

/* Floating Back Button */
.floating-btn {
  position: fixed;
  bottom: 25px;
  right: 25px;
  background: #00b4d8;
  color: #001219;
  padding: 14px 28px;
  border-radius: 30px;
  font-weight: 600;
  text-transform: uppercase;
  text-decoration: none;
  transition: 0.3s ease;
  box-shadow: 0 0 15px rgba(0,180,216,0.6);
}

.floating-btn:hover {
  background: #90e0ef;
  transform: scale(1.08);
}

/* Animation */
@keyframes fadeIn {
  from {opacity: 0; transform: translateY(20px);}
  to {opacity: 1; transform: translateY(0);}
}
</style>
</head>

<body>
<div class="container">
  <div class="header">
    <h1>Manage Vehicle Brands</h1>
    <p>Maintain your AutoResQ brand catalog with ease</p>
  </div>

  <form id="form1" name="form1" method="post" action="Brand.php">
    <table class="form-table">
      <tr>
        <td><label for="bname">Brand Name</label></td>
      </tr>
      <tr>
        <td>
          <input required type="text" name="bname" id="bname" value="<?php echo $bname; ?>" placeholder="Enter brand name" />
          <input type="hidden" name="txt_eid" id="txt_eid" value="<?php echo $eid; ?>" />
        </td>
      </tr>
    </table>
    <input type="submit" name="btn" id="btn" value="<?php echo $eid == 0 ? 'Add Brand' : 'Update Brand'; ?>" />
  </form>

  <table class="data-table">
    <tr>
      <th>Sl.No</th>
      <th>Brand Name</th>
      <th>Action</th>
    </tr>
    <?php
    $i = 0;
    $selQry = "SELECT * FROM tbl_brand";
    $result = $Con->query($selQry);
    while ($row = $result->fetch_assoc()) {
        $i++;
    ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $row['brand_name']; ?></td>
      <td>
        <a href="Brand.php?eid=<?php echo $row['brand_id']; ?>" class="action-btn edit">Edit</a>
        <a href="Brand.php?did=<?php echo $row['brand_id']; ?>" class="action-btn delete">Delete</a>
      </td>
    </tr>
    <?php } ?>
  </table>
</div>

<!-- Floating Button -->
<a href="AdminHomePage.php" class="floating-btn">⬅ Back to Dashboard</a>
</body>
</html>
