<?php
include("../asset/connection/connection.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Feedback | AutoResQ Admin</title>
<style>
    body {
        margin: 0;
        font-family: "Poppins", sans-serif;
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364); /* 🔵 blue gradient */
        color: #fff;
        overflow-x: hidden;
    }

    .sidebar {
        width: 220px;
        background: rgba(10, 20, 30, 0.95);
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        padding: 30px 15px;
        border-right: 3px solid #00bfff;
    }

    .sidebar h2 {
        color: #00bfff;
        text-align: center;
        margin-bottom: 30px;
        letter-spacing: 1px;
    }

    .sidebar a {
        display: block;
        color: #fff;
        text-decoration: none;
        padding: 12px 10px;
        border-radius: 6px;
        margin-bottom: 10px;
        transition: all 0.3s;
    }

    .sidebar a:hover {
        background-color: #00bfff;
        color: #fff;
        transform: translateX(5px);
    }

    .main-content {
        margin-left: 240px;
        padding: 40px;
    }

    .card {
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(12px);
        border-radius: 15px;
        padding: 25px;
        box-shadow: 0 0 25px rgba(0, 191, 255, 0.3);
        max-width: 1000px;
        margin: auto;
    }

    h2 {
        text-align: center;
        color: #00bfff;
        margin-bottom: 25px;
        text-shadow: 0 0 12px rgba(0, 191, 255, 0.4);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 15px;
    }

    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    th {
        background-color: rgba(0, 123, 255, 0.9);
        color: #fff;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    tr:hover {
        background-color: rgba(255, 255, 255, 0.08);
    }

    .user-info {
        line-height: 1.5;
    }

    .user-info strong {
        color: #00bfff;
        font-size: 16px;
    }

    .user-info small {
        display: block;
        color: #ccc;
    }

    .feedback {
        color: #e0f7ff;
        font-style: italic;
        font-size: 15px;
    }
</style>
</head>

<body>

<div class="sidebar">
    <h2>AutoResQ</h2>
    <a href="AdminHome.php">🏠 Dashboard</a>
    <a href="WorkshopVerification.php">🧰 Workshop Verification</a>
    <a href="ViewComplaint.php">📩 Complaints</a>
    <a href="ViewFeedback.php">💬 Feedback</a>
    <a href="Category.php">🗂 Categories</a>
    <a href="Brand.php">🏷 Brands</a>
    <a href="District.php">🌍 Districts</a>
    <a href="Place.php">📍 Places</a>
    <a href="../Guest/login.php">🚪 Logout</a>
</div>

<div class="main-content">
    <div class="card">
        <h2>Manage Feedback</h2>

        <table>
            <tr>
                <th>Sl No</th>
                <th>User Details</th>
                <th>Feedback Content</th>
            </tr>

            <?php
            $i=0;
            $selQry = "SELECT * FROM tbl_feedback c 
                       INNER JOIN tbl_user u ON c.user_id=u.user_id";
            $result = $Con->query($selQry);
            while ($row= $result->fetch_assoc()) {
                $i++;
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td class="user-info">
                    <strong><?php echo $row['user_name']; ?></strong><br>
                    <small>📧 <?php echo $row['user_email']; ?></small><br>
                    <small>📞 <?php echo $row['user_contact']; ?></small><br>
                    <small>🏠 <?php echo $row['user_address']; ?></small>
                </td>
                <td class="feedback"><?php echo $row['feedback_content']; ?></td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>

</body>
</html>
