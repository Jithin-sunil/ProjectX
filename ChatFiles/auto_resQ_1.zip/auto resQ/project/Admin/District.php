<?php
include("../asset/connection/connection.php");
$district = "";
$eid = 0;

if (isset($_POST['btn'])) {
    $district = $_POST['district'];
    $eid = $_POST['txt_eid'];
    if ($eid == 0) {
        $insQry = "INSERT INTO tbl_district (district_name) VALUES ('" . $district . "')";
        if ($Con->query($insQry)) {
            echo "<script>alert('District added successfully!');</script>";
        }
    } else {
        $upQry = "UPDATE tbl_district SET district_name='" . $district . "' WHERE district_id='" . $eid . "'";
        if ($Con->query($upQry)) {
            echo "<script>alert('District updated successfully!');window.location='district.php';</script>";
        }
    }
}

if (isset($_GET['did'])) {
    $delQry = "DELETE FROM tbl_district WHERE district_id=" . $_GET['did'];
    if ($Con->query($delQry)) {
        echo "<script>alert('District deleted successfully!');window.location='district.php';</script>";
    }
}

if (isset($_GET['eid'])) {
    $editSel = "SELECT * FROM tbl_district WHERE district_id='" . $_GET['eid'] . "'";
    $editResult = $Con->query($editSel);
    $editRow = $editResult->fetch_assoc();
    $district = $editRow['district_name'];
    $eid = $editRow['district_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>District Management | AutoResQ</title>
<style>
body {
    font-family: "Poppins", sans-serif;
    background: radial-gradient(circle at top left, #001219, #0a192f, #001219);
    color: #fff;
    margin: 0;
    padding: 0;
    min-height: 100vh;
}
header {
    background: linear-gradient(90deg, #00b4d8, #0077b6, #023e8a);
    padding: 25px;
    text-align: center;
    font-size: 28px;
    font-weight: bold;
    letter-spacing: 1px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.4);
    color: #fff;
}
.container {
    width: 90%;
    margin: 30px auto;
    background: rgba(255,255,255,0.08);
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 0 25px rgba(0,180,216,0.3);
    backdrop-filter: blur(8px);
}
form {
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;
}
.input-group {
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
}
input[type="text"] {
    padding: 12px 18px;
    border: none;
    border-radius: 10px;
    background: rgba(255,255,255,0.15);
    color: #fff;
    width: 280px;
    outline: none;
}
input[type="submit"] {
    background: linear-gradient(90deg, #00b4d8, #0077b6);
    color: #fff;
    border: none;
    border-radius: 30px;
    padding: 10px 25px;
    font-weight: 600;
    letter-spacing: 1px;
    cursor: pointer;
    transition: 0.3s;
}
input[type="submit"]:hover {
    background: linear-gradient(90deg, #90e0ef, #00b4d8);
    color: #001219;
    transform: scale(1.05);
}

/* Table styling */
table {
    width: 90%;
    margin: 30px auto;
    border-collapse: collapse;
    box-shadow: 0 0 25px rgba(0,180,216,0.3);
    border-radius: 10px;
    overflow: hidden;
}
th, td {
    padding: 12px 16px;
    text-align: center;
}
th {
    background: linear-gradient(90deg, #00b4d8, #0077b6);
    color: #fff;
    font-size: 15px;
}
td {
    background: rgba(255,255,255,0.05);
    color: #fff;
}
tr:nth-child(even) td {
    background: rgba(255,255,255,0.08);
}
a.action {
    background: linear-gradient(90deg, #ff6b6b, #c9184a);
    color: #fff;
    text-decoration: none;
    padding: 6px 14px;
    border-radius: 20px;
    margin: 2px;
    display: inline-block;
    transition: 0.3s;
    box-shadow: 0 0 10px rgba(255,107,107,0.4);
}
a.action:hover {
    background: linear-gradient(90deg, #90e0ef, #00b4d8);
    color: #001219;
    transform: scale(1.1);
}
footer {
    text-align: center;
    padding: 18px;
    color: #adb5bd;
    font-size: 14px;
    border-top: 1px solid #00b4d8;
    background: #001219;
    margin-top: 40px;
}
</style>
</head>

<body>
<header>📍 AutoResQ – Manage Districts</header>

<div class="container">
<form id="form1" name="form1" method="post" action="district.php">
  <div class="input-group">
      <input required type="text" name="district" id="district" placeholder="Enter District Name" value="<?php echo $district; ?>" />
      <input type="hidden" name="txt_eid" id="txt_eid" value="<?php echo $eid; ?>" />
      <input type="submit" name="btn" id="submit" value="<?php echo $eid == 0 ? 'Add District' : 'Update District'; ?>" />
  </div>
</form>

<h2 style="text-align:center;color:#90e0ef;margin-top:30px;">District List</h2>
<table border="1">
    <tr>
        <th>SL No</th>
        <th>District Name</th>
        <th>Action</th>
    </tr>
    <?php
    $i = 0;
    $selQry = "SELECT * FROM tbl_district ORDER BY district_name ASC";
    $result = $Con->query($selQry);
    while ($row = $result->fetch_assoc()) {
        $i++;
    ?>
    <tr>
        <td><?php echo $i; ?></td>
        <td><?php echo $row['district_name']; ?></td>
        <td>
            <a class="action" href="district.php?did=<?php echo $row['district_id']; ?>">Delete</a>
            <a class="action" style="background:linear-gradient(90deg,#00b4d8,#0077b6);" href="district.php?eid=<?php echo $row['district_id']; ?>">Edit</a>
        </td>
    </tr>
    <?php } ?>
</table>
</div>

<footer>© <?php echo date('Y'); ?> AutoResQ | District Management Panel</footer>
</body>
</html>
