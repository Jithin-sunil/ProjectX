<?php
include("../asset/connection/connection.php");

if(isset($_POST['btn'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  $insQry = "INSERT INTO tbl_admin(admin_name, admin_email, admin_password) 
             VALUES('".$name."', '".$email."', '".$password."')";
  if($Con->query($insQry)) {
    ?>
    <script>
      alert("✅ Admin Registered Successfully!");
      window.location = "AdminRegistration.php";
    </script>
    <?php
  }
}

if(isset($_GET['did'])) {
  $delQry = "DELETE FROM tbl_admin WHERE admin_id='".$_GET['did']."'";
  if($Con->query($delQry)) {
    ?>
    <script>
      alert("🗑️ Admin Deleted Successfully!");
      window.location = "AdminRegistration.php";
    </script>
    <?php
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Registration | AutoResQ</title>

<style>
/* ===== AutoResQ THEME ===== */
body {
  font-family: "Poppins", sans-serif;
  background: linear-gradient(135deg, #001233, #003566, #001845);
  margin: 0;
  padding: 0;
  color: #f1f1f1;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: 70px 0;
}

/* ===== Main Container ===== */
.container {
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(15px);
  border-radius: 20px;
  padding: 40px 50px;
  width: 85%;
  max-width: 950px;
  box-shadow: 0 10px 35px rgba(0, 0, 0, 0.5);
  border: 1px solid rgba(255,255,255,0.1);
  animation: fadeIn 0.8s ease;
  position: relative;
}

/* ===== Header ===== */
.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
}

.logo img {
  width: 60px;
  height: 60px;
  margin-right: 12px;
}

.logo span {
  font-size: 28px;
  font-weight: 700;
  color: #00b4d8;
  text-shadow: 0 0 10px rgba(0,180,216,0.6);
}

h1 {
  text-align: center;
  color: #90e0ef;
  font-size: 26px;
  letter-spacing: 1px;
  margin-bottom: 25px;
  text-transform: uppercase;
}

/* ===== Form Table ===== */
.form-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 15px;
}

.form-table td:first-child {
  width: 25%;
  font-weight: 600;
  color: #caf0f8;
}

.form-table input {
  width: 95%;
  padding: 12px 16px;
  border: none;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
  outline: none;
  transition: all 0.3s ease;
  font-size: 15px;
}

.form-table input:focus {
  background: rgba(255, 255, 255, 0.25);
  box-shadow: 0 0 10px #00b4d8;
}

/* ===== Button ===== */
input[type="submit"] {
  background: #00b4d8;
  color: #001219;
  font-weight: bold;
  border: none;
  border-radius: 30px;
  padding: 12px 40px;
  cursor: pointer;
  transition: 0.3s ease;
  display: block;
  margin: 25px auto;
  font-size: 15px;
  text-transform: uppercase;
  letter-spacing: 1px;
}

input[type="submit"]:hover {
  background: #90e0ef;
  transform: scale(1.05);
  box-shadow: 0 0 20px #00b4d8;
}

/* ===== Table List ===== */
.list-table {
  width: 100%;
  margin-top: 35px;
  border-collapse: collapse;
  font-size: 15px;
}

.list-table th, .list-table td {
  padding: 12px;
  text-align: center;
}

.list-table th {
  background: rgba(0, 180, 216, 0.25);
  color: #00b4d8;
  text-transform: uppercase;
  font-weight: 600;
}

.list-table tr:nth-child(even) {
  background: rgba(255, 255, 255, 0.05);
}

a.delete-btn {
  color: #ff4d6d;
  text-decoration: none;
  font-weight: 600;
  transition: 0.3s ease;
}

a.delete-btn:hover {
  color: #ff8fa3;
  text-shadow: 0 0 8px #ff4d6d;
}

/* ===== Floating Back Button ===== */
.floating-btn {
  position: fixed;
  bottom: 25px;
  right: 25px;
  background: #00b4d8;
  color: #001219;
  padding: 14px 30px;
  border-radius: 30px;
  font-weight: bold;
  text-transform: uppercase;
  text-decoration: none;
  transition: 0.3s ease;
  border: none;
  cursor: pointer;
  box-shadow: 0 0 15px rgba(0, 180, 216, 0.6);
}

.floating-btn:hover {
  background: #90e0ef;
  transform: scale(1.08);
  box-shadow: 0 0 20px #00b4d8;
}

/* ===== Animations ===== */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
</head>

<body>
<div class="container">

  <div class="logo">
    <img src="../asset/images/autoresq_logo.png" alt="AutoResQ Logo">
    <span>autoresQ</span>
  </div>

  <h1>Admin Registration</h1>

  <form id="form1" name="form1" method="post" action="AdminRegistration.php">
    <table class="form-table">
      <tr>
        <td>Name</td>
        <td>
          <input required type="text" name="name" id="name"
          title="Name allows only alphabets and spaces; first letter must be capital"
          pattern="^[A-Z]+[a-zA-Z ]*$" placeholder="Enter full name">
        </td>
      </tr>
      <tr>
        <td>Email</td>
        <td>
          <input required type="email" name="email" id="email" placeholder="Enter valid email">
        </td>
      </tr>
      <tr>
        <td>Password</td>
        <td>
          <input required type="password" name="password" id="password"
          pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
          title="Must contain at least one number, one uppercase, one lowercase letter, and at least 8 characters"
          placeholder="Enter secure password">
        </td>
      </tr>
    </table>
    <input type="submit" name="btn" id="btn" value="Register Admin">
  </form>

  <table class="list-table">
    <tr>
      <th>Sl.No</th>
      <th>Name</th>
      <th>Email</th>
      <th>Action</th>
    </tr>
    <?php
    $i=0;
    $selQry = "select * from tbl_admin";
    $result = $Con->query($selQry);
    while ($row= $result->fetch_assoc()) {
      $i++;
    ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $row['admin_name']; ?></td>
      <td><?php echo $row['admin_email']; ?></td>
      <td><a href="AdminRegistration.php?did=<?php echo $row['admin_id']?>" class="delete-btn">Delete</a></td>
    </tr>
    <?php } ?>
  </table>
</div>

<!-- Floating Back Button -->
<a href="AdminHomePage.php" class="floating-btn">⬅ Back to Dashboard</a>

</body>
</html>
