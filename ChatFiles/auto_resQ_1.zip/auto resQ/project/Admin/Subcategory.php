<?php
include("../asset/connection/connection.php");
if(isset($_POST['btn']))
{
	$category=$_POST['cat'];
	$subcategory=$_POST['cate'];
	$insQry="insert into tbl_subcategory(category_id,subcategory_name) values('".$category."','".$subcategory."')";
	if($Con->query($insQry))
	{
		?>
		  <script>
	alert("values inserted");
	</script>
    <?php
    }
  }
    if(isset($_GET['did']))
  {	  $delQry="delete from tbl_subcategory where subcategory_id=".$_GET['did'];
 if($Con->query($delQry))
 {?>
  <script>
	alert("values deleted");
	window.location="Subcategory.php";
	</script>
    <?php
  }}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="Subcategory.php">
  <table width="200" border="1">
    <tr>
      <td>Category</td>
      <td><select name="cat" id="cat">
        <option>sel category</option>
        <?php
		$categorySel="select * from tbl_category";
		$disResult=$Con->query($categorySel);
		while($disRow=$disResult->fetch_assoc())
		{
			?>
            <option value="<?php echo $disRow['category_id']?>"><?php
			echo $disRow['category_name']?></option>
            <?php
		}
		?>
      
      </select></td>
    </tr>
    <tr>
      <td>Subcategory</td>
      <td><label for="cate"></label>
      <input  required type="text" name="cate" id="cate" /></td>
    </tr>
    <tr>
      <td colspan="2"><div align="center">
        <input type="submit" name="btn" id="btn" value="Submit" />
      </div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <table width="200" border="1">
    <tr>
      <td>SLno</td>
      <td>Subcategory</td>
      <td>Ccategory</td>
      <td>Action</td>
    </tr>
    <?php
	$i=0;
	$selQry="select * from tbl_subcategory p inner join tbl_category s on s.category_id=p.category_id";
	$result=$Con->query($selQry);
	while($row=$result->fetch_assoc())
	{
		$i++;
	?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $row['category_name']; ?></td>
      <td><?php echo $row['subcategory_name']; ?></td>
      <td><a href="Subcategory.php?did=<?php echo $row['subcategory_id']?>">Delete</a></td>
    </tr>
	<?php
	}
	?>
    
  </table>
  <p>&nbsp;</p>
</form>
</body>
</html>