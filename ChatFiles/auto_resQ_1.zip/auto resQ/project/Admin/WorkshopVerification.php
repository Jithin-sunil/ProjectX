<?php
include("../asset/connection/connection.php");

// Handle Accept/Reject actions
if (isset($_GET['aid'])) {
    $up = "UPDATE tbl_workshop SET workshop_status = 1 WHERE shop_id = '" . $_GET['aid'] . "'";
    if ($Con->query($up)) {
        echo "<script>alert('Workshop Accepted');window.location='WorkshopVerification.php';</script>";
    }
}
if (isset($_GET['rid'])) {
    $dl = "UPDATE tbl_workshop SET workshop_status = 2 WHERE shop_id = '" . $_GET['rid'] . "'";
    if ($Con->query($dl)) {
        echo "<script>alert('Workshop Rejected');window.location='WorkshopVerification.php';</script>";
    }
}

// Search & filter logic
$filter_status = isset($_POST['status']) ? $_POST['status'] : 'all';
$search_query = isset($_POST['search']) ? trim($_POST['search']) : '';
$district_filter = isset($_POST['district']) ? $_POST['district'] : '';

// Fetch district list for dropdown
$districts = $Con->query("SELECT * FROM tbl_district ORDER BY district_name ASC");

$where = [];
if ($filter_status != 'all') $where[] = "workshop_status = '$filter_status'";
if ($district_filter != '') $where[] = "d.district_id = '$district_filter'";
if ($search_query != '') $where[] = "(shop_name LIKE '%$search_query%' OR shop_email LIKE '%$search_query%')";
$where_sql = $where ? "WHERE " . implode(" AND ", $where) : "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Workshop Verification | AutoResQ</title>
<style>
/* ---------- GLOBAL STYLE ---------- */
body {
    font-family: "Poppins", sans-serif;
    background: radial-gradient(circle at top left, #001219, #0a192f, #001219);
    color: #fff;
    margin: 0;
    padding: 0;
    min-height: 100vh;
}
header {
    text-align: center;
    background: linear-gradient(90deg, #00b4d8, #0077b6, #023e8a);
    padding: 25px;
    font-size: 30px;
    font-weight: 700;
    letter-spacing: 1px;
    color: #fff;
    box-shadow: 0 4px 15px rgba(0,0,0,0.4);
    border-bottom: 2px solid #00b4d8;
}
.filter-bar {
    width: 90%;
    margin: 25px auto;
    background: rgba(255, 255, 255, 0.1);
    padding: 20px;
    border-radius: 15px;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
    box-shadow: 0 0 15px rgba(0,180,216,0.3);
    backdrop-filter: blur(5px);
}
.filter-bar input, 
.filter-bar select, 
.filter-bar button {
    padding: 12px 16px;
    border: none;
    border-radius: 10px;
    font-size: 15px;
    outline: none;
}
.filter-bar input, .filter-bar select {
    flex: 1;
    min-width: 200px;
    background: rgba(255,255,255,0.2);
    color: #fff;
}
.filter-bar input::placeholder {
    color: #e0fbfc;
}
.filter-bar select option {
    background: #001219;
    color: #fff;
}
.filter-bar button {
    background: linear-gradient(90deg, #00b4d8, #0077b6);
    color: #fff;
    cursor: pointer;
    font-weight: bold;
    letter-spacing: 1px;
    transition: 0.3s;
}
.filter-bar button:hover {
    background: linear-gradient(90deg, #90e0ef, #00b4d8);
    color: #001219;
    transform: scale(1.05);
}

/* ---------- TABLE STYLE ---------- */
h2 {
    color: #caf0f8;
    text-align: center;
    margin-top: 40px;
    font-size: 26px;
    text-transform: uppercase;
}
table {
    width: 90%;
    margin: 30px auto;
    border-collapse: collapse;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 0 20px rgba(0,180,216,0.25);
}
th, td {
    padding: 14px 18px;
    text-align: center;
}
th {
    background: linear-gradient(90deg, #00b4d8, #0077b6);
    color: #fff;
    font-size: 15px;
    letter-spacing: 1px;
}
td {
    background: rgba(255,255,255,0.05);
    color: #fff;
}
tr:nth-child(even) td {
    background: rgba(255,255,255,0.08);
}
td img {
    border-radius: 12px;
    max-width: 100px;
    max-height: 100px;
    object-fit: cover;
    border: 2px solid #00b4d8;
    box-shadow: 0 0 10px rgba(0,180,216,0.4);
}
a.action {
    background: linear-gradient(90deg, #00b4d8, #0077b6);
    color: #fff;
    text-decoration: none;
    padding: 8px 18px;
    border-radius: 30px;
    font-size: 14px;
    transition: 0.3s;
    display: inline-block;
    margin: 6px 0;
    box-shadow: 0 0 8px rgba(0,180,216,0.5);
}
a.action:hover {
    background: linear-gradient(90deg, #90e0ef, #00b4d8);
    color: #001219;
    transform: scale(1.08);
}
.status {
    font-weight: 600;
    letter-spacing: 0.5px;
}
.status.pending {
    color: #ffd60a;
}
.status.accepted {
    color: #80ed99;
}
.status.rejected {
    color: #ff6b6b;
}

/* ---------- FOOTER ---------- */
footer {
    background: #001219;
    color: #adb5bd;
    text-align: center;
    padding: 18px;
    font-size: 15px;
    margin-top: 50px;
    border-top: 1px solid #00b4d8;
}
</style>
</head>
<body>

<header>⚙️ AutoResQ Admin – Workshop Verification Dashboard</header>

<form method="post">
<div class="filter-bar">
    <input type="text" name="search" placeholder="🔍 Search by Name or Email" value="<?php echo $search_query; ?>">
    <select name="district">
        <option value="">All Districts</option>
        <?php while ($d = $districts->fetch_assoc()) { ?>
            <option value="<?php echo $d['district_id']; ?>" <?php if ($district_filter == $d['district_id']) echo "selected"; ?>>
                <?php echo $d['district_name']; ?>
            </option>
        <?php } ?>
    </select>
    <select name="status">
        <option value="all" <?php if ($filter_status == 'all') echo "selected"; ?>>All Status</option>
        <option value="0" <?php if ($filter_status == '0') echo "selected"; ?>>Pending</option>
        <option value="1" <?php if ($filter_status == '1') echo "selected"; ?>>Accepted</option>
        <option value="2" <?php if ($filter_status == '2') echo "selected"; ?>>Rejected</option>
    </select>
    <button type="submit">Apply Filter</button>
</div>
</form>

<h2>Workshop List</h2>

<table border="1">
<tr>
    <th>Slno</th>
    <th>Name</th>
    <th>Email</th>
    <th>Address</th>
    <th>Contact</th>
    <th>District</th>
    <th>Place</th>
    <th>Photo</th>
    <th>Proof</th>
    <th>Status</th>
    <th>Action</th>
</tr>
<?php
$i = 0;
$selQry = "SELECT * FROM tbl_workshop u
            INNER JOIN tbl_place p ON u.place_id = p.place_id
            INNER JOIN tbl_district d ON d.district_id = p.district_id
            $where_sql ORDER BY shop_id DESC";
$result = $Con->query($selQry);
while ($row = $result->fetch_assoc()) {
    $i++;
    $status_label = $row['workshop_status'] == 0 ? "<span class='status pending'>🕒 Pending</span>" : 
                     ($row['workshop_status'] == 1 ? "<span class='status accepted'>✅ Accepted</span>" : 
                     "<span class='status rejected'>❌ Rejected</span>");
?>
<tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $row['shop_name']; ?></td>
    <td><?php echo $row['shop_email']; ?></td>
    <td><?php echo $row['shop_address']; ?></td>
    <td><?php echo $row['shop_contact']; ?></td>
    <td><?php echo $row['district_name']; ?></td>
    <td><?php echo $row['place_name']; ?></td>
    <td><img src="../asset/Files/WorkShop/Photo/<?php echo $row['shop_photo']; ?>" alt="Photo"></td>
    <td><img src="../asset/Files/WorkShop/Photo/<?php echo $row['shop_proof']; ?>" alt="Proof"></td>
    <td><?php echo $status_label; ?></td>
    <td>
        <?php if ($row['workshop_status'] == 0 || $row['workshop_status'] == 2) { ?>
            <a class="action" href="?aid=<?php echo $row['shop_id']; ?>">Accept</a><br>
        <?php } ?>
        <?php if ($row['workshop_status'] == 0 || $row['workshop_status'] == 1) { ?>
            <a class="action" href="?rid=<?php echo $row['shop_id']; ?>">Reject</a>
        <?php } ?>
    </td>
</tr>
<?php } ?>
</table>

<footer>© <?php echo date('Y'); ?> AutoResQ | Workshop Verification Dashboard</footer>
</body>
</html>
