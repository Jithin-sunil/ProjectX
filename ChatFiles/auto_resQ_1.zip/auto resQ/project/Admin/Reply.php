<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * FROM tbl_complaint WHERE complaint_id='" . $_GET['cid'] . "'";
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();

if (isset($_POST['btn'])) {
    $reply = $_POST['reply'];
    $UpQry = "UPDATE tbl_complaint SET complaint_reply='" . $reply . "', complaint_status=1 WHERE complaint_id='" . $_GET['cid'] . "'";
    if ($Con->query($UpQry)) {
        ?>
        <script>
            alert("Reply sent successfully!");
            window.location = "ViewComplaint.php";
        </script>
        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Complaint Reply | AutoResQ Admin</title>
    <style>
        body {
            margin: 0;
            font-family: "Poppins", sans-serif;
            background: linear-gradient(135deg, #141E30, #243B55);
            color: #fff;
        }

        .sidebar {
            width: 220px;
            background: rgba(0, 0, 0, 0.85);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 30px 15px;
            border-right: 2px solid #ff6b00;
        }

        .sidebar h2 {
            color: #ff6b00;
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 12px 10px;
            border-radius: 6px;
            margin-bottom: 10px;
            transition: all 0.3s;
        }

        .sidebar a:hover {
            background-color: #ff6b00;
            color: #fff;
        }

        .main-content {
            margin-left: 240px;
            padding: 40px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 0 15px rgba(255, 107, 0, 0.3);
            max-width: 600px;
            margin: 50px auto;
        }

        .card h3 {
            color: #ff6b00;
            margin-bottom: 20px;
            text-align: center;
        }

        table {
            width: 100%;
            border-spacing: 10px;
        }

        td {
            padding: 10px;
            vertical-align: top;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: none;
            outline: none;
            background: rgba(255, 255, 255, 0.15);
            color: #fff;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #ff6b00;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #ff8533;
        }

        .label {
            font-weight: bold;
            color: #ddd;
        }

        .value {
            color: #fff;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>AutoResQ</h2>
    <a href="AdminHome.php">🏠 Dashboard</a>
    <a href="WorkshopVerification.php">🧰 Workshop Verification</a>
    <a href="ViewComplaint.php">📩 Complaints</a>
    <a href="ViewFeedback.php">💬 Feedback</a>
    <a href="Category.php">🗂 Categories</a>
    <a href="Brand.php">🏷 Brands</a>
    <a href="District.php">🌍 Districts</a>
    <a href="Place.php">📍 Places</a>
    <a href="../Guest/login.php">🚪 Logout</a>
</div>

<div class="main-content">
    <div class="card">
        <h3>Reply to Complaint</h3>
        <form method="post" action="">
            <table>
                <tr>
                    <td class="label">Title:</td>
                    <td class="value"><?php echo $row['complaint_title']; ?></td>
                </tr>
                <tr>
                    <td class="label">Content:</td>
                    <td class="value"><?php echo $row['complaint_content']; ?></td>
                </tr>
                <tr>
                    <td class="label">Reply:</td>
                    <td><input required type="text" name="reply" id="reply" placeholder="Enter your reply here..."></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="btn" value="Send Reply">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>

</body>
</html>
