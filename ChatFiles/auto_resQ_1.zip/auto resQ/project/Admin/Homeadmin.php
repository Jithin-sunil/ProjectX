<?php
include("../asset/connection/connection.php");
session_start();

$SelQry = "SELECT * FROM tbl_admin WHERE admin_id=" . $_SESSION['did'];
$result = $Con->query($SelQry);
$row = $result->fetch_assoc();

/* ========== DASHBOARD COUNTS ========== */
$total_users = $Con->query("SELECT COUNT(*) AS cnt FROM tbl_user")->fetch_assoc()['cnt'];
$total_workshops = $Con->query("SELECT COUNT(*) AS cnt FROM tbl_workshop")->fetch_assoc()['cnt'];
$total_complaints = $Con->query("SELECT COUNT(*) AS cnt FROM tbl_complaint")->fetch_assoc()['cnt'];
$total_feedbacks = $Con->query("SELECT COUNT(*) AS cnt FROM tbl_feedback")->fetch_assoc()['cnt'];

/* ========== REQUEST DATA (Filter Support) ========== */
$selected_month = isset($_GET['month']) ? $_GET['month'] : date('m');
$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');

$total_request_row = $Con->query("
  SELECT SUM(request_amount) AS total 
  FROM tbl_request 
  WHERE MONTH(request_date) = '$selected_month' AND YEAR(request_date) = '$selected_year'
")->fetch_assoc();
$total_request = $total_request_row['total'] ? $total_request_row['total'] : 0;

/* Monthly chart for selected year */
$chart_data = [];
$chart_query = "
  SELECT MONTHNAME(request_date) AS month, SUM(request_amount) AS total
  FROM tbl_request
  WHERE YEAR(request_date) = '$selected_year'
  GROUP BY MONTH(request_date)
  ORDER BY MONTH(request_date)";
$chart_result = $Con->query($chart_query);
while ($r = $chart_result->fetch_assoc()) {
  $chart_data[] = [
    'month' => $r['month'],
    'total' => $r['total']
  ];
}

/* Year options for dropdown */
$year_result = $Con->query("SELECT DISTINCT YEAR(request_date) AS yr FROM tbl_request ORDER BY yr DESC");
$years = [];
while ($yr = $year_result->fetch_assoc()) {
  $years[] = $yr['yr'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ Admin Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  body {
    margin: 0;
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #001F3F, #003B73, #0077B6);
    color: #fff;
    display: flex;
    height: 100vh;
    overflow: hidden;
  }

  .sidebar {
    width: 260px;
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(10px);
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    border-right: 1px solid rgba(255, 255, 255, 0.2);
  }

  .sidebar h1 {
    font-size: 24px;
    color: #90E0EF;
    text-align: center;
    margin-bottom: 30px;
    letter-spacing: 1px;
  }

  .nav-links a {
    display: block;
    padding: 12px 15px;
    margin: 8px 0;
    border-radius: 8px;
    color: white;
    text-decoration: none;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.05);
  }

  .nav-links a:hover {
    background: #00B4D8;
    transform: translateX(5px);
  }

  .logout {
    text-align: center;
    padding: 10px;
  }

  .logout a {
    color: #FF4D6D;
    text-decoration: none;
    font-weight: bold;
  }

  .main-content {
    flex-grow: 1;
    padding: 40px;
    overflow-y: auto;
  }

  .welcome-box {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(15px);
    padding: 25px;
    border-radius: 16px;
    text-align: center;
    margin-bottom: 30px;
  }

  .cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 25px;
    margin-bottom: 40px;
  }

  .card {
    background: rgba(255, 255, 255, 0.1);
    padding: 25px;
    border-radius: 15px;
    text-align: center;
    transition: 0.3s;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
  }

  .card:hover {
    background: rgba(0, 180, 216, 0.2);
    transform: translateY(-5px);
  }

  .filter-bar {
    text-align: right;
    margin-bottom: 20px;
  }

  select {
    padding: 10px;
    border-radius: 8px;
    border: none;
    outline: none;
    margin: 0 5px;
    background: rgba(255, 255, 255, 0.15);
    color: #fff;
  }

  select option {
    color: #000;
  }

  button {
    background: #00B4D8;
    color: #fff;
    border: none;
    padding: 10px 16px;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s;
  }

  button:hover {
    background: #0096C7;
  }

  canvas {
    background: rgba(255, 255, 255, 0.05);
    padding: 15px;
    border-radius: 16px;
    box-shadow: 0 3px 15px rgba(0, 0, 0, 0.3);
  }
</style>
</head>

<body>
<div class="sidebar">
  <div>
    <h1>AutoResQ</h1>
    <div class="nav-links">
      <a href="AdminRegistration.php">👤 Admin Registration</a>
      <a href="WorkshopVerification.php">🧰 Workshop Verification</a>
      <a href="ViewComplaint.php">📩 Manage Complaints</a>
      <a href="ViewFeedback.php">💬 Manage Feedback</a>
      <a href="Category.php">📁 Manage Categories</a>
      <a href="Brand.php">🏷️ Manage Brands</a>
      <a href="District.php">🌍 Manage Districts</a>
      <a href="Place.php">📍 Manage Places</a>
    </div>
  </div>
  <div class="logout">
    <a href="../Guest/logout.php">🚪 Logout</a>
  </div>
</div>

<div class="main-content">
  <div class="welcome-box">
    <h2>Welcome, Admin <?php echo $row['admin_name']; ?> 👋</h2>
    <p>Here’s your performance overview</p>
  </div>

  <div class="cards">
    <div class="card"><h3>Total Users</h3><p class="count" id="users"><?php echo $total_users; ?></p></div>
    <div class="card"><h3>Total Workshops</h3><p class="count" id="workshops"><?php echo $total_workshops; ?></p></div>
    <div class="card"><h3>Total Complaints</h3><p class="count" id="complaints"><?php echo $total_complaints; ?></p></div>
    <div class="card"><h3>Total Feedbacks</h3><p class="count" id="feedbacks"><?php echo $total_feedbacks; ?></p></div>
    <div class="card"><h3>Total Request Amount (<?php echo date('M Y', strtotime($selected_year . '-' . $selected_month)); ?>)</h3><p class="count" id="amount">₹<?php echo number_format($total_request, 2); ?></p></div>
  </div>

  <div class="filter-bar">
    <form method="get">
      <select name="month">
        <?php
        for ($m = 1; $m <= 12; $m++) {
          $val = str_pad($m, 2, "0", STR_PAD_LEFT);
          $name = date("F", mktime(0, 0, 0, $m, 1));
          echo "<option value='$val' " . ($val == $selected_month ? "selected" : "") . ">$name</option>";
        }
        ?>
      </select>
      <select name="year">
        <?php foreach ($years as $yr) { ?>
          <option value="<?php echo $yr; ?>" <?php echo ($yr == $selected_year ? "selected" : ""); ?>><?php echo $yr; ?></option>
        <?php } ?>
      </select>
      <button type="submit">Filter</button>
    </form>
  </div>

  <canvas id="requestChart" height="120"></canvas>
</div>

<script>
  const ctx = document.getElementById('requestChart');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?php echo json_encode(array_column($chart_data, 'month')); ?>,
      datasets: [{
        label: 'Total Request Amount (₹)',
        data: <?php echo json_encode(array_column($chart_data, 'total')); ?>,
        backgroundColor: 'rgba(0, 180, 216, 0.7)',
        borderColor: '#00B4D8',
        borderWidth: 2,
        borderRadius: 8
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
          ticks: { color: '#fff' },
          grid: { color: 'rgba(255,255,255,0.1)' }
        },
        x: {
          ticks: { color: '#fff' },
          grid: { display: false }
        }
      },
      plugins: {
        legend: { labels: { color: '#fff' } }
      }
    }
  });
</script>
</body>
</html>
