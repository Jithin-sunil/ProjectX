<?php
include("../asset/connection/connection.php");
$category = "";
$eid = 0;

if (isset($_POST['btn'])) {
    $category = $_POST['cat'];
    $eid = $_POST['txt_eid'];

    if ($eid == 0) {
        $insQry = "INSERT INTO tbl_category(category_name) VALUES('".$category."')";
        if ($Con->query($insQry)) {
            echo "<script>alert('✅ Category added successfully!'); window.location='Category.php';</script>";
        }
    } else {
        $upQry = "UPDATE tbl_category SET category_name='".$category."' WHERE category_id='".$eid."'";
        if ($Con->query($upQry)) {
            echo "<script>alert('✅ Category updated successfully!'); window.location='Category.php';</script>";
        }
    }
}

if (isset($_GET['did'])) {
    $delQry = "DELETE FROM tbl_category WHERE category_id=".$_GET['did'];
    if ($Con->query($delQry)) {
        echo "<script>alert('🗑️ Category deleted successfully!'); window.location='Category.php';</script>";
    }
}

if (isset($_GET['eid'])) {
    $editSel = "SELECT * FROM tbl_category WHERE category_id='".$_GET['eid']."'";
    $editResult = $Con->query($editSel);
    $editRow = $editResult->fetch_assoc();
    $category = $editRow['category_name'];
    $eid = $editRow['category_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Category Management | AutoResQ</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(135deg, #03045E, #023E8A, #0077B6);
  margin: 0;
  padding: 60px 0;
  color: #fff;
  display: flex;
  justify-content: center;
}

/* Container */
.container {
  width: 90%;
  max-width: 900px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 18px;
  backdrop-filter: blur(15px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
  padding: 40px;
  animation: fadeIn 0.8s ease;
  border: 1px solid rgba(255,255,255,0.1);
}

/* Header */
.header {
  text-align: center;
  margin-bottom: 30px;
}
.header h1 {
  color: #00b4d8;
  font-size: 28px;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.header p {
  color: #90e0ef;
  font-size: 14px;
  margin-top: 8px;
}

/* Form */
input[type="text"] {
  width: 100%;
  padding: 12px 15px;
  border: none;
  border-radius: 10px;
  background: rgba(255,255,255,0.1);
  color: #fff;
  font-size: 15px;
  transition: 0.3s ease;
}

input[type="text"]:focus {
  background: rgba(255,255,255,0.25);
  box-shadow: 0 0 10px #00b4d8;
  outline: none;
}

input[type="submit"] {
  background: #00b4d8;
  color: #001219;
  border: none;
  border-radius: 25px;
  padding: 12px 30px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.3s ease;
  display: block;
  margin: 25px auto;
}

input[type="submit"]:hover {
  background: #90e0ef;
  transform: scale(1.05);
  box-shadow: 0 0 12px #00b4d8;
}

/* Table */
.data-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  font-size: 15px;
}

.data-table th {
  background: rgba(0, 180, 216, 0.25);
  color: #00b4d8;
  text-transform: uppercase;
  font-weight: 600;
  padding: 12px;
}

.data-table td {
  text-align: center;
  padding: 10px;
  border-bottom: 1px solid rgba(255,255,255,0.1);
}

.data-table tr:nth-child(even) {
  background: rgba(255,255,255,0.05);
}

/* Buttons */
.action-btn {
  text-decoration: none;
  padding: 6px 14px;
  border-radius: 8px;
  color: #fff;
  font-weight: 500;
  margin: 0 5px;
  transition: 0.3s ease;
}

.edit {
  background: #0077b6;
}

.delete {
  background: #ff4d6d;
}

.action-btn:hover {
  transform: scale(1.1);
  opacity: 0.9;
}

/* Floating Back Button */
.floating-btn {
  position: fixed;
  bottom: 25px;
  right: 25px;
  background: #00b4d8;
  color: #001219;
  padding: 14px 28px;
  border-radius: 30px;
  font-weight: 600;
  text-transform: uppercase;
  text-decoration: none;
  transition: 0.3s ease;
  box-shadow: 0 0 15px rgba(0,180,216,0.6);
}

.floating-btn:hover {
  background: #90e0ef;
  transform: scale(1.08);
}

/* Animation */
@keyframes fadeIn {
  from {opacity: 0; transform: translateY(20px);}
  to {opacity: 1; transform: translateY(0);}
}
</style>
</head>

<body>
<div class="container">
  <div class="header">
    <h1>Manage Categories</h1>
    <p>Organize AutoResQ product and service categories</p>
  </div>

  <form method="post" action="Category.php">
    <label for="cat">Category Name</label>
    <input type="text" name="cat" id="cat" required placeholder="Enter category name" value="<?php echo $category; ?>" />
    <input type="hidden" name="txt_eid" id="txt_eid" value="<?php echo $eid; ?>" />
    <input type="submit" name="btn" id="btn" value="<?php echo $eid == 0 ? 'Add Category' : 'Update Category'; ?>" />
  </form>

  <table class="data-table">
    <tr>
      <th>Sl.No</th>
      <th>Category</th>
      <th>Action</th>
    </tr>
    <?php
    $i = 0;
    $selQry = "SELECT * FROM tbl_category";
    $result = $Con->query($selQry);
    while ($row = $result->fetch_assoc()) {
        $i++;
    ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $row['category_name']; ?></td>
      <td>
        <a href="Category.php?eid=<?php echo $row['category_id']; ?>" class="action-btn edit">Edit</a>
        <a href="Category.php?did=<?php echo $row['category_id']; ?>" class="action-btn delete">Delete</a>
      </td>
    </tr>
    <?php } ?>
  </table>
</div>

<a href="AdminHomePage.php" class="floating-btn">⬅ Back to Dashboard</a>
</body>
</html>
