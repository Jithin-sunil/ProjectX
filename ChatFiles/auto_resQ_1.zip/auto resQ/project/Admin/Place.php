<?php
include("../asset/connection/connection.php");

if(isset($_POST['btn'])) {
    $district = $_POST['dis'];
    $place = $_POST['place'];
    $insQry = "INSERT INTO tbl_place(district_id, place_name) VALUES('".$district."', '".$place."')";
    if($Con->query($insQry)) {
        echo "<script>alert('Place added successfully');</script>";
    }
}

if(isset($_GET['did'])) {
    $delQry = "DELETE FROM tbl_place WHERE place_id=".$_GET['did'];
    if($Con->query($delQry)) {
        echo "<script>alert('Place deleted successfully'); window.location='place.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AutoResQ | Manage Place</title>
<style>
    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #0A2647, #144272, #205295);
        color: #fff;
        min-height: 100vh;
        margin: 0;
        padding: 0;
    }

    h1 {
        text-align: center;
        margin-top: 30px;
        font-size: 32px;
        color: #00D1FF;
        text-shadow: 1px 1px 5px #000;
    }

    .container {
        width: 90%;
        max-width: 900px;
        margin: 40px auto;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0px 4px 20px rgba(0,0,0,0.3);
        backdrop-filter: blur(8px);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 25px;
    }

    th, td {
        border: 1px solid rgba(255,255,255,0.2);
        padding: 10px;
        text-align: center;
    }

    th {
        background: rgba(0, 209, 255, 0.2);
        color: #fff;
        font-weight: bold;
    }

    td {
        background: rgba(255,255,255,0.05);
    }

    select, input[type="text"] {
        width: 95%;
        padding: 8px;
        border-radius: 8px;
        border: none;
        outline: none;
        background: rgba(255,255,255,0.2);
        color: #fff;
    }

    input::placeholder {
        color: #ddd;
    }

    option {
        color: #000;
    }

    .btn {
        padding: 10px 18px;
        border-radius: 10px;
        background: #00D1FF;
        border: none;
        color: #000;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
    }

    .btn:hover {
        background: #00A6C9;
        transform: scale(1.05);
    }

    a {
        color: #00D1FF;
        text-decoration: none;
        font-weight: bold;
    }

    a:hover {
        color: #FFD93D;
    }

    .form-section {
        margin-bottom: 30px;
        text-align: center;
    }
</style>
</head>

<body>
    <h1>Manage Place - AutoResQ Admin</h1>
    <div class="container">
        <form id="form1" name="form1" method="post" action="place.php">
            <div class="form-section">
                <table>
                    <tr>
                        <th>District</th>
                        <td>
                            <select name="dis" id="dis" required>
                                <option value="">Select District</option>
                                <?php
                                $districtSel = "SELECT * FROM tbl_district";
                                $disResult = $Con->query($districtSel);
                                while($disRow = $disResult->fetch_assoc()) {
                                    echo '<option value="'.$disRow['district_id'].'">'.$disRow['district_name'].'</option>';
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Place</th>
                        <td>
                            <input type="text" name="place" id="place" placeholder="Enter Place Name" required />
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center">
                            <input type="submit" name="btn" id="btn" value="Add Place" class="btn" />
                        </td>
                    </tr>
                </table>
            </div>

            <table>
                <tr>
                    <th>SL No</th>
                    <th>District</th>
                    <th>Place</th>
                    <th>Action</th>
                </tr>
                <?php
                $i=0;
                $selQry = "SELECT * FROM tbl_place p INNER JOIN tbl_district d ON d.district_id = p.district_id";
                $result = $Con->query($selQry);
                while($row = $result->fetch_assoc()) {
                    $i++;
                    echo '<tr>
                        <td>'.$i.'</td>
                        <td>'.$row['district_name'].'</td>
                        <td>'.$row['place_name'].'</td>
                        <td><a href="place.php?did='.$row['place_id'].'">Delete</a></td>
                    </tr>';
                }
                ?>
            </table>
        </form>
    </div>
</body>
</html>
