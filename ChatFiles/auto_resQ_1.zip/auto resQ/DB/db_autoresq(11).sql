-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2025 at 12:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_autoresq`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(15, 'chriz', 'chriz@gmail.com', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assignwork`
--

CREATE TABLE `tbl_assignwork` (
  `assign_id` varchar(60) NOT NULL,
  `request_id` varchar(60) NOT NULL,
  `mechanic_id` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brand_id` int(60) NOT NULL,
  `brand_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brand_id`, `brand_name`) VALUES
(6, 'hero'),
(9, 'yamaha'),
(10, 'Maruti Suzuki'),
(11, 'Hyundai'),
(12, 'Tata Motors'),
(13, 'Mahindra'),
(14, 'Toyota'),
(15, 'Kia'),
(16, 'Volkswagen'),
(17, 'Mercedes-Benz'),
(18, 'BMW'),
(19, ' Audi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`) VALUES
(11, 'two wheeler'),
(12, 'heavy'),
(13, 'four wheeler'),
(14, 'others');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaint`
--

CREATE TABLE `tbl_complaint` (
  `complaint_id` int(70) NOT NULL,
  `complaint_title` varchar(70) NOT NULL,
  `complaint_content` varchar(100) NOT NULL,
  `complaint_reply` varchar(80) NOT NULL,
  `user_id` int(70) NOT NULL,
  `complaint_date` date DEFAULT NULL,
  `complaint_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_complaint`
--

INSERT INTO `tbl_complaint` (`complaint_id`, `complaint_title`, `complaint_content`, `complaint_reply`, `user_id`, `complaint_date`, `complaint_status`) VALUES
(14, 'service', 'servixce kollilka', '', 0, '2025-09-17', 0),
(15, 'sdc', 'ascf', '', 0, '2025-09-17', 0),
(16, 'dwfvc', 'qewcf', 'vgjhmgj', 9, '2025-09-17', 1),
(17, 'mosham', 'maha mosham', 'aaano anna ne kerendea', 9, '2025-09-17', 1),
(18, 'bad behaviour', 'he called me vanm', 'we fix it', 17, '2025-09-25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` int(11) NOT NULL,
  `district_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`district_id`, `district_name`) VALUES
(28, 'ernakulam'),
(29, 'idukki'),
(30, 'wayyand'),
(31, 'kozhikode'),
(32, 'kollam'),
(33, 'thiruvanathapuram');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedback_id` int(60) NOT NULL,
  `feedback_content` varchar(60) NOT NULL,
  `user_id` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_feedback`
--

INSERT INTO `tbl_feedback` (`feedback_id`, `feedback_content`, `user_id`) VALUES
(3, 'kollam\r\n', 0),
(4, 'kollam', 9),
(5, 'superr service aanu', 9),
(6, 'adipwoli', 17);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mechanic`
--

CREATE TABLE `tbl_mechanic` (
  `mechanic_id` int(60) NOT NULL,
  `mechanic_name` varchar(60) NOT NULL,
  `mechanic_email` varchar(60) NOT NULL,
  `mechanic_contact` int(11) NOT NULL,
  `mechanic_password` varchar(50) NOT NULL,
  `mechanic_photo` varchar(60) NOT NULL,
  `workshop_id` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mechanic`
--

INSERT INTO `tbl_mechanic` (`mechanic_id`, `mechanic_name`, `mechanic_email`, `mechanic_contact`, `mechanic_password`, `mechanic_photo`, `workshop_id`) VALUES
(5, 'leo', 'ibnu12@gmail.com', 0, 'ibnu123', 'Screenshot (2).png', '8'),
(12, 'mechanic', 'mechanic@gamil.com', 987867657, '123456789', 'Screenshot (2).png', '14'),
(13, 'babns', 'babs@gmail.cp', 1253476324, 'ibnu123', 'mmmmm.jpg', '16'),
(14, 'abin', 'abin@gmail.com', 2147483647, 'Ibnu1234$', 'Screenshot (2).png', '17'),
(15, 'fgiosiohfg', 'bubu@gmial.com', 2147483647, 'ibnu!@#12A', 'Screenshot (6).png', '18'),
(16, 'arun', 'arun@gmail.com', 2147483647, 'Arun123@#', 'aneeta.jpeg', '19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_place`
--

CREATE TABLE `tbl_place` (
  `place_id` int(11) NOT NULL,
  `place_name` varchar(60) NOT NULL,
  `district_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_place`
--

INSERT INTO `tbl_place` (`place_id`, `place_name`, `district_id`) VALUES
(2, 'rajakd', 3),
(4, 'rajakd', 3),
(20, 'muvattupuzha', 23),
(21, 'kothamangalam', 23),
(22, 'aluva', 28),
(23, 'thodupuzha', 29),
(24, 'batheri', 30),
(25, 'koyilandi', 31),
(26, 'varkala', 32),
(27, 'thampanur', 33);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `rating_id` int(11) NOT NULL,
  `rating_data` int(11) NOT NULL,
  `rating_content` varchar(60) NOT NULL,
  `rating_datetime` varchar(60) NOT NULL,
  `workshop_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_rating`
--

INSERT INTO `tbl_rating` (`rating_id`, `rating_data`, `rating_content`, `rating_datetime`, `workshop_id`, `user_id`) VALUES
(1, 5, 'Good', '2025-09-30 11:57:14', 0, 18),
(2, 5, 'Good', '2025-09-30 11:57:49', 18, 18),
(3, 4, 'goofd', '2025-09-30 12:58:25', 19, 19);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_request`
--

CREATE TABLE `tbl_request` (
  `request_id` int(60) NOT NULL,
  `request_title` varchar(60) NOT NULL,
  `request_content` varchar(80) NOT NULL,
  `user_id` varchar(60) NOT NULL,
  `workshop_id` varchar(60) NOT NULL,
  `request_status` int(60) NOT NULL DEFAULT 0,
  `request_amount` int(11) NOT NULL,
  `request_date` varchar(60) NOT NULL,
  `mechanic_id` int(11) NOT NULL,
  `request_bill` varchar(600) NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `vehicle_no` varchar(80) DEFAULT NULL,
  `request_location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_request`
--

INSERT INTO `tbl_request` (`request_id`, `request_title`, `request_content`, `user_id`, `workshop_id`, `request_status`, `request_amount`, `request_date`, `mechanic_id`, `request_bill`, `category_id`, `brand_id`, `vehicle_no`, `request_location`) VALUES
(1, 'hh', 'ygbkjh', '9', '16', 0, 0, '2025-09-24', 0, '', 11, 6, NULL, NULL),
(2, 'oirtjiojtr', 'yoiejiojgirjkpoigskor', '9', '14', 0, 0, '2025-09-25', 0, '', 11, 9, NULL, NULL),
(3, 'engine failure', 'roodil kedakuva', '17', '17', 5, 0, '2025-09-25', 14, 'Screenshot (3).png', 11, 9, NULL, NULL),
(4, 'breakdown', 'roadil kedakuva', '17', '17', 6, 0, '2025-09-26', 14, 'Screenshot (3).png', 13, 14, NULL, NULL),
(5, 'breakdowm', 'near road', '9', '16', 0, 0, '2025-09-26', 0, '', 11, 6, 'kl 69 c 1213', NULL),
(6, 'giuehuhfrasg', 'gaiojgijipogjeijgeipjaopiegj', '9', '17', 0, 0, '2025-09-26', 0, '', 11, 9, 'kl 68 c 1213', NULL),
(7, 'fuel', 'fuelduihauihsfuihsfuih', '9', '17', 5, 70000, '2025-09-26', 12, 'Screenshot (2).png', 12, 9, 'kl456789', NULL),
(8, 'fuel', 'fuel no tthereee', '9', '17', 0, 0, '2025-09-26', 0, '', 11, 9, 'kl 68 c 1213', NULL),
(9, 'ghdoijfijipsfojh', 'hdsopifhmpfmho[mh[ph', '9', '17', 0, 0, '2025-09-26', 0, '', 12, 9, '74583890609', 'uhgrfhghuiorgf'),
(10, 'breakdownown', 'car engine out complitly', '17', '17', 0, 0, '2025-09-26', 0, '', 13, 10, 'kl 17 l 3861', 'town'),
(11, 'breakdown', 'engine failure', '17', '14', 5, 70000, '2025-09-26', 12, 'Screenshot (2).png', 11, 9, 'kl 17 l 3862', 'town'),
(12, 'eduiwhoipgig', 'fawhiojtgpog', '18', '18', 6, 5678, '2025-09-26', 15, '1.jpeg', 11, 6, '87787898', 'muvatupuxa'),
(13, 'gsojpkg', 'gfspokgmpokgpoijkgpoij', '18', '18', 5, 8000, '2025-09-26', 15, 'Screenshot (2).png', 11, 6, 'g-0osiogkjpogk', 'ijfiigopj'),
(14, 'fuel', 'g98u890u80jg08jg08jg8judgjijgfijifg', '11', '18', 5, 8000, '2025-09-29', 15, 'Screenshot (2).png', 11, 6, '67778789', 'rajaladu'),
(15, 'hjhjkjc', 'k,jvlkhjggh', '15', '18', 5, 6678, '2025-09-29', 15, 'Screenshot (3).png', 12, 11, '45788', 'rajakumari'),
(16, 'Kfghfg', 'Jfsvbmnkhjiyhuiyiyif', '18', '18', 5, 2055, '2025-09-30', 15, 'bat.webp', 11, 6, 'kl 17 M 3596', 'FGHduifhdifgdtd'),
(17, 'gas leak', 'gass leaked ath thdhhjfbjhdd', '19', '19', 6, 555, '2025-09-30', 16, 'ashmitha.jpeg', 12, 11, 'Kl 45 C 1234', 'nirmala college jn\r\nmuvattupuzha\r\nsec123\r\n'),
(18, 'gsdnfjngjfnkg', 'gdfl;kmnhjgcdgnhjlkxf', '19', '18', 3, 0, '2025-09-30', 15, '', 13, 10, 'kl 46 c 3456', 'nirmajoiufhj'),
(19, 'bhglkfmhgn', 'hdgflkjhms;dfhlkjk', '10', '19', 5, 544654, '2025-09-30', 16, 'ashmitha.jpeg', 14, 10, '344353565', 'uirtfhuighuihjo'),
(20, 'ghfdjohjd', 'gggggdfjkhiojo9hijfh', '9', '19', 6, 414755, '2025-10-03', 16, 'Screenshot (7).png', 12, 9, '64765788', 'tyrkpktyr');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

CREATE TABLE `tbl_subcategory` (
  `subcategory_id` int(60) NOT NULL,
  `subcategory_name` varchar(60) NOT NULL,
  `category_id` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`subcategory_id`, `subcategory_name`, `category_id`) VALUES
(1, 'jhf', 7),
(3, 'shine', 7),
(4, 'Car', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `user_email` varchar(60) NOT NULL,
  `user_contact` varchar(60) NOT NULL,
  `user_address` varchar(100) NOT NULL,
  `user_photo` varchar(100) NOT NULL,
  `user_password` varchar(60) NOT NULL,
  `place_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_email`, `user_contact`, `user_address`, `user_photo`, `user_password`, `place_id`) VALUES
(9, 'user', 'user@gamil.com', '90897877', 'user\r\nautoresq', 'Screenshot (2).png', 'user123', 23),
(10, 'ibnu', 'ibnu@123gmail.com', '675789993', 'jhfdygfrgsuigiugigfuigfduiiugfduigfdiugfdiufds', 'Screenshot (6).png', '12345', 23),
(11, 'chriz', 'chriz@gmail.com', '888486756', 'muvtupuzha\r\nernakulam', 'Screenshot (6).png', '1234', 25),
(12, 'fayz', 'fayz@gamil.com', '123456', 'fayz123', 'Screenshot (2).png', '12345', 24),
(13, 'chris', 'rgfsaio sjdvsopdfjiop', '8848166362', 'fdsapknfdjpsafd', 'Screenshot (6).png', 'YGSiHUAsh1', 0),
(14, 'chuiodfajoi', 'fajhnsdfpifsn', '8848166362', 'dghxjhjoghjohgoi', 'Screenshot (7).png', 'Cygdfhjn4', 23),
(15, 'neew', 'new@gamil.cpm', '8478977859', 'jodklbkxl nkclnkbl', 'Screenshot (6).png', 'Wedrthg56', 23),
(16, 'neew', 'new@gamil.cpm', '8478977859', 'jodklbkxl nkclnkbl', 'Screenshot (6).png', 'Wedrthg56', 23),
(17, 'tomy', 'tomy@gmail.com', '7865349247', 'newyork\r\nhillview', 'Screenshot (2).png', 'Ibnu123$', 27),
(18, 'Joyes', 'joyes@gamil.com', '8848166362', 'foiaejiojgvojpog\r\n', 'Screenshot (7).png', 'Ibnu123$', 23),
(19, 'Varis', 'varis@gmail,com', '8768595959', 'avris\r\nvaris', '3.jpeg', 'Varis12@3', 25);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_workshop`
--

CREATE TABLE `tbl_workshop` (
  `shop_id` int(11) NOT NULL,
  `shop_name` varchar(60) NOT NULL,
  `shop_email` varchar(60) NOT NULL,
  `shop_address` varchar(90) NOT NULL,
  `shop_password` varchar(60) NOT NULL,
  `shop_photo` varchar(100) NOT NULL,
  `shop_proof` varchar(100) NOT NULL,
  `place_id` int(11) NOT NULL,
  `shop_contact` int(20) NOT NULL,
  `workshop_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_workshop`
--

INSERT INTO `tbl_workshop` (`shop_id`, `shop_name`, `shop_email`, `shop_address`, `shop_password`, `shop_photo`, `shop_proof`, `place_id`, `shop_contact`, `workshop_status`) VALUES
(14, 'workshop', 'workshop@gmai.com', 'workshop\r\nautoresq', 'workshop123', 'Screenshot (3).png', 'Screenshot (2).png', 23, 90909090, 1),
(15, 'workshop2', 'workshop2@gmail.com', 'workshop2\r\nautorewsq', '7845578', 'Screenshot (5).png', 'Screenshot (5).png', 22, 87587859, 2),
(16, 'jw tunes', 'jw@gmail.com', 'ernakulam lochio', 'ibnu123', 'Screenshot (5).png', 'Screenshot (6).png', 22, 123456578, 1),
(17, 'babsautomotive', 'babs123@gmail.com', 'kolanchery\r\nekm', 'Ibnu123$', 'Screenshot (7).png', 'Screenshot (15).png', 22, 2147483647, 1),
(18, 'Yoo yo', 'yoo@gmail.com', 'newyork\r\nusa', 'Ibnu123$', 'Screenshot (2).png', 'Screenshot (7).png', 22, 2147483647, 1),
(19, 'JINworks', 'jinworks@gmail.com', 'jins 123 jdfjnhfjiufjh', 'Jinwork@12', 'shamna.jpeg', 'Aadhar-Card-400x300.jpeg', 24, 2147483647, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  ADD PRIMARY KEY (`complaint_id`);

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `tbl_mechanic`
--
ALTER TABLE `tbl_mechanic`
  ADD PRIMARY KEY (`mechanic_id`);

--
-- Indexes for table `tbl_place`
--
ALTER TABLE `tbl_place`
  ADD PRIMARY KEY (`place_id`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `tbl_request`
--
ALTER TABLE `tbl_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  ADD PRIMARY KEY (`subcategory_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_workshop`
--
ALTER TABLE `tbl_workshop`
  ADD PRIMARY KEY (`shop_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brand_id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  MODIFY `complaint_id` int(70) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
  MODIFY `district_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  MODIFY `feedback_id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_mechanic`
--
ALTER TABLE `tbl_mechanic`
  MODIFY `mechanic_id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_place`
--
ALTER TABLE `tbl_place`
  MODIFY `place_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `rating_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_request`
--
ALTER TABLE `tbl_request`
  MODIFY `request_id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  MODIFY `subcategory_id` int(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_workshop`
--
ALTER TABLE `tbl_workshop`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
